"""Screened-Poisson completion baseline, preserving pose and recording inferred closure."""
import os,sys,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,trimesh,open3d as o3d
R=ROOT/'scenes/test_scene_2';a=np.load(R/'assets/labeled_mesh.npz');out=R/'assets/variants/poisson';out.mkdir(exist_ok=True);reports=[]
for name in ['chair_left','chair_right','backpack']:
 label=list(a['names']).index(name);m=trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==label],process=True);np.random.seed(27);points,idx=trimesh.sample.sample_surface(m,30000);pc=o3d.geometry.PointCloud(o3d.utility.Vector3dVector(points));pc.normals=o3d.utility.Vector3dVector(m.face_normals[idx]);pc.orient_normals_consistent_tangent_plane(30)
 mesh,density=o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pc,depth=7,scale=1.2,n_threads=4);mesh=mesh.simplify_quadric_decimation(18000).filter_smooth_taubin(number_of_iterations=5);mesh.remove_degenerate_triangles();mesh.remove_duplicated_triangles();mesh.remove_duplicated_vertices();v=np.asarray(mesh.vertices);f=np.asarray(mesh.triangles);tm=trimesh.Trimesh(v,f,process=True);parts=tm.split(only_watertight=False);tm=max(parts,key=lambda x:x.area);tm.export(out/f'{name}.ply');report={'object':name,'method':'Screened Poisson depth 7, oriented sampled TSDF normals, scale 1.2, 18k target faces, 5 Taubin iterations, largest component','faces':len(tm.faces),'watertight':bool(tm.is_watertight),'components_before':len(parts),'components_after':1,'bounds':tm.bounds.tolist(),'selected':False,'limitation':'Unseen backs are smooth extrapolation, not measured geometry. No density trimming because that reopens holes.'};reports.append(report);print(report,flush=True)
(out/'report.json').write_text(json.dumps(reports,indent=2))
