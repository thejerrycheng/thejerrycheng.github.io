"""Fit convex contact pieces to validated completed visuals using CoACD."""
import os,json,time,argparse
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0')
import numpy as np,trimesh,coacd
p=argparse.ArgumentParser();p.add_argument('--object',default='backpack');p.add_argument('--fine',action='store_true');args=p.parse_args();R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';name=args.object;variant={'backpack':'backpack_0.04','chair_left':'chair_left_resolved','chair_right':'chair_right_resolved'}[name];source=R/f'assets/variants/carved/{variant}.ply';out=R/('assets/contact_fine' if args.fine else 'assets/contact_candidates')/name;out.mkdir(parents=True,exist_ok=True);m=trimesh.load(source,process=True);coacd.set_log_level('warn');start=time.time();hulls=[]
threshold=.005 if args.fine else .015;limit=24 if args.fine else 12;preprocess='off' if args.fine else 'auto'
for part in m.split(only_watertight=False):
 if part.area<.0005:continue
 pieces=coacd.run_coacd(coacd.Mesh(np.asarray(part.vertices,dtype=np.float64),np.asarray(part.faces,dtype=np.int32)),threshold=threshold,real_metric=True,max_convex_hull=limit,preprocess_mode=preprocess,resolution=2000,mcts_nodes=12,mcts_iterations=40,mcts_max_depth=2,seed=27)
 for v,f in pieces:
  h=trimesh.Trimesh(v,f,process=True);assert h.is_watertight and h.is_convex;h.export(out/f'{len(hulls):02d}.ply');hulls.append(h)
report={'object':name,'source_variant':variant,'method':'CoACD per connected visual part','requested_concavity_m':threshold,'max_hulls_per_part':limit,'preprocess':preprocess,'hulls':len(hulls),'seconds':time.time()-start,'faces':sum(len(h.faces) for h in hulls),'all_closed_convex':True,'measured_error_note':'Concavity is an algorithm setting, not an independently measured maximum contact error. Validate against source surfaces and dynamics before adoption.','physics_note':'Inferred hidden geometry; rigid backpack and chair cushions remain approximations.'};(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
