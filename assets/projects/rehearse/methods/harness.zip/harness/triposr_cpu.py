"""CPU object-completion baseline. Uses upstream TripoSR and skimage marching cubes.
The mesh extraction backend differs from upstream torchmcubes; record this in results.
"""
import os,sys,types,time,json,argparse
from pathlib import Path
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',NUMBA_CACHE_DIR=str(Path('/private/tmp/rehearse-numba')))
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/TripoSR'))
import torch,numpy as np,cv2
from PIL import Image
from skimage.measure import marching_cubes
mc=types.ModuleType('torchmcubes')
def cpu_mc(level,threshold):
 v,f,_,_=marching_cubes(level.cpu().numpy(),level=threshold);return torch.from_numpy(v[:,[2,1,0]].copy()),torch.from_numpy(f.copy().astype(np.int64))
mc.marching_cubes=cpu_mc;sys.modules['torchmcubes']=mc
from tsr.system import TSR
import tsr.models.tokenizers.image as tokenizer
# DINO weights are already included in the TripoSR checkpoint. Only its config is needed.
tokenizer.hf_hub_download=lambda **kwargs:str(ROOT/'models/dino-vitb16/config.json')
p=argparse.ArgumentParser();p.add_argument('--object',default='chair_left');p.add_argument('--resolution',type=int,default=192);args=p.parse_args();scene=ROOT/'scenes/test_scene_2';out=scene/'assets/variants/triposr'/args.object;out.mkdir(parents=True,exist_ok=True)
im=cv2.cvtColor(cv2.imread(str(scene/'source/frames/frame_0013.jpg')),cv2.COLOR_BGR2RGB);mask=cv2.imread(str(scene/f'calibration/masks/frame_0013_{args.object}.png'),0)>127;ys,xs=np.where(mask);lo=[xs.min(),ys.min()];hi=[xs.max()+1,ys.max()+1];crop=im[lo[1]:hi[1],lo[0]:hi[0]].copy();m=mask[lo[1]:hi[1],lo[0]:hi[0]];crop[~m]=128;size=int(max(crop.shape[:2])/.85);square=np.full((size,size,3),128,np.uint8);y=(size-crop.shape[0])//2;x=(size-crop.shape[1])//2;square[y:y+crop.shape[0],x:x+crop.shape[1]]=crop;Image.fromarray(square).save(out/'input.png');torch.set_num_threads(4);t=time.time();model=TSR.from_pretrained(str(ROOT/'models/triposr'),config_name='config.yaml',weight_name='model.ckpt').eval().to('cpu');model.renderer.set_chunk_size(8192);print('loaded',round(time.time()-t,2),flush=True);start=time.time()
with torch.inference_mode():
 codes=model([Image.fromarray(square)],device='cpu');print('inferred latent',round(time.time()-start,2),flush=True);mesh=model.extract_mesh(codes,has_vertex_color=True,resolution=args.resolution)[0]
mesh.export(out/'model.glb');mesh.export(out/'model.ply');parts=mesh.split(only_watertight=False);report={'method':'TripoSR CPU object completion','object':args.object,'input':'frame_0013 + SAM mask, centered crop with 0.85 foreground ratio and gray background','seconds_excluding_model_load':time.time()-start,'resolution':args.resolution,'mesh_extraction':'skimage marching cubes, density threshold 25; differs from upstream torchmcubes implementation','vertices':len(mesh.vertices),'faces':len(mesh.faces),'watertight':bool(mesh.is_watertight),'components':len(parts),'bounds':mesh.bounds.tolist(),'training_ready':False,'remaining_validation':'Canonical generated object; must fit pose/scale to multiple calibrated views and validate hidden shape/contact before adoption.'};(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
