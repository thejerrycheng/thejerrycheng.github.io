"""Resolve intersecting inferred shells by voxel union, retaining their world pose."""
import os,sys,json,time
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,trimesh,open3d as o3d
from scipy import ndimage
from skimage.measure import marching_cubes
R=ROOT/'scenes/test_scene_2/assets/variants/carved';reports=[]
for name in ['chair_left','chair_right']:
 start=time.time();m=trimesh.load(R/f'{name}_shell_0.012.ply',process=True);pitch=.004;lo=m.bounds[0]-.012;shape=np.ceil((m.bounds[1]+.012-lo)/pitch).astype(int)+1;occ=np.zeros(shape,bool)
 for part in m.split(only_watertight=False):
  mesh=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(part.vertices),o3d.utility.Vector3iVector(part.faces));scene=o3d.t.geometry.RaycastingScene(nthreads=4);scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh));a=np.maximum(np.floor((part.bounds[0]-lo)/pitch).astype(int)-1,0);b=np.minimum(np.ceil((part.bounds[1]-lo)/pitch).astype(int)+2,shape);dims=b-a;xyz=np.indices(dims,dtype='float32').reshape(3,-1).T;xyz=(xyz+a)*pitch+lo;values=[]
  for k in range(0,len(xyz),300000):values.append(scene.compute_occupancy(o3d.core.Tensor(xyz[k:k+300000].astype('float32')),nthreads=4,nsamples=3).numpy())
  occ[a[0]:b[0],a[1]:b[1],a[2]:b[2]]|=np.concatenate(values).reshape(dims)>.5
 occ=ndimage.binary_closing(occ,iterations=1);occ=ndimage.binary_fill_holes(occ);volume=ndimage.gaussian_filter(occ.astype('float32'),.6);v,f,_,_=marching_cubes(volume,.45,spacing=(pitch,pitch,pitch));mesh=trimesh.Trimesh(v+lo,f,process=True);mesh.fix_normals();mesh=mesh.simplify_quadric_decimation(face_count=30000);mesh.fix_normals();tag=f'{name}_resolved';mesh.export(R/f'{tag}.ply');om=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(mesh.vertices),o3d.utility.Vector3iVector(mesh.faces));report={'variant':tag,'voxel_m':pitch,'method':'Per-part occupancy union of inferred closed shells; morphological closure and 0.6-voxel Gaussian smoothing; marching cubes and 30k-face quadric simplification','faces':len(mesh.faces),'components':len(mesh.split(only_watertight=False)),'self_intersecting_triangle_pairs':len(om.get_self_intersecting_triangles()),'watertight_open3d':om.is_watertight(),'seconds':time.time()-start,'selected':False,'limitations':'Repairs topology of a thin-shell approximation; does not recover unseen chair anatomy.'};reports.append(report);print(json.dumps(report),flush=True)
(R/'resolved-report.json').write_text(json.dumps(reports,indent=2))
