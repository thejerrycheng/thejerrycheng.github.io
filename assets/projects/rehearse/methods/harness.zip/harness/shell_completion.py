"""Preserve measured front surfaces and close them with explicitly inferred thickness.
An object may contain several closed physical parts owned by one rigid body.
"""
import os,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import numpy as np,trimesh
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';out=R/'assets/variants/carved';a=np.load(out/'baseline.npz');cal=json.loads((R/'calibration/cameras.json').read_text());camera=np.array(cal['cameras'][12]['position']);reports=[]
for name in ['chair_left','chair_right','backpack']:
 j=list(a['names']).index(name);source=trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==j],process=True);removed=0
 while True:
  counts=np.bincount(source.edges_unique_inverse);bad=np.flatnonzero(counts>2)
  if not len(bad):break
  owners=np.flatnonzero(np.isin(source.edges_unique_inverse.reshape(-1,3),bad).any(1));delete=owners[np.argmin(source.area_faces[owners])];keep=np.ones(len(source.faces),bool);keep[delete]=False;source.update_faces(keep);source.remove_unreferenced_vertices();removed+=1
 source.fix_normals(multibody=True)
 for thickness in [.012,.025,.045]:
  closed=[];front_count=0
  for part in source.split(only_watertight=False):
   if len(part.faces)<8:continue
   if part.is_watertight:closed.append(part);continue
   # The majority visible normal should face the captured camera. Individual
   # back surfaces observed in other views keep their coherent orientation.
   facing=np.einsum('ij,ij->i',part.face_normals,camera-part.triangles_center)
   if np.median(facing)<0:part.invert()
   V=part.vertices;F=part.faces;n=len(V);norm=part.vertex_normals;vv=np.r_[V,V-norm*thickness];ff=[F,F[:,::-1]+n];counts=np.bincount(part.edges_unique_inverse);boundary=counts[part.edges_unique_inverse]==1;edges=part.edges[boundary];sides=[]
   for u,v in edges:sides.extend([[v,u,u+n],[v,u+n,v+n]])
   ff.append(np.array(sides,dtype=int).reshape(-1,3));m=trimesh.Trimesh(vv,np.vstack(ff),process=True);m.fix_normals(multibody=True);closed.append(m);front_count+=len(F)
  mesh=trimesh.util.concatenate(closed);tag=f'{name}_shell_{thickness:.3f}';mesh.export(out/f'{tag}.ply');report={'object':name,'variant':tag,'method':'Observed-surface-preserving normal extrusion with sealed boundary loops','inferred_thickness_m':thickness,'front_faces_preserved':front_count,'nonmanifold_faces_removed':removed,'components':len(closed),'watertight':bool(mesh.is_watertight),'consistent_winding':bool(mesh.is_winding_consistent),'faces':len(mesh.faces),'selected':False,'limitations':'Hidden surfaces are constant-thickness approximations, not inferred object anatomy. Several closed parts share one object transform. Requires self-intersection/contact validation.'};reports.append(report);print(json.dumps(report),flush=True)
(out/'shell-report.json').write_text(json.dumps(reports,indent=2))
