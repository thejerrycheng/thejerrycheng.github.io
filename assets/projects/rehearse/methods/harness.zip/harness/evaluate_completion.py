"""Compare fixed-pose completion candidates against withheld carving-view masks.
Camera/depth estimation is shared upstream. Masks are pseudo-references, not ground truth.
"""
import os,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import numpy as np,cv2,trimesh
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';out=R/'assets/variants/carved';a=np.load(out/'baseline.npz');cal=json.loads((R/'calibration/cameras.json').read_text());K=np.array(cal['K']);results=[]
def raster(m,c):
 v=m.vertices@np.array(c['R_world_to_cv']).T+np.array(c['t_world_to_cv']);uv=v[:,:2]/np.maximum(v[:,2:],1e-5)*[K[0,0]/3,K[1,1]/3]+[160,120];mask=np.zeros((240,320),np.uint8)
 for f in m.faces:
  if (v[f,2]>.05).all():cv2.fillConvexPoly(mask,np.clip(np.rint(uv[f]),-10000,10000).astype('int32'),1)
 return mask>0
for name in ['chair_left','chair_right','backpack']:
 j=list(a['names']).index(name);scan=trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==j],process=True);models={'partial_scan':scan}
 for p in sorted(out.glob(name+'_*.ply')):models[p.stem]=trimesh.load(p,force='mesh',process=True)
 for variant,m in models.items():
  views=[]
  for i in [0,6,12,18,24,27]:
   p=R/f'calibration/masks/frame_{i+1:04d}_{name}.png'
   if not p.exists():continue
   ref=cv2.resize(cv2.imread(str(p),0),(320,240),interpolation=cv2.INTER_NEAREST)>127
   if not ref.any():continue
   pred=raster(m,cal['cameras'][i]);views.append({'frame':i+1,'role':'audit' if i in [0,18] else 'selection','iou':float((pred&ref).sum()/max(1,(pred|ref).sum())),'precision':float((pred&ref).sum()/max(1,pred.sum())),'recall':float((pred&ref).sum()/ref.sum())})
  row={'object':name,'variant':variant,'watertight':bool(m.is_watertight),'components':len(m.split(only_watertight=False)),'faces':len(m.faces),'views':views,'mean_iou':float(np.mean([v['iou'] for v in views])),'selection_iou':float(np.mean([v['iou'] for v in views if v['role']=='selection'])),'audit_iou':float(np.mean([v['iou'] for v in views if v['role']=='audit']))};results.append(row);print(json.dumps(row),flush=True)
report={'protocol':'320x240 standalone silhouettes against SAM ViT-B pseudo-reference masks. Six views excluded from carving; frames 1 and 19 reserved for final audit, other available references select parameters. All camera/depth estimates share the original capture. Occlusion is not subtracted; scores are not independent physical accuracy.','results':results};(out/'evaluation.json').write_text(json.dumps(report,indent=2))
