import os,sys,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,open3d as o3d,trimesh
R=ROOT/'scenes/test_scene_2/assets/variants/carved';rows=[]
for name in ['chair_left_shell_0.012','chair_right_shell_0.012','backpack_0.04']:
 m=o3d.io.read_triangle_mesh(str(R/f'{name}.ply'));pairs=np.asarray(m.get_self_intersecting_triangles());row={'variant':name,'self_intersecting_triangle_pairs':len(pairs),'orientable':m.is_orientable(),'watertight_open3d':m.is_watertight(),'edge_manifold':m.is_edge_manifold(allow_boundary_edges=False),'vertex_manifold':m.is_vertex_manifold()};rows.append(row);print(row,flush=True)
(R/'intersection-audit.json').write_text(json.dumps(rows,indent=2))
