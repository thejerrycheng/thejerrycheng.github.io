"""Conservative local relaxation of simplification-induced intersections."""
import os,sys,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,trimesh,open3d as o3d
R=ROOT/'scenes/test_scene_2/assets/variants/carved';reports=[]
for name in ['chair_left_resolved','chair_right_resolved']:
 m=trimesh.load(R/f'{name}.ply',process=True);original=m.vertices.copy();history=[]
 for it in range(12):
  om=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(m.vertices),o3d.utility.Vector3iVector(m.faces));pairs=np.asarray(om.get_self_intersecting_triangles());history.append(len(pairs))
  if not len(pairs):break
  affected=np.unique(m.faces[pairs.ravel()]);neighbors=m.vertex_neighbors;affected=np.unique(np.r_[affected,np.concatenate([neighbors[i] for i in affected])]);new=m.vertices.copy()
  for i in affected:new[i]=m.vertices[i]*.90+m.vertices[neighbors[i]].mean(0)*.10
  m.vertices=new
 assert not len(pairs),(name,history)
 displacement=np.linalg.norm(m.vertices-original,axis=1);assert displacement.max()<.004,(name,displacement.max());m.export(R/f'{name}.ply');r={'variant':name,'intersection_pairs_per_iteration':history,'maximum_vertex_adjustment_m':float(displacement.max()),'watertight_open3d':om.is_watertight(),'vertex_manifold':om.is_vertex_manifold(),'self_intersections':0};reports.append(r);print(r,flush=True)
(R/'local-repair.json').write_text(json.dumps(reports,indent=2))
