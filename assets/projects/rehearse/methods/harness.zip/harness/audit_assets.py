"""Topology audit of exported visual meshes, ignoring UV seam duplication."""
from pathlib import Path
import trimesh,numpy as np,json
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';items=[]
for name in ['table','cup','laptop','laptop_lid','chair_left','chair_right','backpack']:
 m=trimesh.load(R/f'assets/objects/{name}.obj',process=False,force='mesh');m.merge_vertices(merge_tex=True,merge_norm=True);m.remove_unreferenced_vertices();counts=np.bincount(m.edges_unique_inverse,minlength=len(m.edges_unique));items.append({'name':name,'faces':len(m.faces),'finite':bool(np.isfinite(m.vertices).all()),'degenerate_faces':int((m.area_faces<1e-12).sum()),'boundary_edges':int((counts==1).sum()),'nonmanifold_edges':int((counts>2).sum()),'watertight':bool(m.is_watertight),'components':len(m.split(only_watertight=False))})
report={'objects':items,'interpretation':'UV seams are welded for topology analysis. Watertightness alone does not establish physical shape accuracy. Partial chair/backpack visuals remain excluded from a training-ready claim.'};(R/'calibration/asset_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
