"""Measure single-process CPU stepping, without rendering, for this scene."""
from pathlib import Path
import time,json,argparse,numpy as np,mujoco
p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';start=time.perf_counter();m=mujoco.MjModel.from_xml_path(str(R/'scene.xml'));load=time.perf_counter()-start;d=mujoco.MjData(m);times=[]
for _ in range(3):
 mujoco.mj_resetData(m,d);start=time.perf_counter()
 for i in range(round(2/m.opt.timestep)):mujoco.mj_step(m,d)
 times.append(time.perf_counter()-start)
assert np.isfinite(d.qpos).all() and not any(w.number for w in d.warning)
report={'label':a.label,'model_load_seconds':load,'geom_count':m.ngeom,'contact_group_geoms':sum(m.geom_group==3).item(),'simulated_seconds_per_trial':2,'wall_seconds':times,'median_sim_seconds_per_wall_second':2/float(np.median(times)),'protocol':'Three resets and 2 simulated seconds per run, single-process CPU, no rendering, 1 ms step, no robot. Includes all current contacts. Not an RL training throughput benchmark.'};(R/f'calibration/physics_timing_{a.label}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
