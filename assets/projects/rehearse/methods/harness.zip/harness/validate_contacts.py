"""Isolate the articulated lid and test closing against its base and a raised table."""
from pathlib import Path
import xml.etree.ElementTree as ET,json
import numpy as np,mujoco
ROOT=Path(__file__).resolve().parents[1];scene=ROOT/'scenes/test_scene_2';cases=[]
for raised in [False,True]:
 root=ET.parse(scene/'scene.xml').getroot();compiler=root.find('compiler');compiler.set('meshdir',str(scene/'assets/objects'));compiler.set('texturedir',str(scene/'assets'))
 for name in ['laptop','table']:
  body=root.find(f"worldbody/body[@name='{name}']");body.remove(body.find('freejoint'))
 if raised:
  table=root.find("worldbody/body[@name='table']");p=np.fromstring(table.attrib['pos'],sep=' ');p[1]-=.56;p[2]+=.12;table.set('pos',' '.join(map(str,p)))
 m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));d=mujoco.MjData(m);j=m.joint('laptop_hinge');lid=m.geom('laptop_lid_collision').id;base=m.geom('laptop_base_collision').id;worst=0.;pairs=set();angles=[]
 for i in range(int(5/m.opt.timestep)):
  d.qfrc_applied[j.dofadr]=3.0;mujoco.mj_step(m,d);angles.append(float(d.qpos[j.qposadr][0]))
  for c in d.contact:
   if lid in c.geom:
    other=int(c.geom[0] if c.geom[1]==lid else c.geom[1]);pairs.add(mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_GEOM,other) or 'table collision proxy');worst=min(worst,float(c.dist))
 result={'case':'raised table' if raised else 'keyboard closure','max_angle_rad':max(angles),'final_angle_rad':angles[-1],'max_lid_penetration_m':-worst,'contacted':sorted(pairs),'finite':bool(np.isfinite(d.qpos).all()),'warnings':[int(x.number) for x in d.warning]};assert result['finite'] and not any(result['warnings']);assert worst>-.008,result;cases.append(result)
assert cases[0]['max_angle_rad']>.7 and cases[1]['max_angle_rad']<cases[0]['max_angle_rad']-.2,cases
out={'protocol':'MuJoCo 3.5, 5 s closing torque of 3 Nm, table and base fixed to isolate hinge response. Contacts are compliant; bounded numerical penetration is reported. Not a real-world calibration.','cases':cases};(scene/'calibration/hinge_contacts.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
