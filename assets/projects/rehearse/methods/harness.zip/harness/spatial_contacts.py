"""Experimental local convex cover; accurate surface fit at a higher geom count.

This is a capture-specific baseline, not a validated solid decomposition. Each
spatial patch is convexified, possibly bridging local concavities. Report both
directions of surface distance and dynamics cost before adoption.
"""
import os,json,time
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import trimesh,numpy as np
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2'
for name,variant in [('chair_left','chair_left_resolved'),('chair_right','chair_right_resolved'),('backpack','backpack_0.04')]:
 start=time.time();m=trimesh.load(R/f'assets/variants/carved/{variant}.ply',process=True);out=R/'assets/contact_spatial'/name;out.mkdir(parents=True,exist_ok=True);hulls=[];size=.03 if name=='backpack' else .06
 for p in out.glob('*.ply'):p.unlink()
 for part in m.split(only_watertight=False):
  cells=np.floor((part.triangles_center-part.bounds[0])/size).astype(int);_,inverse=np.unique(cells,axis=0,return_inverse=True)
  for i in range(inverse.max()+1):
   ids=np.where(inverse==i)[0];vertices=part.triangles[ids].reshape(-1,3)
   try:h=trimesh.convex.convex_hull(vertices)
   except Exception:
    # Only submillimetre regularization of numerically flat patches.
    normal=part.face_normals[ids].mean(0);normal/=max(np.linalg.norm(normal),1e-9);h=trimesh.convex.convex_hull(np.r_[vertices+normal*.0005,vertices-normal*.0005])
   if h.volume<1e-10:
    normal=part.face_normals[ids[np.argmax(part.area_faces[ids])]];h=trimesh.convex.convex_hull(np.r_[vertices+normal*.0005,vertices-normal*.0005])
   assert h.volume>0
   assert h.is_watertight and h.is_convex;h.export(out/f'{len(hulls):04d}.ply');hulls.append(h)
 report={'object':name,'method':f'Experimental {size*1000:.0f} mm spatial patches, independently convexified','source_variant':variant,'hulls':len(hulls),'faces':sum(len(h.faces) for h in hulls),'seconds':time.time()-start,'all_closed_convex':True,'limit':'Can bridge concavities within a patch; source shape itself is inferred. Higher geom count affects physics cost.'};(out/'report.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
