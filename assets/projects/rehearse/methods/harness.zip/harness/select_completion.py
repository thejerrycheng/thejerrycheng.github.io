"""Promote only candidates that pass topology and source-silhouette preservation gates."""
from pathlib import Path
import numpy as np,json,trimesh,shutil
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';folder=R/'assets/variants/carved';a=np.load(folder/'baseline.npz');evaluation=json.loads((folder/'evaluation.json').read_text());lookup={(x['object'],x['variant']):x for x in evaluation['results']};repairs={x['variant']:x for x in json.loads((folder/'local-repair.json').read_text())};selection={'chair_left':'chair_left_resolved','chair_right':'chair_right_resolved','backpack':'backpack_0.04'};vertices=[];faces=[];labels=[];report=[]
for j,name in enumerate(a['names']):
 selected=selection.get(str(name));m=trimesh.load(folder/f'{selected}.ply',process=True) if selected else trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==j],process=True)
 if not len(m.faces):continue
 if selected:
  old=lookup[(str(name),'partial_scan')];new=lookup[(str(name),selected)];assert m.is_watertight and m.is_winding_consistent
  assert new['selection_iou']>=old['selection_iou']-.015,(name,new['selection_iou'],old['selection_iou']);assert new['audit_iou']>=old['audit_iou']-.015,(name,new['audit_iou'],old['audit_iou'])
  if name!='backpack':assert repairs[selected]['self_intersections']==0 and repairs[selected]['watertight_open3d']
  report.append({'object':str(name),'variant':selected,'selected':True,'selection_iou_before':old['selection_iou'],'selection_iou_after':new['selection_iou'],'audit_iou_before':old['audit_iou'],'audit_iou_after':new['audit_iou'],'watertight':True,'faces':len(m.faces),'components':len(m.split(only_watertight=False)),'completion':'12 mm inferred shell, voxel union and local intersection repair' if name!='backpack' else 'multi-view silhouette/depth bounded volume','limitation':'Inferred hidden geometry; topology checks do not validate real contact shape or material properties.'})
 offset=sum(len(x) for x in vertices);vertices.append(m.vertices);faces.append(m.faces+offset);labels.extend([j]*len(m.faces))
np.savez_compressed(R/'assets/labeled_mesh.npz',vertices=np.vstack(vertices).astype('float32'),faces=np.vstack(faces).astype('int32'),labels=np.array(labels,dtype='uint8'),names=a['names']);(R/'calibration/completion_selection.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
shutil.copy2(R/'assets/labeled_mesh.npz',folder/'objects_selected.npz')
