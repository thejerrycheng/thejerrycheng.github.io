"""Inspect fixed-room plane support without replacing observed geometry."""
import os,sys,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,open3d as o3d,trimesh
R=ROOT/'scenes/test_scene_2';a=np.load(R/'assets/labeled_mesh.npz');F=a['faces'][a['labels']==0];m=trimesh.Trimesh(a['vertices'],F,process=True);x=m.triangles_center;norm=m.face_normals;x=x[(x[:,2]>.12)&(abs(norm[:,2])<.4)];p=o3d.geometry.PointCloud(o3d.utility.Vector3dVector(x));planes=[]
for i in range(8):
 if len(p.points)<100:break
 equation,idx=p.segment_plane(distance_threshold=.025,ransac_n=3,num_iterations=600);pts=np.asarray(p.points)[idx];planes.append({'equation':np.asarray(equation).tolist(),'faces':len(idx),'bounds':[pts.min(0).tolist(),pts.max(0).tolist()]});p=p.select_by_index(idx,invert=True)
(R/'calibration/room_planes.json').write_text(json.dumps(planes,indent=2));print(json.dumps(planes,indent=2))
