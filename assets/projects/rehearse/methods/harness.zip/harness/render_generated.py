"""Blender audit views for canonical generated-object candidates."""
import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2/assets/variants/triposr'
for name in ['chair_left','backpack','chair_right']:
 folder=R/name
 if not (folder/'model.glb').exists():continue
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 bpy.ops.import_scene.gltf(filepath=str(folder/'model.glb'))
 for o in bpy.context.selected_objects:
  if o.type!='MESH':continue
  m=bpy.data.materials.new('Generated vertex colors');m.use_nodes=True;n=m.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');sh=n.new('ShaderNodeEmission');v=n.new('ShaderNodeVertexColor');m.node_tree.links.new(v.outputs['Color'],sh.inputs['Color']);m.node_tree.links.new(sh.outputs[0],out.inputs[0]);o.data.materials.clear();o.data.materials.append(m)
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=4;s.render.resolution_x=512;s.render.resolution_y=512;s.render.resolution_percentage=100;s.world.color=(.7,.7,.7);s.view_settings.view_transform='Standard'
 for i in range(4):
  a=i*math.pi/2;bpy.ops.object.camera_add(location=(1.4*math.cos(a),1.4*math.sin(a),.5));cam=bpy.context.object;cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=1.05;s.camera=cam;s.render.filepath=str(folder/f'view_{i}.png');bpy.ops.render.render(write_still=True)
