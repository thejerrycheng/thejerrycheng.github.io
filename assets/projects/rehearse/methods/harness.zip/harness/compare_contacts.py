"""Compare completed coarse/fine CoACD runs with an independent distance query."""
import os,json,shutil,hashlib
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import trimesh,numpy as np
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';rows=[]
for name,variant in [('chair_left','chair_left_resolved'),('chair_right','chair_right_resolved'),('backpack','backpack_0.04')]:
 source=R/f'assets/variants/carved/{variant}.ply';mesh=trimesh.load(source,process=True);np.random.seed(27);points=mesh.sample(2000);trials=[]
 for folder in ['contact_candidates','contact_fine','contact_spatial']:
  directory=R/'assets'/folder/name
  if not (directory/'report.json').exists():continue
  run=json.loads((directory/'report.json').read_text());paths=sorted(directory.glob('*.ply'));assert len(paths)==run['hulls'],'Incomplete decomposition'
  hulls=[trimesh.load(p,process=True) for p in paths];assert all(h.is_watertight and h.is_convex and h.volume>0 for h in hulls)
  combined=trimesh.util.concatenate(hulls);_,distance,_=trimesh.proximity.closest_point(combined,points);np.random.seed(28);_,reverse,_=trimesh.proximity.closest_point(mesh,combined.sample(2000))
  trials.append({'directory':folder,'hulls':len(hulls),'median_m':float(np.median(distance)),'p95_m':float(np.quantile(distance,.95)),'contact_to_visual_p95_m':float(np.quantile(reverse,.95)),'all_closed_convex':True})
 selected=min(trials,key=lambda t:max(t['p95_m'],t['contact_to_visual_p95_m']));dest=R/'assets/contact_selected'/name;dest.mkdir(parents=True,exist_ok=True)
 for p in dest.glob('*.ply'):p.unlink()
 for p in (R/'assets'/selected['directory']/name).glob('*'):shutil.copy2(p,dest/p.name)
 row={'object':name,'visual_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'trials':trials,'selected':selected};rows.append(row);print(row,flush=True)
report={'objects':rows,'protocol':'2,000 deterministic samples in each direction between completed visual and convex-piece surfaces, using trimesh closest_point. Internal piece surfaces are included. Sampled surface-set distances, not union Hausdorff distance or measured real-object accuracy.','limits':'Hidden shape, supports, mass and friction are inferred. CoACD hull caps prevented requested concavity from being achieved. Spatial patches may bridge local concavities; require dynamics validation.'};(R/'calibration/contact_comparison.json').write_text(json.dumps(report,indent=2))
