"""Derive the lighter CoACD profile from the selected scene without changing visuals."""
from pathlib import Path
import xml.etree.ElementTree as ET,json
import trimesh,numpy as np
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';tree=ET.parse(R/'scene.xml');root=tree.getroot();asset=root.find('asset');dest=R/'assets/objects/contact_coacd';dest.mkdir(parents=True,exist_ok=True)
for name in ['chair_left','chair_right','backpack']:
 body=root.find(f"worldbody/body[@name='{name}']");pos=np.fromstring(body.get('pos'),sep=' ')
 for g in list(body.findall('geom')):
  if g.get('name','').startswith(name+'_contact_'):body.remove(g)
 for m in list(asset.findall('mesh')):
  if m.get('name','').startswith(name+'_contact_'):asset.remove(m)
 source=R/'assets'/('contact_fine' if name.startswith('chair') else 'contact_candidates')/name;report=json.loads((source/'report.json').read_text());files=sorted(source.glob('*.ply'));assert len(files)==report['hulls']
 for i,p in enumerate(files):
  key=f'{name}_contact_{i:02d}';mesh=trimesh.load(p,process=True);mesh.apply_translation(-pos);mesh.export(dest/f'{key}.obj');ET.SubElement(asset,'mesh',name=key,file=f'contact_coacd/{key}.obj');ET.SubElement(body,'geom',name=key,type='mesh',mesh=key,rgba='.1 .5 .9 0',group='3',friction='.8 .01 .001',mass='0')
ET.indent(root);tree.write(R/'scene_coacd.xml',encoding='unicode');print('Exported lighter CoACD contact profile')
