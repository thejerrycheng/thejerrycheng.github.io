"""Fit generated candidates to observed geometry; evaluate masked multi-view silhouettes.
SAM masks are pseudo-references, not human ground truth. This does not authorize adoption.
"""
from pathlib import Path
import numpy as np,trimesh,json,itertools,cv2
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';a=np.load(R/'assets/labeled_mesh.npz');cal=json.loads((R/'calibration/cameras.json').read_text());K=np.array(cal['K']);rng=np.random.default_rng(27)
def similarity(x,y):
 mx=x.mean(0);my=y.mean(0);xx=x-mx;yy=y-my;u,s,v=np.linalg.svd(xx.T@yy);sign=np.ones(3);sign[-1]=np.linalg.det(u@v);rot=(u@np.diag(sign)@v).T;scale=(s*sign).sum()/(xx*xx).sum();return rot,scale,my-scale*mx@rot.T

def silhouette(mesh,c):
 v=mesh.vertices@np.array(c['R_world_to_cv']).T+np.array(c['t_world_to_cv']);xy=v[:,:2]/np.maximum(v[:,2:],1e-5)*[K[0,0]/3,K[1,1]/3]+[160,120];mask=np.zeros((240,320),np.uint8)
 for f in mesh.faces:
  if (v[f,2]>.05).all():cv2.fillConvexPoly(mask,np.clip(np.rint(xy[f]),-10000,10000).astype('int32'),1)
 return mask>0
reports=[]
for name in ['chair_left','backpack']:
 folder=R/'assets/variants/triposr'/name;mesh=trimesh.load(folder/'model.ply',process=True);parts=mesh.split(only_watertight=False);mesh=max(parts,key=lambda p:p.area);trimesh.smoothing.filter_taubin(mesh,iterations=8);gen=mesh.vertices.copy();tree=cKDTree(gen);label=list(a['names']).index(name);scan=trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==label],process=True);np.random.seed(27);target=scan.sample(4000);initial_scale=np.linalg.norm(np.ptp(target,axis=0))/np.linalg.norm(np.ptp(gen,axis=0));best=None
 for perm in itertools.permutations(range(3)):
  for signs in itertools.product([-1,1],repeat=3):
   rot=np.eye(3)[list(perm)]*np.array(signs)[:,None]
   if np.linalg.det(rot)<.5:continue
   scale=initial_scale;translation=target.mean(0)-scale*gen.mean(0)@rot.T
   for iteration in range(35):
    local=(target-translation)@rot/scale;dist,idx=tree.query(local);keep=dist<np.quantile(dist,.9);nr,ns,nt=similarity(gen[idx[keep]],target[keep]);scale=np.clip(ns,initial_scale*.6,initial_scale*1.4);rot=nr;translation=target[keep].mean(0)-scale*gen[idx[keep]].mean(0)@rot.T
   dist,_=tree.query((target-translation)@rot/scale);error=float(np.sqrt(np.mean(np.minimum(dist*scale,.15)**2)))
   if best is None or error<best[0]:best=(error,rot.copy(),scale,translation.copy())
 error,rot,scale,translation=best;mesh.vertices=gen@rot.T*scale+translation;mesh.export(folder/'aligned.glb');mesh.export(folder/'aligned.ply');views=[]
 for i in [0,6,12,18,24,27]:
  path=R/f'calibration/masks/frame_{i+1:04d}_{name}.png'
  if not path.exists():continue
  ref=cv2.resize(cv2.imread(str(path),0),(320,240),interpolation=cv2.INTER_NEAREST)>127
  if not ref.any():continue
  scores={}
  for key,m in [('partial_scan',scan),('generated',mesh)]:
   pred=silhouette(m,cal['cameras'][i]);scores[key+'_silhouette_iou']=float((pred&ref).sum()/max(1,(pred|ref).sum()))
  views.append({'frame':i+1,**scores})
 report={'object':name,'alignment':'24 proper axis initializations; 35 trimmed similarity ICP iterations against partial scan; largest component + 8 Taubin iterations','observed_to_generated_clipped_rms_m':error,'scale':float(scale),'rotation':rot.tolist(),'translation':translation.tolist(),'components_before':len(parts),'components_after':1,'watertight':bool(mesh.is_watertight),'views':views,'mean_scan_iou':float(np.mean([x['partial_scan_silhouette_iou'] for x in views])),'mean_generated_iou':float(np.mean([x['generated_silhouette_iou'] for x in views])),'selected':False,'limitations':'Pseudo-reference SAM masks; standalone silhouettes include occluded geometry. Alignment used shared reconstructed geometry from all views. Not a held-out geometry test. No real scale validation.'};(folder/'alignment.json').write_text(json.dumps(report,indent=2));reports.append(report);print(json.dumps(report),flush=True)
(R/'calibration/generated_comparison.json').write_text(json.dumps(reports,indent=2))
