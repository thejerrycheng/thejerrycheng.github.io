"""Reproducible stage runner with immutable per-run commands and exit reports."""
from pathlib import Path
import argparse,json,subprocess,hashlib,datetime,sys,os
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('action',choices=['plan','run']);p.add_argument('--config',type=Path,required=True);p.add_argument('--stage');args=p.parse_args();cfg=json.loads(args.config.read_text());scene=cfg['scene'];python=str(ROOT/'.venv/bin/python');scripts=ROOT/scene/'scripts'
stages={
 'cameras':[python,str(scripts/'run_colmap.py')],
 'world':[python,str(scripts/'calibrate_world.py')],
 'metric':[python,str(scripts/'metric_scene.py')],
 'depth-large':[python,str(scripts/'run_da3.py'),'--model','large','--resolution','504'],
 'segmentation':[python,str(scripts/'segment_objects.py')],
 'tracking':[python,str(ROOT/'harness/track_video.py'),'--config',str(args.config.resolve())],
 'tracking-export':[python,str(ROOT/'harness/export_tracking.py'),'--config',str(args.config.resolve())],
 'fusion':[python,str(scripts/'fuse_geometry.py'),'--variant','da3_large'],
 'tsdf':[python,str(scripts/'fuse_tsdf.py')],
 'ownership':[python,str(scripts/'prepare_mesh.py')],
 'cleanup':[python,str(scripts/'clean_instances.py')],
 'carving':[python,str(ROOT/'harness/carve_objects.py')],
 'shells':[python,str(ROOT/'harness/shell_completion.py')],
 'resolve-shells':[python,str(ROOT/'harness/remesh_shells.py')],
 'repair-intersections':[python,str(ROOT/'harness/resolve_local_intersections.py')],
 'evaluate-completion':[python,str(ROOT/'harness/evaluate_completion.py')],
 'select-completion':[python,str(ROOT/'harness/select_completion.py')],
 'convex-left':[python,str(ROOT/'harness/decompose_contacts.py'),'--object','chair_left','--fine'],
 'convex-right':[python,str(ROOT/'harness/decompose_contacts.py'),'--object','chair_right','--fine'],
 'convex-backpack':[python,str(ROOT/'harness/decompose_contacts.py'),'--object','backpack'],
 'validate-completion':[python,str(ROOT/'harness/validate_completed_assets.py')],
 'select-contacts':[python,str(ROOT/'harness/compare_contacts.py')],
 'spatial-contacts':[python,str(ROOT/'harness/spatial_contacts.py')],
 'audit-export':[python,str(ROOT/'harness/audit_assets.py')],
 'texture':[python,str(scripts/'texture_mesh.py')],
 'physics':[python,str(scripts/'build_mujoco.py')],
 'coacd-profile':[python,str(ROOT/'harness/export_contact_profile.py')],
 'contacts':[python,str(ROOT/'harness/validate_contacts.py')],
 'packages':[python,str(ROOT/'scripts/verify_packages.py')],
 'browser':[python,str(ROOT/'scripts/check_site.py'),'--interactions']}
if args.action=='plan':
 print(json.dumps({'scene':scene,'stages':stages,'manual_inputs':['floor polygon and scale','landmark correspondences','SAM prompt boxes/masks','fitted object geometry and contact assumptions'],'note':'Run stages explicitly. GPU object-generation experiments are optional separate adapters; an installed package is not a successful inference.'},indent=2));sys.exit()
if args.stage not in stages:p.error('--stage must be one of '+', '.join(stages))
if scene!='scenes/test_scene_2' and args.stage not in ['tracking','tracking-export']:p.error('New capture: supply and review its own calibrated script set before running capture-specific reconstruction stages.')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');run=ROOT/'harness/runs'/f'{stamp}-{args.stage}';run.mkdir(parents=True);record={'stage':args.stage,'scene':scene,'command':stages[args.stage],'config_sha256':hashlib.sha256(args.config.read_bytes()).hexdigest(),'start_utc':stamp,'status':'running'};(run/'run.json').write_text(json.dumps(record,indent=2));(run/'config.json').write_text(args.config.read_text());env={**os.environ,'USE_TF':'0','USE_FLAX':'0','KMP_USE_SHM':'0','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'1'}
with (run/'output.log').open('w') as log:
 proc=subprocess.Popen(stages[args.stage],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 for line in proc.stdout:print(line,end='',flush=True);log.write(line);log.flush()
 code=proc.wait()
record.update(status='passed' if code==0 else 'failed',exit_code=code,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(run/'run.json').write_text(json.dumps(record,indent=2));print(run/'run.json');sys.exit(code)
