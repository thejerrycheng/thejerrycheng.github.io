"""Independent Open3D topology/intersection audit plus convex-contact surface checks."""
import os,sys,json,argparse
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,trimesh,open3d as o3d
parser=argparse.ArgumentParser();parser.add_argument('--contacts',default='contact_candidates');args=parser.parse_args();R=ROOT/'scenes/test_scene_2';results=[]
for name,variant in [('chair_left','chair_left_resolved'),('chair_right','chair_right_resolved'),('backpack','backpack_0.04')]:
 mesh=trimesh.load(R/f'assets/variants/carved/{variant}.ply',process=True);om=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(mesh.vertices),o3d.utility.Vector3iVector(mesh.faces));intersections=len(om.get_self_intersecting_triangles());assert om.is_watertight() and intersections==0
 contact_dir=R/'assets'/args.contacts/name
 if not contact_dir.exists():contact_dir=R/'assets/contact_candidates'/name
 hulls=[trimesh.load(p,process=True) for p in sorted(contact_dir.glob('*.ply'))];assert hulls;assert all(h.is_watertight and h.is_convex and h.volume>0 for h in hulls)
 # Query exact triangle distance to the convex-piece surface set. Internal
 # hull boundaries remain included: this is explicitly not a union Hausdorff test.
 np.random.seed(27);points=mesh.sample(2000);hullmesh=trimesh.util.concatenate(hulls);hm=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(hullmesh.vertices),o3d.utility.Vector3iVector(hullmesh.faces));scene=o3d.t.geometry.RaycastingScene(nthreads=4);scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(hm));distance=scene.compute_distance(o3d.core.Tensor(points.astype('float32')),nthreads=4).numpy();row={'object':name,'visual_faces':len(mesh.faces),'closed_parts':len(mesh.split(only_watertight=False)),'vertex_manifold':om.is_vertex_manifold(),'edge_manifold':om.is_edge_manifold(False),'watertight':om.is_watertight(),'self_intersection_pairs':intersections,'convex_contact_parts':len(hulls),'sampled_visual_to_contact_surface_median_m':float(np.median(distance)),'sampled_visual_to_contact_surface_p95_m':float(np.quantile(distance,.95))};results.append(row);print(row,flush=True)
report={'contact_directory':args.contacts,'objects':results,'distance_protocol':'2,000 deterministic visual-surface samples to nearest convex-piece surface. Includes internal piece boundaries; one-sided comparison, not union Hausdorff distance or ground-truth physical accuracy.','hidden_surface_status':'Inferred closure; real contact shape, rigid-material assumptions and mass/friction are unverified.'};filename='completed_asset_validation.json' if args.contacts=='contact_candidates' else f'{args.contacts}_validation.json';(R/'calibration'/filename).write_text(json.dumps(report,indent=2))
