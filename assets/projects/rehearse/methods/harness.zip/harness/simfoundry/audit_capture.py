#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Audit decoded-frame identity, temporal coverage and the processing/source clocks."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw


def probe(path):
    return json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_frames",
        "-show_streams", "-show_entries",
        "stream=width,height,avg_frame_rate,duration:frame=best_effort_timestamp_time",
        "-of", "json", str(path)]))


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            result.update(chunk)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--video", required=True, type=Path)
    parser.add_argument("--scene", required=True, type=Path)
    parser.add_argument("--frames", type=int, default=400)
    args = parser.parse_args()
    source = probe(args.video)
    source_pts = [float(f["best_effort_timestamp_time"]) for f in source["frames"]]
    root = args.scene / "s1_video"
    prepared = probe(root / "input_video.mp4")
    prep_pts = [float(f["best_effort_timestamp_time"]) for f in prepared["frames"]]
    files = sorted((root / f"frames_subsampled_{args.frames}").glob("*.png"))
    source_indices = [int(p.stem.split("_")[-1])-1 for p in files]
    expected = np.rint(np.linspace(0, len(source_pts)-1, args.frames)).astype(int).tolist()
    dimensions = list(Image.open(files[0]).size)
    checks = {
        "source_pts_strictly_increasing": bool(np.all(np.diff(source_pts) > 0)),
        "uniform_whole_capture_selection": source_indices == expected,
        "all_frames_decoded": len(list((root / "frames_all").glob("*.png"))) == len(source_pts),
        "no_processing_duplicates_or_drops": len(files) == len(prep_pts) == args.frames,
        "processing_pts_strictly_increasing": bool(np.all(np.diff(prep_pts) > 0)),
        "uniform_image_dimensions": all(list(Image.open(p).size) == dimensions for p in files),
        "aspect_preserved": abs(dimensions[0]/dimensions[1]-source["streams"][0]["width"]/source["streams"][0]["height"]) < 1e-6,
    }
    # Decode every original frame independently. The selected PNG must be a direct
    # resize of the original decoded PNG, never a resize of the recompressed video.
    selected_lookup = {index: row for row, index in enumerate(source_indices)}
    capture = cv2.VideoCapture(str(args.video))
    source_error, resize_error = [], []
    index = 0
    while True:
        ok, bgr = capture.read()
        if not ok:
            break
        if index in selected_lookup:
            original = np.asarray(Image.open(root / "frames_all" / f"frame_{index+1:04d}.png").convert("RGB"))
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            source_error.append(float(np.abs(rgb.astype(float)-original).mean()))
            resized = np.asarray(Image.fromarray(original).resize(tuple(dimensions), Image.Resampling.LANCZOS))
            actual = np.asarray(Image.open(files[selected_lookup[index]]).convert("RGB"))
            resize_error.append(float(np.abs(resized.astype(float)-actual).max()))
        index += 1
    capture.release()
    # Different FFmpeg builds may round conversion differently; one 8-bit code
    # value average tolerance. Resize must be byte-identical.
    checks["original_decode_correspondence"] = index == len(source_pts) and len(source_error) == args.frames and max(source_error) <= 1.0
    checks["resized_from_original_png"] = max(resize_error) == 0
    rows = [{"row": row, "source_frame": idx, "source_time_s": source_pts[idx]-source_pts[0],
             "processing_time_s": prep_pts[row], "file": file.name, "sha256": digest(file)}
            for row, (idx, file) in enumerate(zip(source_indices, files))]
    report = {
        "schema_version": 1, "passed": all(checks.values()), "checks": checks,
        "source_sha256": digest(args.video), "source_frame_count": len(source_pts),
        "source_duration_s": float(source["streams"][0]["duration"]),
        "selected_frame_count": len(files), "processing_dimensions": dimensions,
        "processing_fps": prepared["streams"][0]["avg_frame_rate"],
        "processing_duration_s": float(prepared["streams"][0]["duration"]),
        "max_original_decode_mean_error_8bit": max(source_error),
        "max_resize_error_8bit": max(resize_error),
        "timeline_note": "Offline processing video is retimed. Playback and trajectory must use source_time_s, not processing_time_s. Camera inference has not run.",
        "evaluation_reserved_source_frames": sorted(set(range(len(source_pts)))-set(source_indices)),
        "evaluation_note": "71 unsampled frames are reserved for RGB view auditing. Source video is a shared capture, not independent ground-truth geometry; masks/cameras may still share information.",
        "frames": rows,
    }
    path = args.scene / "capture_manifest.json"
    path.write_text(json.dumps(report, indent=2)+"\n")
    sheet = Image.new("RGB", (1024, 3*216), "#16191d")
    draw = ImageDraw.Draw(sheet)
    for slot, row in enumerate(np.rint(np.linspace(0, len(files)-1, 12)).astype(int)):
        thumb = Image.open(files[row]).convert("RGB").resize((256,192))
        x,y = slot%4*256,slot//4*216
        sheet.paste(thumb,(x,y))
        draw.text((x+6,y+196),f"Source {source_indices[row]} / {rows[row]['source_time_s']:.3f}s",fill="white")
    sheet.save(args.scene / "capture_contact_sheet.jpg", quality=92)
    print(json.dumps({k:v for k,v in report.items() if k not in ("frames","evaluation_reserved_source_frames")},indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
