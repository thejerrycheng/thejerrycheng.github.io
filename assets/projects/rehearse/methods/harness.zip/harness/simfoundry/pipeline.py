#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Pinned SimFoundry adapter. Plans by default; --execute runs explicit stages.

No synthetic success markers, implicit uploads, or CPU substitute for CUDA training.
Paths are portable relative to --workspace. Logs and outputs stay in the scene.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
STAGES = "scripts/pipeline/A_reconstruction/stages"
BG = f"{STAGES}/auto_bg_reconstruction"


def plan(cfg, workspace, video, phase):
    root = (workspace / cfg["data_root"]).resolve()
    scene = root / cfg["scene"]
    common = [f"root_dir={root}", f"scene_name={cfg['scene']}", f"seed={cfg['seed']}"]
    canonical = [
        "bash", "scripts/pipeline/A_reconstruction/run.sh", "--scene-name", cfg["scene"],
        "--root-dir", str(root), "--video-fpath", str(video), "--no-stream",
    ]
    options = [
        "s1_video.splat_prep=true", f"s1_video.n_subsampled_frames={cfg['frames']}",
        f"s1_video.target_w={cfg['width']}", f"s1_video.target_h={cfg['height']}",
        f"s1_video.mp4_fps={cfg['processing_fps']}", f"seed={cfg['seed']}",
    ]
    if phase == "prepare":
        return [{"id": "capture", "argv": canonical + ["--include", "1b", "--no-env-switch", "--python-bin", sys.executable, "--"] + options}]
    if phase == "foreground":
        return [{"id": "foreground", "argv": canonical + ["--exclude", "1b", "--detect-articulation", "--"] + options + cfg["canonical_overrides"]}]
    bgcommon = common + [
        f"assets_dir={root / 'assets'}", f"num_frames={cfg['frames']}", "floor_category=floor",
        f"void_mp4_fps={cfg['processing_fps']}",
        f"s2_pass1.width={cfg['width']}", f"s2_pass1.height={cfg['height']}",
        f"s3_pass2.width={cfg['width']}", f"s3_pass2.height={cfg['height']}",
        f"s2_pass1.fps={cfg['processing_fps']}", f"s3_pass2.fps={cfg['processing_fps']}",
    ]
    def stage(label, filename, env="simfoundry", overrides=None):
        return {"id": label, "argv": ["mamba", "run", "-n", env, "python", f"{BG}/{filename}"] + bgcommon + (overrides or [])}
    if phase == "background":
        return [
            stage("quadmask", "1_generate_quadmask_for_void.py"),
            stage("void_pass1", "2_run_void_pass1.py"),
            stage("void_pass2", "3_run_void_pass2.py"),
            {"id": "clean_depth", "argv": ["mamba", "run", "-n", "da3", "python", f"{STAGES}/2b_run_da.py"] + common + [
                f"s2_da.frames_dir={scene / 'auto_bg/void/pass2/cleaned_frames'}",
                f"s2_da.out_dir={scene / 'auto_bg/da3/void'}"]},
            stage("seed", "4_build_seed_ply_from_void_da3.py"),
            stage("gaussian_train", "5_train_bg_splat.py"),
            stage("world_registration", "6_bridge_bg_splat_to_og.py"),
            stage("omnigibson_export", "7_build_og_scene_assets.py"),
        ]
    raise ValueError(phase)


def preflight(vendor):
    checks = {"linux": platform.system() == "Linux", "mamba": shutil.which("mamba") is not None,
              "ffmpeg": shutil.which("ffmpeg") is not None,
              "service_config_present": bool(os.getenv("GCLOUD_PROJECT") or os.getenv("GEMINI_API_KEY"))}
    details = {"cuda": False, "vram_gib": 0, "articulation_available": False, "model_access": "not_verified"}
    if checks["mamba"]:
        probe = 'import torch,json; from simfoundry.pipeline.orchestrator import articulation_available; ok=torch.cuda.is_available(); print(json.dumps({"cuda":ok,"vram_gib":torch.cuda.get_device_properties(0).total_memory/2**30 if ok else 0,"articulation_available":articulation_available()}))'
        result = subprocess.run(["mamba", "run", "-n", "simfoundry", "python", "-c", probe], cwd=vendor, capture_output=True, text=True)
        if result.returncode == 0:
            try:
                details.update(json.loads(result.stdout.strip().splitlines()[-1]))
            except (ValueError, IndexError):
                pass
    checks["cuda_24gb_class"] = details["cuda"] and details["vram_gib"] >= 22
    checks["articulation_dependencies"] = details["articulation_available"]
    checks["vendor_present"] = (vendor / "scripts/cfg/auto_bg.yaml").is_file()
    # This is an execution prerequisite check, not proof that gated weights/APIs work.
    return {"checks": checks, "details": details, "ready_to_attempt": all(checks.values())}


def require_capture(scene, cfg):
    manifest = json.loads((scene / "capture_manifest.json").read_text())
    if not manifest["passed"] or manifest["selected_frame_count"] != cfg["frames"]:
        raise RuntimeError("Capture audit failed or config changed; run audit_capture.py.")
    if manifest["processing_dimensions"] != [cfg["width"], cfg["height"]]:
        raise RuntimeError("Audited frame dimensions disagree with recipe.")
    return manifest


def stage_background_inputs(scene, cfg):
    import numpy as np
    from PIL import Image
    require_capture(scene, cfg)
    required = [scene / "s2_da/da/exports/npz/results.npz", scene / "s14_og/reconstructed_og_scene.json"]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(path)
    if len(list((scene / "s4_frame").glob("image_*_cam2world.npy"))) != 1:
        raise RuntimeError("Require exactly one canonical world anchor.")
    with np.load(required[0]) as data:
        for key in ("extrinsics", "intrinsics", "depth", "image"):
            if key not in data or len(data[key]) != cfg["frames"]:
                raise RuntimeError(f"DA3 key/count mismatch: {key}")
    frames = scene / f"s1_video/frames_subsampled_{cfg['frames']}"
    pngs = sorted(frames.glob("*.png"))
    if len(pngs) != cfg["frames"] or any(Image.open(p).size != (cfg["width"], cfg["height"]) for p in pngs):
        raise RuntimeError("Canonical frame geometry/count changed.")
    dest = scene / "auto_bg/void/input"
    dest.mkdir(parents=True, exist_ok=True)
    for name, target in [("subsampled", frames), ("input_video.mp4", scene / "s1_video/input_video.mp4")]:
        link = dest / name
        if link.exists() or link.is_symlink():
            if not link.is_symlink() or link.resolve() != target.resolve():
                raise RuntimeError(f"Refusing to replace existing input: {link}")
        else:
            link.symlink_to(os.path.relpath(target, link.parent))


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("phase", choices=["preflight", "prepare", "foreground", "background"])
    parser.add_argument("--workspace", type=Path, default=REPO)
    parser.add_argument("--config", type=Path, default=Path(__file__).with_name("scene2.json"))
    parser.add_argument("--video", type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    workspace = args.workspace.resolve()
    vendor = workspace / "third_party/SimFoundry"
    scene = workspace / cfg["data_root"] / cfg["scene"]
    if args.phase == "preflight":
        print(json.dumps(preflight(vendor), indent=2))
        return
    if not args.video:
        parser.error("--video is required; no implicit machine-specific capture path")
    commands = plan(cfg, workspace, args.video.resolve(), args.phase)
    if not args.execute:
        print(json.dumps({"status": "plan_only", "phase": args.phase, "commands": commands}, indent=2))
        return
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=vendor, text=True).strip()
    if head != cfg["revision"]:
        raise RuntimeError("Upstream revision differs from audited recipe.")
    patch = Path(__file__).with_name("patches") / "capture-and-paths.patch"
    subprocess.run(["git", "apply", "--reverse", "--check", str(patch)], cwd=vendor, check=True)
    if args.phase != "prepare":
        report = preflight(vendor)
        if not report["ready_to_attempt"]:
            print(json.dumps(report, indent=2))
            raise SystemExit("CUDA execution prerequisites unavailable; no stages launched.")
        require_capture(scene, cfg)
    if args.phase == "background":
        stage_background_inputs(scene, cfg)
    scene.mkdir(parents=True, exist_ok=True)
    logs = scene / "adapter_logs"
    logs.mkdir(exist_ok=True)
    run = {"revision": head, "phase": args.phase, "status": "running", "stages": []}
    report_path = logs / f"{args.phase}-{time.time_ns()}.json"
    env = dict(os.environ, OMNIGIBSON_HEADLESS="1", PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
    for command in commands:
        started = time.monotonic()
        log = logs / f"{report_path.stem}-{command['id']}.log"
        with log.open("w") as stream:
            result = subprocess.run(command["argv"], cwd=vendor, env=env, stdout=stream, stderr=subprocess.STDOUT)
        run["stages"].append({"id": command["id"], "exit_code": result.returncode, "wall_seconds": time.monotonic()-started, "log": log.name})
        run["status"] = "failed" if result.returncode else "running"
        report_path.write_text(json.dumps(run, indent=2))
        if result.returncode:
            raise SystemExit(f"Stage {command['id']} failed. See {log}")
    run["status"] = "completed_execution_requires_review"
    report_path.write_text(json.dumps(run, indent=2))
    print(report_path)


if __name__ == "__main__":
    main()
