#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Export actual SimFoundry cameras and its Gaussian transform to the web viewer.

The Gaussian PLY stays in its trained frame, preserving covariance and SH.
Apply background_matrix once to its root. Cameras are exported in simulator world.
"""
import argparse
import json
from pathlib import Path
import numpy as np


def camera_matrices(world_to_cv, source_to_sim):
    ext = np.eye(4)
    ext[:3, :4] = np.asarray(world_to_cv)[:3, :4]
    transform = np.asarray(source_to_sim, dtype=float)
    if transform.shape != (4,4) or not np.isfinite(transform).all() or not np.allclose(transform[3],[0,0,0,1]):
        raise ValueError("Invalid homogeneous background transform")
    basis = transform[:3,:3]
    scale = np.cbrt(np.linalg.det(basis))
    if scale <= 0 or not np.allclose(basis.T@basis,np.eye(3)*scale**2,atol=1e-5):
        raise ValueError("Background transform must be a positive uniform similarity")
    if not np.allclose(ext[:3,:3].T@ext[:3,:3],np.eye(3),atol=1e-4) or np.linalg.det(ext[:3,:3]) <= 0:
        raise ValueError("Camera extrinsics must be rigid world-to-OpenCV transforms")
    cv = transform @ np.linalg.inv(ext)
    cv[:3,:3] /= scale  # World translation scales; the camera orientation must not.
    gl = cv @ np.diag([1,-1,-1,1])
    return cv,gl


def main():
    p = argparse.ArgumentParser(__doc__)
    p.add_argument("--scene",required=True,type=Path)
    p.add_argument("--out",required=True,type=Path)
    a = p.parse_args()
    manifest = json.loads((a.scene/"capture_manifest.json").read_text())
    if not manifest["passed"]:
        raise ValueError("Capture audit did not pass")
    name = a.scene.name
    ply = a.scene / f"auto_bg/splat/export/{name}_bg.ply"
    if not ply.is_file():
        raise FileNotFoundError("Trained background PLY does not exist; cannot export a placeholder")
    pose = json.loads(ply.with_name(ply.name+".pose.json").read_text())
    transform = np.asarray(pose["M_src_to_og"],dtype=float)
    data = np.load(a.scene/"s2_da/da/exports/npz/results.npz")
    if len(data["extrinsics"]) != len(manifest["frames"]):
        raise ValueError("Camera rows no longer match audited capture")
    image = data["image"]
    if image.shape[-1] != 3:
        raise ValueError("Expected DA3 image array [N,H,W,3]; verify upstream schema")
    ih,iw = image.shape[1:3]
    w,h = manifest["processing_dimensions"]
    rows = []
    for entry, ext, intrinsics in zip(manifest["frames"],data["extrinsics"],data["intrinsics"]):
        cv,gl = camera_matrices(ext,transform)
        k = np.array(intrinsics,dtype=float)
        k[0] *= w/iw
        k[1] *= h/ih
        rows.append({"row":entry["row"],"source_frame":entry["source_frame"],"time_s":entry["source_time_s"],
                     "K":k.tolist(),"camera_to_world_cv":cv.tolist(),"camera_to_world_gl":gl.tolist()})
    payload = {"schema_version":1,"representation":"SimFoundry trained background + separate object meshes",
               "background_file":ply.name,"background_matrix":transform.tolist(),"background_visual_only":True,
               "camera_dimensions":[w,h],"world_up":[0,0,1],"camera_timeline":"original capture PTS",
               "replay_type":"offline reconstruction","metric_scale":"unverified",
               "camera_estimates":"Original DA3 cameras; do not mislabel as final splatfacto-optimized cameras.",
               "cameras":rows}
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(payload,indent=2)+"\n")


if __name__ == "__main__":
    main()
