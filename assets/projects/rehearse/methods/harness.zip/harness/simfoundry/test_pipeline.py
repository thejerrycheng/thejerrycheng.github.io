# SPDX-License-Identifier: Apache-2.0
"""Regression checks for capture loss and the aspect/world-frame adapters."""
import ast
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO

import numpy as np
from omegaconf import OmegaConf

from pipeline import REPO, plan
from export_cameras import camera_matrices


class PipelineTests(unittest.TestCase):
    def test_camera_world_scale_translation_and_opencv_gl_conventions(self):
        transform = np.diag([2.,2.,2.,1.])
        transform[:3,3] = [10,20,30]
        ext = np.eye(4)[:3]
        ext[:,3] = [-1,-2,-3]
        cv,gl = camera_matrices(ext,transform)
        np.testing.assert_allclose(cv[:3,3],[12,24,36])
        np.testing.assert_allclose(cv[:3,:3],np.eye(3))
        np.testing.assert_allclose(gl[:3,2],[0,0,-1])
        np.testing.assert_allclose(gl[:3,1],[0,-1,0])
        transform[0,0] = -2
        with self.assertRaises(ValueError):
            camera_matrices(ext,transform)

    def test_sampling_keeps_final_view_and_has_no_duplicate_indices(self):
        path = REPO / "third_party/SimFoundry/scripts/pipeline/A_reconstruction/stages/1b_process_raw_video.py"
        tree = ast.parse(path.read_text())
        function = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name == "subsample_images")
        namespace = dict(os=os, np=np, shutil=shutil)
        exec(compile(ast.Module(body=[function],type_ignores=[]),str(path),"exec"),namespace)
        with tempfile.TemporaryDirectory() as temp:
            src,dst = Path(temp)/"source",Path(temp)/"selected"
            src.mkdir()
            for i in range(471):
                (src/f"frame_{i+1:04d}.png").touch()
            with redirect_stdout(StringIO()):
                namespace["subsample_images"](src,dst,400)
            names = sorted(p.name for p in dst.iterdir())
            self.assertEqual(len(names),400)
            self.assertEqual(names[0],"frame_0001.png")
            self.assertEqual(names[-1],"frame_0471.png")

    def test_every_override_exists_in_pinned_upstream_schema(self):
        cfg = json.loads(Path(__file__).with_name("scene2.json").read_text())
        vendor = REPO / "third_party/SimFoundry"
        for phase in ("prepare","foreground","background"):
            for command in plan(cfg,REPO,Path("capture.mov"),phase):
                args = command["argv"]
                name = "auto_bg.yaml" if any("auto_bg_reconstruction/" in a for a in args) else "real2sim_cfg.yaml"
                schema = OmegaConf.load(vendor/"scripts/cfg"/name)
                overrides = args[args.index("--")+1:] if "--" in args else [a for a in args if "=" in a]
                for override in overrides:
                    key,_ = override.split("=",1)
                    sentinel = object()
                    self.assertIsNot(OmegaConf.select(schema,key,default=sentinel),sentinel,(phase,key))
                OmegaConf.set_struct(schema,True)
                OmegaConf.merge(schema,OmegaConf.from_dotlist(overrides))
        bg = plan(cfg,REPO,Path("capture.mov"),"background")
        for command in bg:
            if command["id"] != "clean_depth":
                self.assertIn("s2_pass1.width=512",command["argv"])
                self.assertIn("s3_pass2.width=512",command["argv"])


if __name__ == "__main__":
    unittest.main()
