"""Blender geometry inspection of fixed-world completion candidates."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';cal=json.loads((R/'calibration/cameras.json').read_text());out=R/'assets/variants/carved';s=bpy.context.scene
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=8;s.render.resolution_x=640;s.render.resolution_y=480;s.render.resolution_percentage=100;s.world.color=(.6,.6,.6);s.view_settings.view_transform='Standard'
for name in ['chair_left','chair_right','backpack']:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_mesh.ply(filepath=str(out/f'{name}_0.10.ply'));obj=bpy.context.object;obj.name=name
 m=bpy.data.materials.new('Geometry audit');m.diffuse_color=(.14,.23,.32,1);obj.data.materials.clear();obj.data.materials.append(m)
 bpy.ops.object.light_add(type='AREA',location=(-1,-2,4));bpy.context.object.data.energy=400;bpy.context.object.data.size=5
 target=sum((obj.matrix_world@Vector(c) for c in obj.bound_box),Vector())/8
 for i in range(3):
  if i==0:
   c=cal['cameras'][12];pos=Vector(c['position']);rotation=Matrix(c['rotation_camera_to_world_opengl']).to_euler()
  else:
   pos=target+Vector((1.5 if i==1 else -1.5,1.4,.9));rotation=(target-pos).to_track_quat('-Z','Y').to_euler()
  bpy.ops.object.camera_add(location=pos);cam=bpy.context.object;cam.rotation_euler=rotation;cam.data.type='ORTHO';cam.data.ortho_scale=1.7 if 'chair' in name else 1.1;cam.rotation_euler=(target-pos).to_track_quat('-Z','Y').to_euler();s.camera=cam;s.render.filepath=str(out/f'{name}-audit-{i}.png');bpy.ops.render.render(write_still=True)
