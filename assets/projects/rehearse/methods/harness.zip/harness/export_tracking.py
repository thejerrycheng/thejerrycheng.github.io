"""Export a browser overlay for every processed video frame, with exact PTS."""
from pathlib import Path
import argparse,json,cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);args=p.parse_args();cfg=json.loads(args.config.read_text());scene=ROOT/cfg['scene'];r=scene/'calibration/sam2_fullrate';report=json.loads((r/'report.json').read_text());times=json.loads((r/'timestamps.json').read_text());assert report['every_decoded_frame_processed'] and report['frames']==len(times);names=cfg['objects'];colors=[[0,113,227],[50,160,120],[201,115,39],[173,88,193],[64,135,183],[220,92,96]];frames=[];missing=[]
for i,t in enumerate(times):
 objects=[]
 for n in names:
  m=cv2.imread(str(r/f'masks/{i:05d}_{n}.png'),0)
  if m is None:missing.append([i,n]);continue
  contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);polygons=[cv2.approxPolyDP(c,1.0,True)[:,0].tolist() for c in contours if cv2.contourArea(c)>15];objects.append({'name':n,'polygons':polygons})
 frames.append({'index':i,'time':t,'objects':objects})
assert not missing,missing
out=ROOT/'website/assets/projects/rehearse/scene2';tracking={'model':report['model'],'inference_image_size':report['image_size'],'resolution':[960,720],'colors':colors,'names':names,'frames':frames,'synchronization':'Every decoded video frame has a SAM 2 result. Browser requestVideoFrameCallback mediaTime selects the matching presentation timestamp.','video_sha256':report['video_sha256'],'offline':True};(out/'tracks.json').write_text(json.dumps(tracking,separators=(',',':')))
validation={'frames':len(times),'mask_files':len(times)*len(names),'missing_frames':missing,'strictly_increasing_pts':all(b>a for a,b in zip(times,times[1:])),'frame_interval_range_seconds':[min(np.diff(times)),max(np.diff(times))],'model_seconds':report['seconds'],'inference_image_size':report['image_size'],'same_frame_alignment':'indexed by decoded PTS; no 2 Hz nearest-mask approximation','accuracy_note':'Completeness and timing checks are not segmentation ground truth. Evaluate masks visually and compare reference annotations.'};(r/'validation.json').write_text(json.dumps(validation,indent=2));(out/'tracking-validation.json').write_text(json.dumps(validation,indent=2));print(validation)
