"""Occlusion-aware, multi-view silhouette/depth completion on the captured objects.
This is an explicit CPU baseline, not an implementation of a learned completion paper.
"""
import os,sys,json,time
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',KMP_USE_SHM='0');ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/numpy126'))
import numpy as np,cv2,trimesh
from scipy import ndimage
from skimage.measure import marching_cubes
R=ROOT/'scenes/test_scene_2';out=R/'assets/variants/carved';out.mkdir(exist_ok=True);source=out/'baseline.npz'
if not source.exists():source.write_bytes((R/'assets/labeled_mesh.npz').read_bytes())
a=np.load(source);cal=json.loads((R/'calibration/cameras.json').read_text());K=np.array(cal['K']);withheld=[0,6,12,18,24,27];reports=[];step=.008
for name in ['chair_left','chair_right','backpack']:
 start=time.time();j=list(a['names']).index(name);scan=trimesh.Trimesh(a['vertices'],a['faces'][a['labels']==j],process=True);lo=scan.bounds[0]-.045;hi=scan.bounds[1]+.045;lo[2]=max(lo[2],-.074);shape=np.ceil((hi-lo)/step).astype(int)+1;X=np.indices(shape,dtype='float32').reshape(3,-1).T*step+lo;yes=np.zeros(len(X),np.uint8);no=np.zeros(len(X),np.uint8)
 for i,c in enumerate(cal['cameras']):
  if i in withheld:continue
  P=X@np.array(c['R_world_to_cv']).T+np.array(c['t_world_to_cv']);uv=np.rint(P[:,:2]/np.maximum(P[:,2:],.001)*[K[0,0],K[1,1]]+[480,360]).astype(int);ok=(P[:,2]>.05)&(uv[:,0]>=0)&(uv[:,0]<960)&(uv[:,1]>=0)&(uv[:,1]<720);ids=np.flatnonzero(ok);u,v=uv[ids].T;mask=cv2.imread(str(R/f'calibration/sam2_masks/frame_{i+1:04d}_{name}.png'),0);mask=cv2.dilate(mask,np.ones((3,3),np.uint8))>127;inside=mask[v,u];d=np.load(R/f'calibration/fused_input_{i:02d}.npz')['depth'];h,w=d.shape;depth=d[v*h//720,u*w//960];z=P[ids,2];valid=np.isfinite(depth)&(depth>.05)
  yes[ids[inside&valid&(z>=depth-.045)]]+=1
  no[ids[valid&((inside&(z<depth-.065))|(~inside&(z<=depth+.045)))]]+=1
 for tolerance in [.04,.10,.20]:
  occ=((yes>=2)&(no<=np.maximum(1,tolerance*(yes+no)))).reshape(shape);occ=ndimage.binary_closing(occ,iterations=1);occ=ndimage.binary_fill_holes(occ);occ=ndimage.gaussian_filter(occ.astype('float32'),.7)>.45;lab,n=ndimage.label(occ);sizes=np.bincount(lab.ravel());keep=np.flatnonzero(sizes>=max(30,sizes[1:].max()*.002));keep=keep[keep!=0];occ=np.isin(lab,keep);volume=np.pad(occ.astype('float32'),1);v,f,_,_=marching_cubes(volume,.5,spacing=(step,step,step));m=trimesh.Trimesh(v+lo-step,f,process=True);m.fix_normals();m=m.simplify_quadric_decimation(face_count=24000);trimesh.smoothing.filter_taubin(m,iterations=5);m.fix_normals();tag=f'{name}_{tolerance:.2f}';m.export(out/f'{tag}.ply');rep={'object':name,'variant':tag,'method':'25-view silhouette and depth carving with depth-based occlusion tolerance, bounded volume, morphological closure and Taubin smoothing','withheld_carving_indices':withheld,'voxel_m':step,'contradiction_fraction':tolerance,'minimum_support_views':2,'faces':len(m.faces),'components':len(m.split(only_watertight=False)),'watertight':bool(m.is_watertight),'consistent_winding':bool(m.is_winding_consistent),'bounds':m.bounds.tolist(),'seconds_since_object_start':time.time()-start,'selected':False,'limitations':'All cameras and learned depth share the capture; withheld masks are pseudo-references, not independent physical ground truth. Hidden volumes are inferred.'};reports.append(rep);print(json.dumps(rep),flush=True)
(out/'report.json').write_text(json.dumps(reports,indent=2))
