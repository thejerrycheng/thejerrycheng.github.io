"""Run SAM 2 on every decoded video frame; export presentation timestamps and provenance."""
import os,sys,json,argparse,subprocess,time,hashlib
from pathlib import Path
os.environ.update(KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'third_party/sam2'))
import cv2,numpy as np,torch
from sam2.build_sam import build_sam2_video_predictor
p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);args=p.parse_args();cfg=json.loads(args.config.read_text());scene=ROOT/cfg['scene'];video=ROOT/cfg['tracking']['video'];out=scene/'calibration/sam2_fullrate';out.mkdir(parents=True,exist_ok=True);frames=out/'frames';frames.mkdir(exist_ok=True)
probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(video)]));times=[float(f['best_effort_timestamp_time']) for f in probe['frames']];assert len(times)>0 and all(b>a for a,b in zip(times,times[1:]));times=[t-times[0] for t in times]
if len(list(frames.glob('*.jpg')))!=len(times):
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-y','-i',str(video),'-vf','scale=960:-2','-fps_mode','passthrough','-start_number','0','-q:v','2',str(frames/'%05d.jpg')],check=True)
assert len(list(frames.glob('*.jpg')))==len(times)
(out/'timestamps.json').write_text(json.dumps(times));size=cfg['tracking'].get('image_size',512);torch.set_num_threads(4);model=build_sam2_video_predictor('configs/sam2.1/sam2.1_hiera_t.yaml',str(ROOT/'models/sam2.1/sam2.1_hiera_tiny.pt'),device='cpu',apply_postprocessing=False,hydra_overrides_extra=[f'++model.image_size={size}']);names=cfg['objects'];masks=out/'masks';masks.mkdir(exist_ok=True);start=time.time();stats={};seed_indices=[]
with torch.inference_mode():
 state=model.init_state(str(frames),offload_video_to_cpu=True,offload_state_to_cpu=True)
 for prompt in cfg['tracking']['prompts']:
  idx=min(range(len(times)),key=lambda i:abs(times[i]-prompt['time']));seed_indices.append(idx)
  for obj_id,name in enumerate(names,1):
   path=scene/prompt['mask_pattern'].format(name=name)
   if not path.exists():continue # Object is outside this annotation keyframe.
   mask=cv2.imread(str(path),0);assert mask is not None,path
   if name=='table':
    for other in ['cup','laptop']:mask=cv2.bitwise_and(mask,cv2.bitwise_not(cv2.imread(str(scene/prompt['mask_pattern'].format(name=other)),0)))
   model.add_new_mask(state,frame_idx=idx,obj_id=obj_id,mask=mask>127)
 for reverse in [False,True]:
  for frame,ids,logits in model.propagate_in_video(state,start_frame_idx=min(seed_indices),reverse=reverse):
   if frame in stats:continue
   entry={}
   for j,obj_id in enumerate(ids):
    mask=(logits[j,0]>0).cpu().numpy().astype('uint8')*255;name=names[obj_id-1];cv2.imwrite(str(masks/f'{frame:05d}_{name}.png'),mask);entry[name]=int(np.count_nonzero(mask))
   stats[frame]=entry;progress={'completed':len(stats),'total':len(times),'last_frame':frame,'seconds':time.time()-start};(out/'progress.json').write_text(json.dumps(progress));print(json.dumps(progress),flush=True)
assert set(stats)==set(range(len(times)))
report={'model':'SAM 2.1 Hiera Tiny','device':'CPU float32','image_size':size,'video_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'seconds':time.time()-start,'frames':len(stats),'timestamps':'timestamps.json','objects':names,'prompt_indices':seed_indices,'prompt_source':'Independent box-prompted SAM ViT-B masks on six reference keyframes, aligned to nearest actual video PTS','pixel_counts':stats,'every_decoded_frame_processed':True,'online':False};(out/'report.json').write_text(json.dumps(report,indent=2));print('COMPLETE',len(stats),flush=True)
