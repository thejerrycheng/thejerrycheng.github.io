"""Regularize supported vertical room planes; leave other geometry untouched."""
import os,json
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import numpy as np,trimesh,cv2
from scipy import ndimage
R=Path(__file__).resolve().parents[1]/'scenes/test_scene_2';input=R/'assets/variants/carved/objects_selected.npz';a=np.load(input);V=a['vertices'];F=a['faces'];labels=a['labels'];mesh=trimesh.Trimesh(V,F,process=False);X=mesh.triangles_center;N=mesh.face_normals;planes=json.loads((R/'calibration/room_planes.json').read_text());chosen=[planes[0],planes[2]];available=(labels==0)&(X[:,2]>.10);keep=np.ones(len(F),bool);parts=[];rows=[];step=.02
for plane in chosen:
 q=np.array(plane['equation']);d=abs(X@q[:3]+q[3]);aligned=abs(N@q[:3])>.65;ids=np.flatnonzero(available&(d<.065)&aligned);available[ids]=False;keep[ids]=False;pts=V[F[ids]];lo=pts[:,:,1:].reshape(-1,2).min(0)-.02;hi=pts[:,:,1:].reshape(-1,2).max(0)+.02;shape=np.ceil((hi-lo)/step).astype(int)+1;grid=np.zeros((shape[1],shape[0]),np.uint8)
 for tri in pts:cv2.fillConvexPoly(grid,np.rint((tri[:,1:]-lo)/step).astype('int32'),1)
 before=int(grid.sum());grid=ndimage.binary_closing(grid,structure=np.ones((5,5)));grid=ndimage.binary_fill_holes(grid);lab,n=ndimage.label(grid);sizes=np.bincount(lab.ravel());grid&=sizes[lab]>20;z,y=np.where(grid);vertices=[];faces=[]
 for yy,zz in zip(y,z):
  yz=np.array([[yy,zz],[yy+1,zz],[yy+1,zz+1],[yy,zz+1]])*step+lo;xx=-(yz@q[1:3]+q[3])/q[0];p=np.c_[xx,yz];off=len(vertices);vertices.extend(p.tolist());faces.extend([[off,off+1,off+2],[off,off+2,off+3]])
 part=trimesh.Trimesh(vertices,faces,process=True);parts.append(part);rows.append({'plane':q.tolist(),'replaced_faces':len(ids),'output_faces':len(part.faces),'grid_m':step,'observed_cells':before,'completed_cells':int(grid.sum()),'inferred_extra_cells':int(grid.sum())-before})
vs=[V];fs=[F[keep]];ls=[labels[keep]]
for p in parts:fs.append(p.faces+sum(len(v) for v in vs));vs.append(p.vertices);ls.append(np.zeros(len(p.faces),np.uint8))
np.savez_compressed(R/'assets/labeled_mesh.npz',vertices=np.vstack(vs).astype('float32'),faces=np.vstack(fs).astype('int32'),labels=np.concatenate(ls),names=a['names']);(R/'calibration/structure_regularization.json').write_text(json.dumps({'planes':rows,'method':'Two RANSAC-supported vertical planes; 2 cm raster union, 5-cell closing and hole filling','limitation':'Inferred planar closure, including reflective surfaces. Not a verified collision boundary or measured hidden structure.'},indent=2));print(rows)
