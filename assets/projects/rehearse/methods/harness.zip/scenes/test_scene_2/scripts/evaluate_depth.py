"""Evaluate model depths against withheld SfM tracks; not external depth ground truth."""
import os
os.environ.update(KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import json,numpy as np,pycolmap
from scipy.optimize import least_squares
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text());rec=pycolmap.Reconstruction(R/'calibration/colmap/best');ims={x.name:x for x in rec.images.values()};B=np.array(cal['raw_to_world_rotation']);origin=np.array(cal['origin_raw']);scale=cal['scale_m_per_sfm_unit'];report={}
for variant in ['depth-anything-v2-small','da3','da3_large']:
 frames={}
 if variant.startswith('depth-anything-v2'):
  for i,c in enumerate(cal['cameras']):frames[i]=np.load(R/f'calibration/depth_{Path(c["name"]).stem}.npy')
 else:
  for p in sorted((R/'calibration'/variant).glob('batch_*.npz')):
   a=np.load(p)
   for j,i in enumerate(a['indices']):frames[int(i)]=a['depth'][j]
 errors=[];perframe=[]
 for i,d in frames.items():
  c=cal['cameras'][i];im=ims[c['name']];H,W=d.shape;vals=[];zs=[]
  for pt in im.points2D:
   if not pt.has_point3D():continue
   X=(rec.points3D[pt.point3D_id].xyz-origin)@B.T*scale;z=(np.array(c['R_world_to_cv'])@X+np.array(c['t_world_to_cv']))[2];u,v=np.rint(pt.xy*[W/960,H/720]).astype(int)
   if 0<=u<W and 0<=v<H and .2<z<10:vals.append(d[v,u]);zs.append(z)
  vals=np.array(vals);z=np.array(zs);rng=np.random.default_rng(123+i);idx=rng.permutation(len(z));train=idx[:int(.8*len(z))];test=idx[int(.8*len(z)):]
  inverse=variant.startswith('depth-anything-v2');target=1/z if inverse else z
  p0=np.polyfit(vals[train],target[train],1);fit=least_squares(lambda p:(p[0]*vals[train]+p[1]-target[train])/np.maximum(abs(target[train]),.1),p0,loss='soft_l1',f_scale=.03)
  pred=fit.x[0]*vals[test]+fit.x[1];pred=1/np.maximum(pred,.001) if inverse else pred;e=abs(pred-z[test])/z[test];errors.extend(e.tolist());perframe.append({'frame':c['name'],'withheld_tracks':len(test),'median_abs_relative_error':float(np.median(e))})
 report[variant]={'median_abs_relative_error':float(np.median(errors)),'p90_abs_relative_error':float(np.percentile(errors,90)),'withheld_tracks':len(errors),'frames':perframe};print(variant,report[variant]['median_abs_relative_error'],flush=True)
report['protocol']='Per-frame scale/shift fitted on 80% of sparse COLMAP tracks; remaining 20% evaluated with a fixed seed. Cameras and all images are shared inputs. This measures agreement with SfM, not independent metric accuracy or held-out novel-view quality.'
(R/'calibration/depth_benchmark.json').write_text(json.dumps(report,indent=2))
