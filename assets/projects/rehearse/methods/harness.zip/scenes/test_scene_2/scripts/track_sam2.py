import os,sys
os.environ.update(KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R.parents[1]/'third_party/sam2'))
import torch,numpy as np,cv2,json,time
from sam2.build_sam import build_sam2_video_predictor
torch.set_num_threads(4);frames=R/'calibration/sam2_frames';frames.mkdir(exist_ok=True)
for i,p in enumerate(sorted((R/'source/frames').glob('*.jpg'))):
 q=frames/f'{i:05d}.jpg'
 if not q.exists():q.symlink_to(p)
model=build_sam2_video_predictor('configs/sam2.1/sam2.1_hiera_t.yaml',str(R.parents[1]/'models/sam2.1/sam2.1_hiera_tiny.pt'),device='cpu',apply_postprocessing=False);out=R/'calibration/sam2_masks';out.mkdir(exist_ok=True);names=['table','chair_left','chair_right','backpack','laptop','cup'];start=time.time()
with torch.inference_mode():
 state=model.init_state(str(frames),offload_video_to_cpu=True,offload_state_to_cpu=True)
 # One shared mid-sequence prompt frame, then propagate both temporal directions.
 for i,name in enumerate(names):
  mask=cv2.imread(str(R/f'calibration/masks/frame_0013_{name}.png'),0)>127
  if name=='table':
   for other in ['cup','laptop']:mask &= ~(cv2.imread(str(R/f'calibration/masks/frame_0013_{other}.png'),0)>127)
  model.add_new_mask(state,frame_idx=12,obj_id=i+1,mask=mask)
 stats={}
 for reverse in [False,True]:
  for frame,ids,logits in model.propagate_in_video(state,start_frame_idx=12,reverse=reverse):
   entry={}
   for j,obj_id in enumerate(ids):
    mask=(logits[j,0]>0).cpu().numpy().astype('uint8')*255;name=names[obj_id-1];cv2.imwrite(str(out/f'frame_{frame+1:04d}_{name}.png'),mask);entry[name]=int((mask>0).sum())
   stats[frame]=entry;print('frame',frame,'elapsed',round(time.time()-start,1),flush=True)
report={'model':'SAM 2.1 Hiera Tiny','device':'CPU float32','seconds':time.time()-start,'frames':len(stats),'objects':names,'prompt':'SAM ViT-B masks at frame 13, propagated forward and backward','pixel_counts':stats};(R/'calibration/sam2_tracking.json').write_text(json.dumps(report,indent=2))
