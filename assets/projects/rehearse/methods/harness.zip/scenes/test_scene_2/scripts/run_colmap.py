from pathlib import Path
import pycolmap,json,time
R=Path(__file__).resolve().parents[1];out=R/'calibration/colmap';out.mkdir(exist_ok=True);db=out/'database.db'
start=time.time()
if not db.exists():
 opts=pycolmap.FeatureExtractionOptions();opts.num_threads=6;opts.sift.max_num_features=12000
 pycolmap.extract_features(db,R/'source/frames',camera_mode=pycolmap.CameraMode.SINGLE,reader_options={'camera_model':'SIMPLE_RADIAL'},extraction_options=opts,device=pycolmap.Device.cpu)
 mo=pycolmap.FeatureMatchingOptions();mo.num_threads=6;mo.guided_matching=True
 pycolmap.match_exhaustive(db,matching_options=mo,device=pycolmap.Device.cpu)
opts=pycolmap.IncrementalPipelineOptions();opts.num_threads=6
maps=pycolmap.incremental_mapping(db,R/'source/frames',out/'sparse',options=opts)
if not maps:raise RuntimeError('No reconstruction')
best=max(maps.values(),key=lambda r:r.num_reg_images());(out/'best').mkdir(exist_ok=True);best.write(out/'best');best.write_text(out/'best')
report={'method':'COLMAP incremental SfM CPU','registered_frames':best.num_reg_images(),'sparse_points':best.num_points3D(),'mean_reprojection_error_px':best.compute_mean_reprojection_error(),'elapsed_s':time.time()-start}
(R/'calibration/sfm_report.json').write_text(json.dumps(report,indent=2));print(report)
