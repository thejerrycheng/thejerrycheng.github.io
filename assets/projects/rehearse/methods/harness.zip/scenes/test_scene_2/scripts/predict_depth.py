from pathlib import Path
import os
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4')
import numpy as np,torch,cv2,json,time
from PIL import Image
from transformers import AutoImageProcessor,AutoModelForDepthEstimation
R=Path(__file__).resolve().parents[1];modelpath=R.parents[1]/'models/depth-anything-v2-small'
torch.set_num_threads(4);processor=AutoImageProcessor.from_pretrained(str(modelpath),local_files_only=True);model=AutoModelForDepthEstimation.from_pretrained(str(modelpath),local_files_only=True).eval();start=time.time()
for i,p in enumerate(sorted((R/'source/frames').glob('*.jpg'))):
 dest=R/'calibration'/f'depth_{p.stem}.npy'
 if dest.exists():continue
 im=Image.open(p)
 with torch.no_grad():d=model(**processor(images=im,return_tensors='pt')).predicted_depth
 d=torch.nn.functional.interpolate(d[:,None],size=(720,960),mode='bilinear',align_corners=False)[0,0].numpy();np.save(dest,d)
 print(p.name,'time',round(time.time()-start,1),flush=True)
(R/'calibration/depth_runtime.json').write_text(json.dumps({'model':'Depth-Anything-V2-Small-hf','device':'CPU','seconds':time.time()-start,'frames':31},indent=2))
