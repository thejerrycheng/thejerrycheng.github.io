from pathlib import Path
import numpy as np,json,shutil
R=Path(__file__).resolve().parents[1];out=R.parents[1]/'website/assets/projects/rehearse/scene2';out.mkdir(exist_ok=True)
for src,dst in [('assets/scene.glb','scene.glb'),('assets/objects.json','objects.json'),('calibration/cameras.json','cameras.json'),('calibration/depth_benchmark.json','depth-benchmark.json'),('calibration/sfm_report.json','sfm-report.json')]:shutil.copy2(R/src,out/dst)
a=np.load(R/'calibration/dense_world.npz');idx=np.arange(0,len(a['xyz']),max(1,len(a['xyz'])//160000));data=np.c_[a['xyz'][idx],a['rgb'][idx]/255,a['first_seen'][idx]].astype('float32');data.tofile(out/'observations.bin');(out/'observations.json').write_text(json.dumps({'count':len(data),'stride':7,'format':'little-endian float32 x y z r g b first_seen_seconds','voxel_m':.008,'subsampled':True}))
