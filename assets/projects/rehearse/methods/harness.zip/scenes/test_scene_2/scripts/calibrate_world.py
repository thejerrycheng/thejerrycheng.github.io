from pathlib import Path
import pycolmap,numpy as np,cv2,json
R=Path(__file__).resolve().parents[1];rec=pycolmap.Reconstruction(R/'calibration/colmap/best');images={im.name:im for im in rec.images.values()};cam=next(iter(rec.cameras.values()));K=cam.calibration_matrix();f=K[0,0];dist=np.array([cam.params[3],0,0,0,0])
# Manual corresponding landmarks: table front top corners and cup ring centers.
# Frame 1 captures the front-facing table rectangle clearly.
# Fit ground normal from tracked carpet points outside objects in frame 13.
im=images['frame_0013.jpg'];floorpoly=np.array([[5,365],[322,400],[340,473],[150,720],[5,720]])
ids=[]
for pt in im.points2D:
 if pt.has_point3D() and cv2.pointPolygonTest(floorpoly,tuple(pt.xy.astype(float)),False)>=0:ids.append(pt.point3D_id)
X=np.array([rec.points3D[i].xyz for i in ids]);rng=np.random.default_rng(4);best=[]
for _ in range(3000):
 a,b,c=X[rng.choice(len(X),3,replace=False)];n=np.cross(b-a,c-a);n/=max(np.linalg.norm(n),1e-10);d=-n@a;inl=np.where(abs(X@n+d)<.08)[0]
 if len(inl)>len(best):best=inl
p=X[best].mean(0);_,_,V=np.linalg.svd(X[best]-p);normal=V[-1];C=images['frame_0001.jpg'].projection_center()
if normal@(C-p)<0:normal=-normal
# Triangulate manual table corners across frames 1 and 19 and estimate scale from ground-to-table distance.
def triang(points):
 A=[]
 for name,xy in points:
  im=images[name];norm=cam.cam_from_img(np.array(xy,dtype=float));P=im.cam_from_world().matrix();A.extend([norm[0]*P[2]-P[0],norm[1]*P[2]-P[1]])
 _,_,v=np.linalg.svd(A);return v[-1,:3]/v[-1,3]
# Use feature-supported table face corners in frames 1 and 19; inspected annotations saved separately.
# Coordinates for frame 19 are read in a later fitting pass.
# Cup height from frame 1 base and lid: use local 3D points near rim for depth.
pts=[]
for pt in images['frame_0001.jpg'].points2D:
 if pt.has_point3D() and 620<pt.xy[0]<687 and 280<pt.xy[1]<379:pts.append(rec.points3D[pt.point3D_id].xyz)
print('floor points',len(X),'floor inliers',len(best),'normal',normal,'floorpoint',p,'cup points',len(pts))
np.savez(R/'calibration/world_init.npz',floor_normal=normal,floor_point=p,floor_points=X[best],cup_points=pts)
# Export raw camera and sparse data for calibrated asset creation.
cs=[]
for name,im in sorted(images.items()):
 T=im.cam_from_world().matrix();cs.append({'name':name,'time':(int(name[6:10])-1)*.5+.25,'R':T[:,:3].tolist(),'t':T[:,3].tolist(),'position':im.projection_center().tolist()})
(R/'calibration/raw_cameras.json').write_text(json.dumps({'K':K.tolist(),'distortion':dist.tolist(),'cameras':cs},indent=2))
np.savez(R/'calibration/sparse_raw.npz',xyz=np.array([p.xyz for p in rec.points3D.values()]),rgb=np.array([p.color for p in rec.points3D.values()]),ids=np.array(list(rec.points3D)))
