import os
os.environ.update(KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'third_party/numpy126'))
import numpy as np,json
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text())
import open3d as o3d
print("open3d ready",np.__version__,flush=True)
vol=o3d.pipelines.integration.ScalableTSDFVolume(voxel_length=.01,sdf_trunc=.06,color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8)
for i,c in enumerate(cal['cameras']):
 print('integrating',i,flush=True)
 a=np.load(R/f'calibration/fused_input_{i:02d}.npz');d=a['depth'].copy();d[~a['valid']]=0;K=a['K'];h,w=d.shape
 rgbd=o3d.geometry.RGBDImage.create_from_color_and_depth(o3d.geometry.Image(a['rgb']),o3d.geometry.Image(d),depth_scale=1.,depth_trunc=10,convert_rgb_to_intensity=False)
 ext=np.eye(4);ext[:3,:3]=c['R_world_to_cv'];ext[:3,3]=c['t_world_to_cv'];intr=o3d.camera.PinholeCameraIntrinsic(w,h,K[0,0],K[1,1],K[0,2],K[1,2]);vol.integrate(rgbd,intr,ext)
mesh=vol.extract_triangle_mesh();mesh.remove_degenerate_triangles();mesh.remove_duplicated_vertices();mesh.remove_duplicated_triangles();mesh.compute_vertex_normals();o3d.io.write_triangle_mesh(str(R/'assets/fused_scene.ply'),mesh);print('mesh',len(mesh.vertices),len(mesh.triangles),flush=True)
