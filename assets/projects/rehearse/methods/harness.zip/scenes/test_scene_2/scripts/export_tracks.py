from pathlib import Path
import cv2,numpy as np,json
R=Path(__file__).resolve().parents[1];out=R.parents[1]/'website/assets/projects/rehearse/scene2';names=['table','chair_left','chair_right','backpack','laptop','cup'];colors=[[0,113,227],[50,160,120],[201,115,39],[173,88,193],[64,135,183],[220,92,96]];frames=[];agreement={n:[] for n in names}
for i in range(31):
 objects=[];im=cv2.imread(str(R/f'source/frames/frame_{i+1:04d}.jpg'));overlay=im.copy()
 for j,n in enumerate(names):
  mask=cv2.imread(str(R/f'calibration/sam2_masks/frame_{i+1:04d}_{n}.png'),0);contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);polygons=[cv2.approxPolyDP(c,2.5,True)[:,0].tolist() for c in contours if cv2.contourArea(c)>50];objects.append({'name':n,'polygons':polygons});overlay[mask>127]=(overlay[mask>127]*.65+np.array(colors[j][::-1])*.35).astype('uint8');cv2.drawContours(overlay,contours,-1,colors[j][::-1],2)
  source=R/f'calibration/masks/frame_{i+1:04d}_{n}.png'
  if source.exists() and i!=12:
   a=cv2.imread(str(source),0)>127;b=mask>127;agreement[n].append({'frame':i,'mask_iou_with_independent_box_prompted_sam':float((a&b).sum()/max(1,(a|b).sum()))})
 frames.append({'time':.25+i*.5,'objects':objects})
 if i in [0,12,24,30]:cv2.imwrite(str(R/f'renders/tracking_{i:02d}.jpg'),overlay)
(out/'tracks.json').write_text(json.dumps({'model':'SAM 2.1 Hiera Tiny','prompt_frame':12,'resolution':[960,720],'colors':colors,'names':names,'frames':frames},separators=(',',':')));report={'protocol':'Agreement with separately box-prompted SAM ViT-B keyframe masks, excluding the shared prompt frame. This is model agreement, not ground-truth segmentation accuracy.','per_object':agreement};(R/'calibration/tracking_agreement.json').write_text(json.dumps(report,indent=2));(out/'tracking-agreement.json').write_text(json.dumps(report,indent=2));print({n:round(np.mean([x['mask_iou_with_independent_box_prompted_sam'] for x in a]),3) for n,a in agreement.items()})
