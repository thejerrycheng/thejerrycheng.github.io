import os
os.environ.update(KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import numpy as np,cv2,json,pycolmap,time,argparse
p=argparse.ArgumentParser();p.add_argument('--variant',default='da3');args=p.parse_args()
from scipy.optimize import least_squares
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text());rec=pycolmap.Reconstruction(R/'calibration/colmap/best');ims={im.name:im for im in rec.images.values()};s=cal['scale_m_per_sfm_unit'];B=np.array(cal['raw_to_world_rotation']);origin=np.array(cal['origin_raw']);frames={}
for p in sorted((R/('calibration/'+args.variant)).glob('batch_*.npz')):
 a=np.load(p)
 for j,i in enumerate(a['indices']):frames.setdefault(int(i),[]).append((a['depth'][j],a['conf'][j],a['intrinsics'][j]))
report=[];clouds=[];colors=[];times=[];depths=[]
for i in sorted(frames):
 c=cal['cameras'][i];items=frames[i];d=np.mean([x[0] for x in items],axis=0);confidence=np.mean([x[1] for x in items],axis=0);H,W=d.shape;K=items[0][2];Rcv=np.array(c['R_world_to_cv']);tcv=np.array(c['t_world_to_cv']);C=np.array(c['position']); im=ims[c['name']]
 # Fit residual depth scale/shift to robust COLMAP tracks and report agreement.
 vals=[];truth=[]
 for pt in im.points2D:
  if not pt.has_point3D():continue
  X=(rec.points3D[pt.point3D_id].xyz-origin)@B.T*s;z=(Rcv@X+tcv)[2];u,v=pt.xy*np.array([W/960,H/720]);u,v=round(u),round(v)
  if 0<=u<W and 0<=v<H and .2<z<12:vals.append(d[v,u]);truth.append(z)
 vals=np.array(vals);truth=np.array(truth);ok=(vals>.1)&(truth>0)&(abs(vals-truth)/truth<.5)
 fit=least_squares(lambda p:(vals[ok]*p[0]+p[1]-truth[ok])/np.maximum(truth[ok],.5),[1,0],bounds=([.5,-.5],[2,.5]),loss='soft_l1',f_scale=.03)
 d=(d*fit.x[0]+fit.x[1]).astype('float32');d[~np.isfinite(d)]=0;d[(d<.2)|(d>10)]=0
 rgb=cv2.cvtColor(cv2.resize(cv2.imread(str(R/'source/frames'/c['name'])),(W,H)),cv2.COLOR_BGR2RGB)
 # Keep stable depth; SAM semantics are applied after fusion, preserving source boundaries.
 gy,gx=np.mgrid[:H,:W];ray=np.stack([(gx-K[0,2])/K[0,0],(gy-K[1,2])/K[1,1],np.ones_like(gx)],-1);X=C+(ray*d[:,:,None])@Rcv
 valid=(d>.2)&(confidence>0)&(X[:,:,2]>-.06)&(X[:,:,2]<3.3)&(X[:,:,0]>-4)&(X[:,:,0]<3)&(X[:,:,1]>-2)&(X[:,:,1]<5)
 np.savez_compressed(R/f'calibration/fused_input_{i:02d}.npz',depth=d,confidence=confidence,K=K,rgb=rgb,valid=valid)
 clouds.append(X[valid]);colors.append(rgb[valid]);times.append(np.full(valid.sum(),c['time']))
 report.append({'frame':c['name'],'depth_scale_correction':float(fit.x[0]),'depth_shift_correction_m':float(fit.x[1]),'median_relative_depth_error_to_sfm':float(np.median(abs(vals[ok]*fit.x[0]+fit.x[1]-truth[ok])/truth[ok])),'retained_pixels':int(valid.sum())})
 print(c['name'],report[-1],flush=True)
X=np.concatenate(clouds);col=np.concatenate(colors);t=np.concatenate(times)
# First-observation voxel selection makes accumulated-map replay stable and deterministic.
vox=np.floor(X/.008).astype(int);_,ix=np.unique(vox,axis=0,return_index=True);ix=ix[np.argsort(t[ix])];np.savez_compressed(R/'calibration/dense_world.npz',xyz=X[ix].astype('float32'),rgb=col[ix],first_seen=t[ix].astype('float32'))
(R/'calibration/depth_fusion_report.json').write_text(json.dumps(report,indent=2));print('dense points',len(ix),flush=True)
