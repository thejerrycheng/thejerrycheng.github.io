import os
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0')
from pathlib import Path
import torch,numpy as np,cv2,json,time
from PIL import Image
from transformers import SamModel,SamProcessor
R=Path(__file__).resolve().parents[1];torch.set_num_threads(4);p=SamProcessor.from_pretrained(str(R.parents[1]/'models/sam-vit-base'));m=SamModel.from_pretrained(str(R.parents[1]/'models/sam-vit-base')).eval();ann=json.loads((R/'calibration/annotations.json').read_text());out=R/'calibration/masks';out.mkdir(exist_ok=True)
boxes={
1:{'laptop':[356,208,656,451],'cup':[625,276,688,383],'table':[333,287,789,720],'backpack':[36,538,348,719],'chair_right':[376,176,602,288],'chair_left':[0,191,72,430],'whiteboard':[394,0,493,187]},
7:{'laptop':[36,328,481,719],'cup':[490,511,587,652],'table':[47,335,659,719],'backpack':[0,546,140,719],'chair_right':[399,73,752,453],'chair_left':[0,21,160,395],'whiteboard':[576,0,738,85]},
13:ann['frame_0013.jpg'],
19:{'laptop':[414,110,659,343],'cup':[647,174,704,264],'table':[407,163,780,555],'backpack':[203,383,431,550],'chair_right':[466,24,668,184],'chair_left':[0,49,210,358],'whiteboard':[447,0,632,78]},
25:{**ann['frame_0025.jpg'],'charger':[325,548,396,620]},
28:{'laptop':[0,172,425,710],'cup':[470,303,581,482],'table':[0,155,749,720],'chair_right':[28,0,375,243]},
}
report={};start=time.time()
for frame,objects in boxes.items():
 objects={k:v for k,v in objects.items() if k in ['table','laptop','cup','chair_left','chair_right','backpack','whiteboard','charger']};name=f'frame_{frame:04d}';im=Image.open(R/f'source/frames/{name}.jpg');inputs=p(im,input_boxes=[list(objects.values())],return_tensors='pt')
 with torch.no_grad():o=m(**inputs,multimask_output=True)
 masks=p.image_processor.post_process_masks(o.pred_masks,inputs['original_sizes'],inputs['reshaped_input_sizes'])[0];overlay=np.array(im).copy();report[name]={}
 for i,key in enumerate(objects):
  j=int(o.iou_scores[0,i].argmax());mask=masks[i,j].numpy().astype('uint8')*255;cv2.imwrite(str(out/f'{name}_{key}.png'),mask);report[name][key]={'predicted_iou':float(o.iou_scores[0,i,j]),'pixels':int((mask>0).sum()),'prompt_box':objects[key]};color=np.array([(i*79)%255,(i*137)%255,230]);overlay[mask>0]=(overlay[mask>0]*.55+color*.45).astype('uint8')
 cv2.imwrite(str(out/f'{name}_overlay.jpg'),cv2.cvtColor(overlay,cv2.COLOR_RGB2BGR));print(name,report[name],round(time.time()-start,1),flush=True)
(R/'calibration/segmentation_report.json').write_text(json.dumps(report,indent=2))
