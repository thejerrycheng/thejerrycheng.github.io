"""Fitted solids for planar/table/cup surfaces; dimensions remain provisional."""
import numpy as np,trimesh,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def gridquad(corners,n=16):
 c=np.asarray(corners);v=[];f=[]
 for j in range(n+1):
  for i in range(n+1):
   u=i/n;w=j/n;v.append((1-u)*(1-w)*c[0]+u*(1-w)*c[1]+u*w*c[2]+(1-u)*w*c[3])
 for j in range(n):
  for i in range(n):
   k=j*(n+1)+i;f.extend([[k,k+1,k+n+2],[k,k+n+2,k+n+1]])
 return trimesh.Trimesh(v,f,process=False)
def planez(x,y):return -.08607166*x-.011*y

def fitted_base_corners():
 # Manually reviewed keyboard corners in frame_0013, projected onto its fitted
 # plane. This replaces an oversized rectangle whose edges sampled carpet.
 cal=json.loads((R/'calibration/cameras.json').read_text());c=cal['cameras'][12];K=np.array(cal['K']);r=np.array(c['R_world_to_cv']);t=np.array(c['t_world_to_cv']);origin=-r.T@t
 pixels=np.array([[346,517],[573,562],[592,451],[393,416]],float);rays=np.c_[pixels,np.ones(4)]@np.linalg.inv(K).T@r;n=np.array([.08607166,.011,1]);distance=(.581-origin@n)/(rays@n)
 return origin+rays*distance[:,None]

def fitted_lid_corners():
 lm=json.loads((R/'calibration/cameras.json').read_text())['landmarks'];q=np.array([lm[k] for k in ['laptop_lid_bl','laptop_lid_br','laptop_lid_tr','laptop_lid_tl']])
 # Regularize the hinge to the keyboard plane, with thickness clearance.
 # Original triangulated edge is inside the base: retain it as source evidence,
 # but use an explicitly fitted mechanical edge for the articulated asset.
 q[:2,2]=planez(q[:2,0],q[:2,1])+.581+.015
 return q

def solids():
 out={};lo=-.34;hi=.358;front=-.37;back=.35;height=.552
 bottom=np.array([[lo,front,-.075],[hi,front,-.075],[hi,back,-.075],[lo,back,-.075]]);top=bottom.copy();top[:,2]=planez(top[:,0],top[:,1])+height
 out['table_top']=('table',gridquad(top),31)
 out['table_bottom']=('table',gridquad(bottom[::-1]),None)
 for i in range(4):out[f'table_side_{i}']=('table',gridquad([bottom[i],bottom[(i+1)%4],top[(i+1)%4],top[i]]),None)
 # Fitted screen quadrilateral from multiview landmarks; base follows table plane.
 cal=json.loads((R/'calibration/cameras.json').read_text());lm=cal['landmarks'];corners=fitted_lid_corners()
 out['laptop_lid']=('laptop',gridquad(corners),12)
 base=fitted_base_corners()
 out['laptop_base']=('laptop',gridquad(base),12)
 # Close the thin keyboard and display shells. Their hidden surfaces are inferred.
 for key,q in [('laptop_lid',corners),('laptop_base',base)]:
  normal=np.cross(q[1]-q[0],q[3]-q[0]);normal/=np.linalg.norm(normal);back=q-normal*.012
  out[key+'_back']=('laptop',gridquad(back[::-1]),None)
  for i in range(4):out[key+f'_edge_{i}']=('laptop',gridquad([q[i],back[i],back[(i+1)%4],q[(i+1)%4]],16),None)
 # Closed continuous coffee shell + connected lid, owned by a single rigid body.
 center=np.array([.204,-.18,planez(.204,-.18)+height]);N=96;v=[];f=[]
 for z,r in [(0,.032),(.012,.033),(.148,.044),(.156,.044),(.156,.046),(.168,.046)]:
  for a in np.arange(N)*2*np.pi/N:v.append(center+[r*np.cos(a),r*np.sin(a),z])
 for j in range(5):
  for i in range(N):k=j*N+i;l=j*N+(i+1)%N;f.extend([[k,l,l+N],[k,l+N,k+N]])
 v.extend([center,center+[0,0,.168]])
 for i in range(N):f.extend([[6*N,(i+1)%N,i],[6*N+1,5*N+i,5*N+(i+1)%N]])
 out['cup']=('cup',trimesh.Trimesh(v,f,process=False),None)
 # Inferred continuous floor follows the structural plane, textured from clean plate.
 # The recovered camera's upper-left rays hit the floor near x=-8, y=10.
 # The earlier display extent (-3.8..1.2, y<=5) clipped observed floor coverage.
 # Extend the fitted plane; appearance outside observed pixels remains inferred.
 out['floor']=('background',gridquad([[-12,-3,-.075],[3,-3,-.075],[3,16,-.075],[-12,16,-.075]],160),32)
 return out

def hinge_config(laptop_position):
 lm=json.loads((R/'calibration/cameras.json').read_text())['landmarks'];q=fitted_lid_corners();h=(q[0]+q[1])/2;axis=q[1]-q[0];axis/=np.linalg.norm(axis);rest=(q[2]+q[3])/2-h;rest-=axis*(rest@axis);rest/=np.linalg.norm(rest)
 base=fitted_base_corners()
 target=(base[0]+base[1])/2-h;target-=axis*(target@axis);target/=np.linalg.norm(target);closed=float(np.arctan2(axis@np.cross(rest,target),rest@target));assert closed>0
 bottom=np.array([[-.34,-.37,-.075],[.358,-.37,-.075],[.358,.35,-.075],[-.34,.35,-.075]]);top=bottom.copy();top[:,2]=planez(top[:,0],top[:,1])+.552
 return {'file':'laptop_lid.obj','hinge_world':h.tolist(),'axis':axis.tolist(),'corners_local':(q-h).tolist(),'base_corners_local':(base-np.array(laptop_position)).tolist(),'table_corners_world':np.r_[bottom,top].tolist(),'closed_rotation':closed,'min_rotation':closed-np.deg2rad(165),'max_rotation':closed,'captured_open_angle_degrees':float(np.rad2deg(closed)),'convention':'Positive rotation closes the lid toward the keyboard. Collision stops may engage before the nominal closed limit.'}
