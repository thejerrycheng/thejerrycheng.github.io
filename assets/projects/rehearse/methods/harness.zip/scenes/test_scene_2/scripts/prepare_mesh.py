"""Decimate the fused surface and assign object ownership using visible SAM labels."""
import os
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'third_party/numpy126'))
import numpy as np,cv2,json,trimesh
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text())
m=trimesh.load(R/'assets/fused_scene.ply',process=False);print('loaded',len(m.faces),flush=True)
m=m.simplify_quadric_decimation(face_count=180000);print('decimated',len(m.faces),flush=True)
X=m.triangles_center;norm=m.face_normals;names=['background','table','whiteboard','chair_left','chair_right','backpack','laptop','cup','charger'];votes=np.zeros((len(X),len(names)),np.float32)
for i in [0,6,12,18,24,27]:
 c=cal['cameras'][i];a=np.load(R/f'calibration/fused_input_{i:02d}.npz');K=np.array(cal['K']);z=X@np.array(c['R_world_to_cv']).T+np.array(c['t_world_to_cv']);uv=z[:,:2]/z[:,2:]*[K[0,0],K[1,1]]+[480,360];u,v=np.round(uv).astype(int).T;ok=(z[:,2]>.1)&(u>=0)&(u<960)&(v>=0)&(v<720);ix=np.where(ok)[0];d=a['depth'];h,w=d.shape;di=d[np.minimum((v[ix]*h/720).astype(int),h-1),np.minimum((u[ix]*w/960).astype(int),w-1)];ix=ix[abs(z[ix,2]-di)<.08]
 labels=np.zeros((720,960),np.uint8)
 for j,name in enumerate(names[1:],1):
  p=R/f'calibration/masks/{Path(c["name"]).stem}_{name}.png'
  if p.exists():labels[cv2.imread(str(p),0)>127]=j
 # Grazing/occluded observations contribute less. SAM is semantic evidence, not geometry.
 weights=np.maximum(.1,abs((norm[ix]*(np.array(c['position'])-X[ix])).sum(1))/np.linalg.norm(np.array(c['position'])-X[ix],axis=1))
 np.add.at(votes,(ix,labels[v[ix],u[ix]]),weights)
labels=votes.argmax(1)
# Remove implausible semantic fragments far from the working area.
priors={'cup':([.07,-.31,.47],[.32,-.04,.8]),'laptop':([-.43,-.48,.47],[.43,.12,.97]),'table':([-.6,-.65,-.05],[.55,.5,.72]),'backpack':([-1.15,-.6,-.04],[-.38,.25,.4]),'chair_left':([-2.2,.3,-.06],[-.7,1.9,1.15]),'chair_right':([-.2,.3,-.06],[1.0,1.8,1.15])}
for name,(lo,hi) in priors.items():labels[(labels==names.index(name))&(~((X>=lo)&(X<=hi)).all(1))]=0
np.savez_compressed(R/'assets/labeled_mesh.npz',vertices=m.vertices.astype('float32'),faces=m.faces.astype('int32'),labels=labels.astype('uint8'),names=names)
print({n:int((labels==i).sum()) for i,n in enumerate(names)},flush=True)
