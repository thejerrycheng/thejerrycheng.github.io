import bpy,json,sys
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text());(R/'renders').mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=4;s.render.resolution_x=960;s.render.resolution_y=720;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard';s.world.color=(.65,.65,.65)
bpy.ops.import_mesh.ply(filepath=str(R/'assets/fused_scene.ply'));o=bpy.context.object
m=bpy.data.materials.new('Captured appearance');m.use_nodes=True;n=m.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');sh=n.new('ShaderNodeEmission');c=n.new('ShaderNodeVertexColor');c.layer_name=o.data.vertex_colors[0].name;m.node_tree.links.new(c.outputs['Color'],sh.inputs['Color']);m.node_tree.links.new(sh.outputs[0],out.inputs['Surface']);o.data.materials.append(m)
for c in cal['cameras']:
 bpy.ops.object.camera_add(location=c['position']);cam=bpy.context.object;cam.name=c['name'];cam.rotation_euler=Matrix(c['rotation_camera_to_world_opengl']).to_euler();cam.data.sensor_fit='HORIZONTAL';cam.data.sensor_width=36;cam.data.lens=cal['K'][0][0]/960*36;cam.data.clip_start=.01
for i in [0,12,24]:
 s.camera=bpy.data.objects[cal['cameras'][i]['name']];s.render.filepath=str(R/f'renders/fused_{i:02d}.png');bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'scene.blend'))
