"""Bake measured photo appearance onto fused surfaces; object-local meshes share one atlas."""
import os
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
import numpy as np,cv2,json,trimesh
from PIL import Image
from solid_assets import solids,planez,hinge_config,fitted_lid_corners
R=Path(__file__).resolve().parents[1];a=np.load(R/'assets/labeled_mesh.npz');cal=json.loads((R/'calibration/cameras.json').read_text());V=a['vertices'];F=a['faces'];labels=a['labels'];names=a['names'];mesh=trimesh.Trimesh(V,F,process=False);X=mesh.triangles_center
keep=~np.isin(labels,[1,6,7]);keep &= ~((labels==0)&(X[:,2]<.10))
# Exclude all measured surface fragments occupying replaced solids, including missed SAM pixels.
keep &= ~((X[:,0]>-.43)&(X[:,0]<.42)&(X[:,1]>-.46)&(X[:,1]<.39)&(X[:,2]>planez(X[:,0],X[:,1])+.02)&(X[:,2]<.9))
labels=labels[keep];F=F[keep];preferred=np.full(len(F),-1,int);solid_names=np.full(len(F),'scan',object)
for key,(owner,part,pref) in solids().items():
 F=np.r_[F,part.faces+len(V)];V=np.r_[V,part.vertices];labels=np.r_[labels,np.full(len(part.faces),list(names).index(owner))];preferred=np.r_[preferred,np.full(len(part.faces),-1 if pref is None else pref)];solid_names=np.r_[solid_names,np.full(len(part.faces),key,object)]
mesh=trimesh.Trimesh(V,F,process=False);X=mesh.triangles_center;N=mesh.face_normals;best=np.full(len(F),-1e6);views=np.zeros(len(F),int);uv=np.zeros((len(F),3,2));K=np.array(cal['K']);atlas=Image.new('RGB',(960*8,720*5),(160,158,150))
for index,c in enumerate(cal['cameras']+[cal['cameras'][12],cal['cameras'][12]]):
 i=index if index<31 else 12
 im=Image.open(R/'source/frames'/c['name']) if index<31 else Image.open(R/('assets/generated_clean_table.png' if index==31 else 'assets/generated_clean_floor.png')).resize((960,720));atlas.paste(im,(index%8*960,index//8*720));r=np.array(c['R_world_to_cv']);t=np.array(c['t_world_to_cv']);P=V[F]@r.T+t;xy=P[:,:,:2]/np.maximum(P[:,:,2:],1e-6)*[K[0,0],K[1,1]]+[480,360];ok=(P[:,:,2]>.1).all(1)&(xy[:,:,0]>=2).all(1)&(xy[:,:,0]<958).all(1)&(xy[:,:,1]>=2).all(1)&(xy[:,:,1]<718).all(1);ids=np.where(ok)[0]
 dep=np.load(R/f'calibration/fused_input_{i:02d}.npz')['depth'];h,w=dep.shape;mid=xy[ids].mean(1);d=dep[(mid[:,1]*h/720).astype(int),(mid[:,0]*w/960).astype(int)];err=abs(P[ids,:,2].mean(1)-d);direction=np.array(c['position'])-X[ids];dist=np.linalg.norm(direction,axis=1);inc=abs((direction*N[ids]).sum(1))/dist;score=inc/np.maximum(dist,.25)**.6-err*12;score[err>.13]-=10
 score+=1.5*(i==12)
 # Appearance ownership is separate from geometric ownership: never bake a
 # foreground object's photograph onto another body or the static room.
 if index<31:
  pixel=np.round(mid).astype(int);sample_masks={}
  for owner in ['table','chair_left','chair_right','backpack','laptop','cup']:
   mp=R/f'calibration/sam2_masks/{c["name"].replace(".jpg", "")}_{owner}.png'
   mm=cv2.imread(str(mp),0)
   if mm is not None:sample_masks[owner]=mm[pixel[:,1],pixel[:,0]]>127
  foreground=np.zeros(len(ids),bool)
  for owner,m in sample_masks.items():
   owned=labels[ids]==list(names).index(owner);score[owned&~m]=-1e7
   # Closed completed surfaces only receive a photo from their outward side.
   # Back faces must not acquire the visible front's photograph through the object.
   if owner in ['chair_left','chair_right','backpack']:
    facing=(direction*N[ids]).sum(1)/dist
    score[owned&(facing<.03)]=-1e7
   if owner!='table':foreground|=m
  score[np.isin(labels[ids],[list(names).index(n) for n in ['background','whiteboard','charger']])&foreground]=-1e7
 forced=preferred[ids]>=0
 if index>=31:
  score[:]=-1e7;score[preferred[ids]==index]=100
 else:
  score[forced & (preferred[ids]!=index)]-=1e5
  score[preferred[ids]==index]+=100
 # Never project the structural column onto the inferred carpet.
 if index==32:score[(mid[:,0]>790)|(mid[:,1]<12)]=-1e7
 update=score>best[ids];ids=ids[update];best[ids]=score[update];views[ids]=index;uv[ids]=xy[ids]
 print('bake',i,'assigned',len(ids),flush=True)
floor_ids=np.where(preferred==32)[0];c=cal['cameras'][12];r=np.array(c['R_world_to_cv']);t=np.array(c['t_world_to_cv']);P=V[F[floor_ids]]@r.T+t;xy=P[:,:,:2]/np.maximum(P[:,:,2:],1e-6)*[K[0,0],K[1,1]]+[480,360];mid=xy.mean(1);valid=(P[:,:,2]>.01).all(1)&(mid[:,0]>-20)&(mid[:,0]<790)&(mid[:,1]>12)&(mid[:,1]<740);ids=floor_ids[valid];uv[ids]=np.clip(xy[valid],[2,2],[957,717]);views[ids]=32;best[ids]=100
# The manually reviewed top quadrilateral is entirely inside the keyboard.
# Preserve its continuous reference projection across all triangle boundaries.
ids=np.where(solid_names=='laptop_base')[0];P=V[F[ids]]@r.T+t;uv[ids]=P[:,:,:2]/P[:,:,2:]*[K[0,0],K[1,1]]+[480,360];views[ids]=12;best[ids]=100
missing=(preferred==32)&(best<0);mid=X[missing];patch=V[F[missing]];uv[missing]=np.stack([300+(patch[:,:,0]%.5)/.5*100,50+(patch[:,:,1]%.5)/.5*100],axis=-1);views[missing]=32;best[missing]=0
white=(labels==list(names).index('cup'))&(X[:,2]<planez(.204,-.18)+.552+.012);uv[white]=[480,360];views[white]=33;best[white]=100;atlas.paste(Image.new('RGB',(960,720),(226,223,212)),(960,2880))
# Fit smooth captured illumination on planar table sides. Projecting the source
# silhouette onto an approximate plane otherwise creates a saw-tooth carpet edge.
for side in range(4):
 ids=np.where(solid_names==f'table_side_{side}')[0];axes=[0 if side%2==0 else 1,2];p=V[F[ids]][:,:,axes];lo=p.reshape(-1,2).min(0);span=np.maximum(p.reshape(-1,2).max(0)-lo,1e-6);coords=(X[ids][:,axes]-lo)/span;good=best[ids]>-1e5;rgb=[]
 for fi in ids[good]:
  pixel=uv[fi].mean(0).astype(int);rgb.append(atlas.getpixel((int(pixel[0]+views[fi]%8*960),int(pixel[1]+views[fi]//8*720))))
 if len(rgb)>12:
  rgb=np.array(rgb,float);A=np.c_[coords[good],np.ones(good.sum())];valid=np.ones(len(A),bool)
  for _ in range(4):
   coef=np.linalg.lstsq(A[valid],rgb[valid],rcond=None)[0];res=np.linalg.norm(A@coef-rgb,axis=1);valid=res<max(15,np.median(res)*2.5)
  yy,xx=np.mgrid[:720,:960];colors=np.c_[xx.ravel()/959,yy.ravel()/719,np.ones(960*720)]@coef;tile=np.clip(colors,50,235).reshape(720,960,3).astype('uint8')
 else:tile=np.full((720,960,3),[161,160,155],np.uint8)
 slot=35+side;atlas.paste(Image.fromarray(tile),(slot%8*960,slot//8*720));uv[ids]=(p-lo)/span*[959,719];views[ids]=slot;best[ids]=100
# Preserve every owned face. Unseen surfaces receive an explicit inferred
# neutral material; lack of a source-view UV must never punch geometry holes.
# Thin laptop edges are below reliable mask/geometry precision. A fitted metal
# finish avoids projecting alternating carpet/keyboard triangles onto them.
for key,color,offset in [('laptop_base_edge',(185,184,177),10),('laptop_lid_edge',(52,54,53),11)]:
 ids=np.array([str(n).startswith(key) for n in solid_names]);x=10+offset*75;y=110;atlas.paste(Image.new('RGB',(70,70),color),(34%8*960+x,34//8*720+y));views[ids]=34;uv[ids]=[x+35,y+35];best[ids]=100
fallback=best<-1e5;fallback_counts={}
colors={'background':(166,164,153),'table':(205,204,197),'chair_left':(41,43,40),'chair_right':(42,44,40),'backpack':(48,48,44),'laptop':(77,76,73),'cup':(93,73,64),'whiteboard':(215,214,204),'charger':(53,52,48)}
for j,name in enumerate(names):
 ids=fallback&(labels==j);slot=34+j
 # Remaining atlas cells hold per-object fallback swatches in one shared tile.
 x=10+j*90;y=10;atlas.paste(Image.new('RGB',(80,80),colors.get(str(name),(150,148,140))),(34%8*960+x,34//8*720+y))
 views[ids]=34;uv[ids]=[x+40,y+40];fallback_counts[str(name)]=int(ids.sum())
(R/'calibration/texture_coverage.json').write_text(json.dumps({'faces':len(F),'faces_dropped_for_missing_texture':0,'inferred_color_faces':fallback_counts,'note':'Unobserved surfaces use labeled neutral-color completion; these are not measured texture.'},indent=2))
atlas.save(R/'assets/photo_atlas.jpg',quality=92)
uv[:,:,0]=(uv[:,:,0]+(views%8)[:,None]*960)/(960*8);uv[:,:,1]=1-(uv[:,:,1]+(views//8)[:,None]*720)/(720*5)
material=trimesh.visual.material.PBRMaterial(name='Captured light and color',baseColorTexture=Image.open(R/'assets/photo_atlas.jpg'),metallicFactor=0,roughnessFactor=1,doubleSided=True)
scene=trimesh.Scene();manifest=[]
for j,name in enumerate(names):
 mask=labels==j;faces=F[mask];verts=V[faces].reshape(-1,3);tex=uv[mask].reshape(-1,2)
 if len(verts)==0:continue
 center=np.zeros(3) if name=='background' else np.median(verts,axis=0)
 if name=='laptop':
  allmask=mask.copy();mask &= ~np.array([str(n).startswith('laptop_lid') for n in solid_names]);faces=F[mask];verts=V[faces].reshape(-1,3);tex=uv[mask].reshape(-1,2)
 local=verts-center
 obj=trimesh.Trimesh(local,np.arange(len(verts)).reshape(-1,3),process=False);obj.visual=trimesh.visual.TextureVisuals(uv=tex,material=material)
 tf=np.eye(4);tf[:3,3]=center;scene.graph.update(frame_to=str(name),matrix=tf);scene.add_geometry(obj,geom_name=str(name)+'_surface',node_name=str(name)+'_surface',parent_node_name=str(name))
 obj.export(R/'assets/objects'/f'{name}.obj')
 if name=='laptop':
  lm=cal['landmarks'];hinge=fitted_lid_corners()[:2].mean(0);mask=allmask&np.array([str(n).startswith('laptop_lid') for n in solid_names]);vv=V[F[mask]].reshape(-1,3)-hinge;ll=trimesh.Trimesh(vv,np.arange(len(vv)).reshape(-1,3),process=False);ll.visual=trimesh.visual.TextureVisuals(uv=uv[mask].reshape(-1,2),material=material);tf=np.eye(4);tf[:3,3]=hinge-center;scene.graph.update(frame_to='laptop_lid',frame_from='laptop',matrix=tf);scene.add_geometry(ll,geom_name='laptop_lid_surface',node_name='laptop_lid_surface',parent_node_name='laptop_lid');ll.export(R/'assets/objects/laptop_lid.obj')
 manifest.append({'name':str(name),'position':center.tolist(),'bounds':obj.bounds.tolist(),'faces':len(obj.faces),'fixed':name in ('background','whiteboard','charger'),'source':'DA3 depth fusion, SAM object ownership, source-image UV projection'})
lap=next(x for x in manifest if x['name']=='laptop');lap['lid_visual']=hinge_config(lap['position'])
prior=trimesh.load(R.parent/'test_scene_1/assets/multiview/background.obj',process=False);pc=prior.triangles_center;prior=prior.submesh([np.where(pc[:,2]>1.55)[0]],append=True);prior.visual.material=trimesh.visual.material.PBRMaterial(baseColorTexture=Image.open(R.parent/'test_scene_1/assets/multiview/atlas.jpg'),doubleSided=True,metallicFactor=0,roughnessFactor=1);prior.export(R/'assets/objects/room_from_stills.obj');Image.open(R.parent/'test_scene_1/assets/multiview/atlas.jpg').save(R/'assets/still_atlas.png');scene.add_geometry(prior,node_name='room_from_stills',geom_name='room_from_stills',parent_node_name='background');scene.export(R/'assets/scene.glb');(R/'assets/objects.json').write_text(json.dumps(manifest,indent=2));print('GLB complete',flush=True)
