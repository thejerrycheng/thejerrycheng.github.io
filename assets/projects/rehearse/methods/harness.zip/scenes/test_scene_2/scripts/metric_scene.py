from pathlib import Path
import pycolmap,numpy as np,cv2,json
R=Path(__file__).resolve().parents[1];r=pycolmap.Reconstruction(R/'calibration/colmap/best');ims={im.name:im for im in r.images.values()};cam=next(iter(r.cameras.values()));ann=json.loads((R/'calibration/annotations.json').read_text());init=np.load(R/'calibration/world_init.npz');normal=init['floor_normal'];floor=init['floor_point']
def tri(label):
 A=[]
 for name in ann:
  if label not in ann[name]:continue
  xy=cam.cam_from_img(np.array(ann[name][label],float));P=ims[name].cam_from_world().matrix();A.extend([xy[0]*P[2]-P[0],xy[1]*P[2]-P[1]])
 _,_,v=np.linalg.svd(A);return v[-1,:3]/v[-1,3]
pts={key:tri(key) for key in ann['frame_0001.jpg']}
scale=.17/abs((pts['cup_top_center']-pts['cup_bottom_center'])@normal)
x=pts['table_front_right_top']-pts['table_front_left_top'];x-=normal*(x@normal);x/=np.linalg.norm(x);y=np.cross(normal,x);B=np.array([x,y,normal]);origin=(pts['table_front_left_top']+pts['table_front_right_top'])/2;origin-=normal*((origin-floor)@normal)
# Raw front plane origin; shift table center back by half its reconstructed width.
width=np.linalg.norm(pts['table_front_right_top']-pts['table_front_left_top'])*scale
origin+=y*width/(2*scale)
landmarks={k:((v-origin)@B.T*scale).tolist() for k,v in pts.items()}
cameras=[]
for name,im in sorted(ims.items()):
 T=im.cam_from_world().matrix();C=(im.projection_center()-origin)@B.T*scale;Rw=T[:,:3]@B.T;tw=-Rw@C
 cameras.append({'name':name,'time':(int(name[6:10])-1)*.5+.25,'position':C.tolist(),'R_world_to_cv':Rw.tolist(),'t_world_to_cv':tw.tolist(),'rotation_camera_to_world_opengl':(Rw.T@np.diag([1,-1,-1])).tolist()})
world={'scale_m_per_sfm_unit':scale,'scale_assumption':'Cup lid-top to base assumed 0.17 m; no measured scale supplied','origin_raw':origin.tolist(),'raw_to_world_rotation':B.tolist(),'table_width':width,'table_depth':width,'table_height':np.mean([landmarks['table_front_left_top'][2],landmarks['table_front_right_top'][2]]),'landmarks':landmarks,'K':cam.calibration_matrix().tolist(),'radial_distortion_k1':float(cam.params[3]),'resolution':[960,720],'duration':15.7,'cameras':cameras}
(R/'calibration/cameras.json').write_text(json.dumps(world,indent=2));print({k:v for k,v in world.items() if k!='cameras'})
# Save sparse observed geometry and earliest observation times.
X=[];rgb=[];first=[]
for p in r.points3D.values():
 X.append((p.xyz-origin)@B.T*scale);rgb.append(p.color);first.append(min((int(r.images[e.image_id].name[6:10])-1)*.5+.25 for e in p.track.elements))
np.savez(R/'calibration/sparse_world.npz',xyz=X,rgb=rgb,first_seen=first)
