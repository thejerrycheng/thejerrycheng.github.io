"""Export interactive bodies with conservative contact proxies and explicit assumptions."""
from pathlib import Path
import json,numpy as np,xml.etree.ElementTree as ET
from scipy.spatial.transform import Rotation
from PIL import Image
import mujoco,trimesh
from solid_assets import planez,hinge_config,fitted_lid_corners
R=Path(__file__).resolve().parents[1];objects=json.loads((R/'assets/objects.json').read_text());cal=json.loads((R/'calibration/cameras.json').read_text());Image.open(R/'assets/photo_atlas.jpg').save(R/'assets/photo_atlas.png')
def txt(x):return ' '.join(f'{v:.8g}' for v in x)
def quat_z(n):
 n=np.asarray(n);n=n/np.linalg.norm(n);r,_=Rotation.align_vectors([n],[[0,0,1]]);q=r.as_quat();return txt(np.r_[q[3],q[:3]])
root=ET.Element('mujoco',model='Rehearse_scene_02');ET.SubElement(root,'compiler',angle='radian',meshdir='assets/objects',texturedir='assets');ET.SubElement(root,'option',timestep='.001',gravity='0 0 -9.81',integrator='implicitfast');defaults=ET.SubElement(root,'default');ET.SubElement(defaults,'geom',solref='.004 1',solimp='.95 .99 .001');asset=ET.SubElement(root,'asset');ET.SubElement(asset,'texture',name='captured',type='2d',file='photo_atlas.png');ET.SubElement(asset,'material',name='photo',texture='captured',texuniform='false',emission='1',specular='0',reflectance='0');world=ET.SubElement(root,'worldbody');ET.SubElement(world,'light',pos='0 -2 4',diffuse='.6 .6 .6');ET.SubElement(world,'geom',name='floor_contact',type='plane',pos='0 0 -.075',size='5 5 .1',rgba='.6 .56 .5 0',friction='.9 .01 .001')
assumptions=[]
for ob in objects:
 name=ob['name'];pos=np.array(ob['position']);ET.SubElement(asset,'mesh',name=name,file=name+'.obj');body=ET.SubElement(world,'body',name=name,pos=txt(pos));ET.SubElement(body,'geom',name=name+'_appearance',type='mesh',mesh=name,material='photo',contype='0',conaffinity='0',group='2',mass='0')
 if name=='background':continue
 if name in ['whiteboard','charger']:
  assumptions.append({'object':name,'mode':'visual only, fixed pending reliable separation'});continue
 ET.SubElement(body,'freejoint',name=name+'_free');mass={'table':12,'cup':.35,'laptop':1.6,'backpack':1.2,'chair_left':12,'chair_right':12}[name];com=np.array([.204,-.18,planez(.204,-.18)+.552+.084])-pos if name=='cup' else (np.array([-.1175,-.279,.591])-pos if name=='laptop' else np.zeros(3));inertia=[.001,.001,.0004] if name=='cup' else np.repeat(max(.0004,mass*.04),3);ET.SubElement(body,'inertial',pos=txt(com),mass=str(mass),diaginertia=txt(inertia))
 def geom(kind,worldpos,size,**kw):ET.SubElement(body,'geom',type=kind,pos=txt(np.array(worldpos)-pos),size=txt(size),rgba='.1 .5 .9 0',group='3',friction='.8 .01 .001',**kw)
 if name=='table':
  corners=np.array([[-.34,-.37],[.358,-.37],[.358,.35],[-.34,.35]]);vv=np.r_[np.c_[corners,np.full(4,-.075)],np.c_[corners,planez(corners[:,0],corners[:,1])+.552]]-pos;proxy=trimesh.convex.convex_hull(vv);proxy.export(R/'assets/objects/table_collision.obj');ET.SubElement(asset,'mesh',name='table_collision',file='table_collision.obj');ET.SubElement(body,'geom',name='table_collision_geom',type='mesh',mesh='table_collision',rgba='.1 .5 .9 0',group='3',friction='.8 .01 .001')
 elif name=='cup':geom('cylinder',[.204,-.18,planez(.204,-.18)+.552+.084],[.042,.084])
 elif name=='laptop':
  geom('box',[-.1175,-.279,.591],[.24,.15,.006],name='laptop_base_collision',quat=quat_z([.086,.049,1]))
  lm=cal['landmarks'];bl,br,tr,tl=fitted_lid_corners();hinge=(bl+br)/2;center=(bl+br+tl+tr)/4;x=(br-bl)/np.linalg.norm(br-bl);y=((tl+tr)/2-hinge);y/=np.linalg.norm(y);z=np.cross(x,y);z/=np.linalg.norm(z);y=np.cross(z,x);q=Rotation.from_matrix(np.c_[x,y,z]).as_quat();ET.SubElement(asset,'mesh',name='laptop_lid',file='laptop_lid.obj');lid=ET.SubElement(body,'body',name='laptop_lid_contact',pos=txt(hinge-pos));ET.SubElement(lid,'geom',type='mesh',mesh='laptop_lid',material='photo',contype='0',conaffinity='0',mass='0',group='2');ET.SubElement(lid,'joint',name='laptop_hinge',type='hinge',axis=txt(x),range=txt([hinge_config(pos)['min_rotation'],hinge_config(pos)['max_rotation']]),damping='.3',frictionloss='.15',stiffness='1',springref='0',solreflimit='.004 1',solimplimit='.95 .99 .001');ET.SubElement(lid,'geom',name='laptop_lid_collision',type='box',pos=txt(center-hinge),quat=txt(np.r_[q[3],q[:3]]),size=txt([np.linalg.norm(br-bl)/2,np.linalg.norm((tl+tr)/2-hinge)/2,.006]),mass='.3',rgba='.3 .3 .3 0',group='3')
 elif name=='backpack':geom('ellipsoid',[-.75,-.03,.025],[.30,.23,.10])
 else:
  x,y=(-1.55,1.05) if name=='chair_left' else (.23,1.05);floor=-.055;geom('box',[x,y,.37],[.30,.29,.065]);geom('box',[x,y+.23,.59],[.31,.055,.20]);geom('cylinder',[x,y,.15],[.045,.205]);geom('box',[x,y,floor+.025],[.34,.035,.025]);geom('box',[x,y,floor+.025],[.035,.34,.025])
 assumptions.append({'object':name,'mode':'free rigid body','mass_kg_assumed':mass,'collision':'compound primitive proxy','geometry_note':'Incomplete scanned surfaces are visual only. Backpack is rigid; chair cushions are rigid; contact parameters are not measured.'})
contact=ET.SubElement(root,'contact');ET.SubElement(contact,'pair',geom1='laptop_lid_collision',geom2='table_collision_geom',condim='3',solref='.004 1',solimp='.95 .99 .001');ET.SubElement(contact,'pair',geom1='laptop_base_collision',geom2='laptop_lid_collision',condim='3',solref='.004 1',solimp='.95 .99 .001')
ET.SubElement(asset,'mesh',name='room_from_stills',file='room_from_stills.obj');ET.SubElement(asset,'texture',name='stills',type='2d',file='still_atlas.png');ET.SubElement(asset,'material',name='stills',texture='stills',emission='1',specular='0');ET.SubElement(world,'geom',type='mesh',mesh='room_from_stills',material='stills',contype='0',conaffinity='0',mass='0',group='2')
for i,c in enumerate(cal['cameras']):
 q=Rotation.from_matrix(c['rotation_camera_to_world_opengl']).as_quat();ET.SubElement(world,'camera',name=f'capture_{i:02d}',pos=txt(c['position']),quat=txt(np.r_[q[3],q[:3]]),fovy=str(2*np.degrees(np.arctan(360/cal['K'][1][1]))))
ET.indent(root);ET.ElementTree(root).write(R/'scene.xml',encoding='unicode');(R/'assets/physics_assumptions.json').write_text(json.dumps(assumptions,indent=2))
m=mujoco.MjModel.from_xml_path(str(R/'scene.xml'));d=mujoco.MjData(m);mujoco.mj_forward(m,d);initial=d.qpos.copy();initial_positions=d.xpos.copy()
for _ in range(int(8/m.opt.timestep)):mujoco.mj_step(m,d)
report={'bodies':m.nbody,'free_joints':sum(m.jnt_type==mujoco.mjtJoint.mjJNT_FREE).item(),'hinges':sum(m.jnt_type==mujoco.mjtJoint.mjJNT_HINGE).item(),'settle_seconds':8,'finite_state':bool(np.isfinite(d.qpos).all()),'max_speed_after_settle':float(abs(d.qvel).max()),'warnings':[int(w.number) for w in d.warning]}
report['settle_displacement_m']={ob['name']:float(np.linalg.norm(d.xpos[m.body(ob['name']).id]-initial_positions[m.body(ob['name']).id])) for ob in objects if ob['name'] not in ['background','whiteboard','charger']};body=m.body('cup').id;z0=float(d.xpos[body,2]);maximum=z0
for i in range(int(.7/m.opt.timestep)):
 d.xfrc_applied[body,:3]=[0,0,5 if i<int(.2/m.opt.timestep) else 0];mujoco.mj_step(m,d);maximum=max(maximum,float(d.xpos[body,2]))
report['cup_external_force_rise_m']=maximum-z0;report['cup_final_z']=float(d.xpos[body,2]);report['test_note']='External force sanity check only; no robot or learned policy.';(R/'calibration/physics_report.json').write_text(json.dumps(report,indent=2));print(report)
