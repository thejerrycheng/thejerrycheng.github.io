import os,sys
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR='/tmp/rehearse-mpl')
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R.parents[1]/'third_party/depth-anything-3/src'))
import torch,numpy as np,json,time,argparse
p=argparse.ArgumentParser();p.add_argument('--model',default='small');p.add_argument('--resolution',type=int,default=392);args=p.parse_args()
from depth_anything_3.api import DepthAnything3
class CPUModel(DepthAnything3):
 @torch.inference_mode()
 def forward(self,image,extrinsics=None,intrinsics=None,export_feat_layers=None,infer_gs=False,use_ray_pose=False,ref_view_strategy='saddle_balanced'):
  return self.model(image,extrinsics,intrinsics,export_feat_layers,infer_gs,use_ray_pose,ref_view_strategy)
torch.set_num_threads(4);m=CPUModel.from_pretrained(str(R.parents[1]/('models/da3-'+args.model))).to('cpu');cal=json.loads((R/'calibration/cameras.json').read_text());out=R/('calibration/da3' if args.model=='small' else 'calibration/da3_'+args.model);out.mkdir(exist_ok=True);start=time.time()
for batch,indices in enumerate([list(range(0,9)),list(range(7,16)),list(range(14,23)),list(range(22,31))]):
 if (out/f'batch_{batch}.npz').exists():continue
 cs=[cal['cameras'][i] for i in indices];ext=np.stack([np.r_[np.c_[c['R_world_to_cv'],c['t_world_to_cv']],[[0,0,0,1]]] for c in cs]).astype('float32');K=np.repeat(np.array(cal['K'])[None],len(cs),axis=0).astype('float32')
 pred=m.inference([str(R/'source/frames'/c['name']) for c in cs],extrinsics=ext,intrinsics=K,align_to_input_ext_scale=True,process_res=args.resolution,ref_view_strategy='middle')
 np.savez_compressed(out/f'batch_{batch}.npz',indices=indices,depth=pred.depth,conf=pred.conf,extrinsics=pred.extrinsics,intrinsics=pred.intrinsics,rgb=pred.processed_images)
 print('batch',batch,'depth',pred.depth.shape,'elapsed',round(time.time()-start,1),flush=True)
(out/'runtime.json').write_text(json.dumps({'model':'DA3-'+args.model.upper(),'device':'CPU float32','seconds':time.time()-start,'camera_conditioned':True,'process_res':args.resolution},indent=2))
