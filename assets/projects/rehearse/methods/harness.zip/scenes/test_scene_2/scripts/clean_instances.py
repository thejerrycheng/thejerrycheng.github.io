"""Multi-view ownership, removal of object remnants from fixed structure, surface cleanup.
Not generative object completion: preserves a versioned baseline for measured comparisons.
"""
import os,json,shutil
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
import numpy as np,cv2,trimesh
R=Path(__file__).resolve().parents[1];variants=R/'assets/variants';variants.mkdir(exist_ok=True);baseline=variants/'da3_unfiltered.npz'
if not baseline.exists():shutil.copy2(R/'assets/labeled_mesh.npz',baseline);shutil.copy2(R/'assets/scene.glb',variants/'da3_unfiltered.glb')
a=np.load(baseline);V=a['vertices'].astype(float);F=a['faces'];names=a['names'];cal=json.loads((R/'calibration/cameras.json').read_text());X=V[F].mean(1);normal=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]);normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-9);votes=np.zeros((len(F),len(names)));seen=np.zeros(len(F));movable=['table','chair_left','chair_right','backpack','laptop','cup'];
priors={'cup':([.10,-.30,.50],[.31,-.06,.79]),'laptop':([-.45,-.49,.49],[.24,.15,.94]),'table':([-.40,-.44,-.07],[.42,.42,.64]),'backpack':([-1.14,-.45,-.06],[-.39,.33,.20]),'chair_left':([-2.10,.52,-.06],[-.98,1.65,.95]),'chair_right':([-.29,.54,-.06],[.78,1.64,.95])}
for i,c in enumerate(cal['cameras']):
 z=X@np.array(c['R_world_to_cv']).T+np.array(c['t_world_to_cv']);K=np.array(cal['K']);uv=z[:,:2]/z[:,2:]*[K[0,0],K[1,1]]+[480,360];u,v=np.rint(uv).astype(int).T;ok=(z[:,2]>.1)&(u>=0)&(u<960)&(v>=0)&(v<720);ix=np.where(ok)[0];d=np.load(R/f'calibration/fused_input_{i:02d}.npz')['depth'];h,w=d.shape;di=d[np.minimum(v[ix]*h//720,h-1),np.minimum(u[ix]*w//960,w-1)];ix=ix[abs(z[ix,2]-di)<.065];weights=np.maximum(.15,abs((normal[ix]*(np.array(c['position'])-X[ix])).sum(1))/np.linalg.norm(np.array(c['position'])-X[ix],axis=1));seen[ix]+=weights
 labels=np.zeros((720,960),np.uint8)
 for n in movable:
  p=R/f'calibration/sam2_masks/frame_{i+1:04d}_{n}.png';m=cv2.imread(str(p),0);assert m is not None,p
  labels[m>127]=list(names).index(n)
 np.add.at(votes,(ix,labels[v[ix],u[ix]]),weights)
# Prefer cross-view semantic evidence inside conservative spatial envelopes.
labels=a['labels'].copy();keep=np.ones(len(F),bool);report={'baseline_faces':len(F),'method':'31-view depth-visible SAM 2 ownership, spatial exclusion of object remnants, component filtering, six Taubin smoothing iterations','objects':{},'fixed_object_remnant_faces_removed':0}
owned=np.zeros_like(votes)
for name in movable:
 j=list(names).index(name);lo,hi=priors[name];inside=((X>=lo)&(X<=hi)).all(1);owned[:,j]=votes[:,j]*inside
winner=owned.argmax(1);support=owned.max(1);labels[support>.2]=winner[support>.2]
for name in movable:
 j=list(names).index(name);lo,hi=priors[name];inside=((X>=lo)&(X<=hi)).all(1)
 invalid=(labels==j)&~inside;keep[invalid]=False
 # Ambiguous fixed-room pieces inside an object's envelope cannot remain behind
 # when that object moves. Floor is reconstructed separately from its clean plate.
 remnant=inside&np.isin(labels,[0,2,8])&(X[:,2]>-.065);keep[remnant]=False;report['fixed_object_remnant_faces_removed']+=int(remnant.sum())
# Keep supported connected parts; remove tiny detached surface noise.
vertices=[];faces=[];outlabels=[]
for j,name in enumerate(names):
 chosen=np.where((labels==j)&keep)[0]
 if not len(chosen):continue
 m=trimesh.Trimesh(V,F[chosen],process=True);parts=m.split(only_watertight=False)
 if name in movable:
  large=[p for p in parts if p.area>.0008 and len(p.faces)>=8];removed=len(m.faces)-sum(len(p.faces) for p in large)
  cleaned=[]
  for part in large:
   if len(part.vertices)>10:trimesh.smoothing.filter_taubin(part,lamb=.45,nu=.50,iterations=6)
   cleaned.append(part)
  if not cleaned:continue
  m=trimesh.util.concatenate(cleaned);report['objects'][str(name)]={'before_faces':len(chosen),'after_faces':len(m.faces),'removed_small_component_faces':removed,'retained_components':len(cleaned),'watertight_visual':bool(m.is_watertight),'completion':'none; hidden surfaces still need generative completion or better capture'}
 offset=sum(len(v) for v in vertices);vertices.append(m.vertices);faces.append(m.faces+offset);outlabels.extend([j]*len(m.faces))
np.savez_compressed(R/'assets/labeled_mesh.npz',vertices=np.vstack(vertices).astype('float32'),faces=np.vstack(faces).astype('int32'),labels=np.array(outlabels,dtype='uint8'),names=names)
report['output_faces']=len(outlabels);(R/'calibration/instance_cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
