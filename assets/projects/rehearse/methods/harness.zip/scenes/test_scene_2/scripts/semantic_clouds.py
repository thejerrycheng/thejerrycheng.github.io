from pathlib import Path
import numpy as np,json,pycolmap,cv2
R=Path(__file__).resolve().parents[1];c=json.loads((R/'calibration/cameras.json').read_text());r=pycolmap.Reconstruction(R/'calibration/colmap/best');ims={im.name:im for im in r.images.values()};B=np.array(c['raw_to_world_rotation']);origin=np.array(c['origin_raw']);s=c['scale_m_per_sfm_unit'];obj={}
for path in sorted((R/'calibration/masks').glob('*.png')):
 name=path.stem[:10]+'.jpg';key=path.stem[11:];im=ims[name];mask=cv2.imread(str(path),0)
 for pt in im.points2D:
  if pt.has_point3D():
   u,v=np.round(pt.xy).astype(int)
   if 0<=u<960 and 0<=v<720 and mask[v,u]>0:obj.setdefault(key,{})[pt.point3D_id]=(r.points3D[pt.point3D_id].xyz-origin)@B.T*s
summary={}
for key,pts in obj.items():
 X=np.array(list(pts.values()));lo,hi=np.percentile(X,[2,98],axis=0);summary[key]={'n_sparse_points':len(X),'bbox_min':lo.tolist(),'bbox_max':hi.tolist(),'center':np.median(X,axis=0).tolist()};np.save(R/f'calibration/sparse_{key}.npy',X)
(R/'calibration/semantic_bounds.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
