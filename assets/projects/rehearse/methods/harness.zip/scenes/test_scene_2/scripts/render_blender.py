import bpy,json,sys
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras.json').read_text());(R/'renders').mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=4;s.render.resolution_x=960;s.render.resolution_y=720;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard';s.world.color=(.65,.65,.65)
m=bpy.data.materials.new('Captured appearance');m.use_nodes=True;n=m.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');sh=n.new('ShaderNodeEmission');tex=n.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(R/'assets/photo_atlas.jpg'));m.node_tree.links.new(tex.outputs['Color'],sh.inputs['Color']);m.node_tree.links.new(sh.outputs[0],out.inputs['Surface'])
for obj in json.loads((R/'assets/objects.json').read_text()):
 bpy.ops.import_scene.obj(filepath=str(R/'assets/objects'/f"{obj['name']}.obj"),axis_forward='Y',axis_up='Z');o=bpy.context.selected_objects[0];o.location=obj['position'];o.name=obj['name'];o.data.materials.clear();o.data.materials.append(m)
bpy.ops.import_scene.obj(filepath=str(R/'assets/objects/room_from_stills.obj'),axis_forward='Y',axis_up='Z');o=bpy.context.selected_objects[0];o.name='room_from_stills';sm=m.copy();next(x for x in sm.node_tree.nodes if x.type=='TEX_IMAGE').image=bpy.data.images.load(str(R/'assets/still_atlas.png'));o.data.materials.clear();o.data.materials.append(sm)
lap=next(x for x in json.loads((R/'assets/objects.json').read_text()) if x['name']=='laptop')
if 'lid_visual' in lap:
 bpy.ops.import_scene.obj(filepath=str(R/'assets/objects/laptop_lid.obj'),axis_forward='Y',axis_up='Z');o=bpy.context.selected_objects[0];o.location=lap['lid_visual']['hinge_world'];o.name='laptop_lid';o.data.materials.clear();o.data.materials.append(m)
for c in cal['cameras']:
 bpy.ops.object.camera_add(location=c['position']);cam=bpy.context.object;cam.name=c['name'];cam.rotation_euler=Matrix(c['rotation_camera_to_world_opengl']).to_euler();cam.data.sensor_fit='HORIZONTAL';cam.data.sensor_width=36;cam.data.lens=cal['K'][0][0]/960*36;cam.data.clip_start=.01
for i in [0,12,24]:
 s.camera=bpy.data.objects[cal['cameras'][i]['name']];s.render.filepath=str(R/f'renders/photo_{i:02d}.png');bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'scene.blend'))
