from pathlib import Path
import torch, numpy as np, cv2
from PIL import Image
from transformers import DPTImageProcessor, DPTForDepthEstimation
ROOT=Path(__file__).resolve().parents[1]
torch.set_num_threads(6)
p=DPTImageProcessor.from_pretrained('Intel/dpt-large',local_files_only=True)
m=DPTForDepthEstimation.from_pretrained('Intel/dpt-large',local_files_only=True).eval()
for n in (1207,1208,1209):
 im=Image.open(ROOT/f'source/IMG_{n}.jpg'); im.thumbnail((1200,1600))
 with torch.no_grad(): d=m(**p(images=im,return_tensors='pt')).predicted_depth
 d=torch.nn.functional.interpolate(d[:,None],size=(1600,1200),mode='bicubic',align_corners=False)[0,0].numpy()
 np.save(ROOT/f'calibration/depth_{n}.npy',d)
 cv2.imwrite(str(ROOT/f'calibration/depth_{n}.jpg'),cv2.applyColorMap(np.uint8(np.clip(d/np.percentile(d,99),0,1)*255),cv2.COLORMAP_TURBO))
 print(n,float(d.min()),float(d.max()),flush=True)
