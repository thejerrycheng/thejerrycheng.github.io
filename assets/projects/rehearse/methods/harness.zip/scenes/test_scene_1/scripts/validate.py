from pathlib import Path
import mujoco,numpy as np,json,cv2
ROOT=Path(__file__).resolve().parents[1]
m=mujoco.MjModel.from_xml_path(str(ROOT/'scene.xml'));d=mujoco.MjData(m);bid=m.body('coffee').id
mujoco.mj_forward(m,d);z0=float(d.xpos[bid,2]);zs=[]
for i in range(1500):mujoco.mj_step(m,d)
rest=float(d.xpos[bid,2]);contacts=d.ncon
for i in range(150):
 d.xfrc_applied[bid,2]=5.;mujoco.mj_step(m,d);zs.append(float(d.xpos[bid,2]))
d.xfrc_applied[:]=0
for i in range(2500):mujoco.mj_step(m,d)
report={'model_load':'pass','nq':m.nq,'nv':m.nv,'coffee_freejoint':m.nq==7,'coffee_mass_kg':float(m.body_mass[bid]),'rest_base_z_m':rest,'rest_contacts':contacts,'external_force_lift_m':max(zs)-rest,'returned_base_z_m':float(d.xpos[bid,2]),'finite_state':bool(np.isfinite(d.qpos).all()),'test_scope':'External-force lift and gravity return; NOT a robot grasp or learned policy.'}
(ROOT/'calibration/physics_report.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
mujoco.mj_resetData(m,d);mujoco.mj_forward(m,d)
renderer=mujoco.Renderer(m,height=1000,width=750);opt=mujoco.MjvOption();opt.geomgroup[5]=0
for name in ['capture_1207','capture_1208','capture_1209']:
 renderer.update_scene(d,camera=name,scene_option=opt);rgb=renderer.render();cv2.imwrite(str(ROOT/f'renders/{name}.png'),cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR))
# Overview with capture frusta, and a lifted-object view.
opt.geomgroup[5]=1;cam=mujoco.MjvCamera();cam.lookat[:]=[0,0,.8];cam.distance=2.5;cam.azimuth=130;cam.elevation=-30
renderer.update_scene(d,camera=cam,scene_option=opt);cv2.imwrite(str(ROOT/'renders/camera_overview.png'),cv2.cvtColor(renderer.render(),cv2.COLOR_RGB2BGR))
opt.geomgroup[5]=0;d.qpos[2]+=.2;mujoco.mj_forward(m,d);renderer.update_scene(d,camera='capture_1207',scene_option=opt);cv2.imwrite(str(ROOT/'renders/coffee_lifted.png'),cv2.cvtColor(renderer.render(),cv2.COLOR_RGB2BGR));renderer.close()
