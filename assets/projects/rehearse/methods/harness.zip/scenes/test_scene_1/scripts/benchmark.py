"""Camera-conditioned cross-view reprojection; NOT a held-out end-to-end reconstruction test."""
from pathlib import Path
import cv2,numpy as np,json
from skimage.metrics import structural_similarity
ROOT=Path(__file__).resolve().parents[1];cal=json.loads((ROOT/'calibration/cameras.json').read_text());K=np.array(cal['K']);W,H=750,1000
report={'evaluation_scope':'Camera-conditioned cross-view appearance transfer. Camera fitting used annotations in all three photos. No independent metric geometry ground truth. This is NOT an end-to-end held-out novel-view benchmark.','methods':[]}
# Compare mesh-like nearest-point reprojection with an untrained isotropic Gaussian splat baseline.
for source in range(3):
 c=cal['cameras'][source];name=c['image'][4:8];cloud=np.load(ROOT/f'calibration/cloud_{name}.npz');xyz=cloud['xyz'];rgb=cloud['rgb'].astype(float)
 for target in range(3):
  if target==source:continue
  t=cal['cameras'][target];p=xyz@np.array(t['R_world_to_cv']).T+np.array(t['t_world_to_cv']);q=p@K.T;q=q[:,:2]/q[:,2:];ij=np.round(q).astype(int);ok=(p[:,2]>.02)&(ij[:,0]>=0)&(ij[:,0]<W)&(ij[:,1]>=0)&(ij[:,1]<H);ij=ij[ok];z=p[ok,2];colors=rgb[ok]
  gt=cv2.cvtColor(cv2.resize(cv2.imread(str(ROOT/'source'/t['image'])),(W,H)),cv2.COLOR_BGR2RGB)
  for method in ['depth_point_reprojection','untrained_gaussian_splats']:
   zb=np.full((H,W),np.inf);acc=np.zeros((H,W,3));weight=np.zeros((H,W));radius=3
   for dy in range(-radius,radius+1):
    for dx in range(-radius,radius+1):
     xx=ij[:,0]+dx;yy=ij[:,1]+dy;v=(xx>=0)&(xx<W)&(yy>=0)&(yy<H);np.minimum.at(zb,(yy[v],xx[v]),z[v])
   for dy in range(-radius,radius+1):
    for dx in range(-radius,radius+1):
     xx=ij[:,0]+dx;yy=ij[:,1]+dy;v=(xx>=0)&(xx<W)&(yy>=0)&(yy<H);indices=np.where(v)[0];v[indices]&=z[indices]<=zb[yy[indices],xx[indices]]+.025
     ww=np.exp(-(dx*dx+dy*dy)/(2*1.5**2)) if method=='untrained_gaussian_splats' else 1.
     np.add.at(acc,(yy[v],xx[v]),colors[v]*ww);np.add.at(weight,(yy[v],xx[v]),ww)
   valid=weight>0;out=np.zeros_like(acc);out[valid]=acc[valid]/weight[valid,None];out=np.clip(out,0,255).astype('uint8')
   # Cup and table are not in background point clouds, so evaluate background only.
   targetcup=cv2.imread(str(ROOT/f'assets/cup_mask_{target}.png'),0)>0
   valid&=~targetcup
   mse=np.mean((out[valid].astype(float)-gt[valid])**2) if valid.any() else np.nan
   fullmse=np.mean((out.astype(float)-gt)**2)
   row={'method':method,'source':int(name),'target':int(t['image'][4:8]),'coverage_fraction':float(valid.mean()),'psnr_on_covered_pixels_db':float(10*np.log10(255**2/mse)),'psnr_full_image_including_holes_db':float(10*np.log10(255**2/fullmse)),'ssim_full_image':float(structural_similarity(gt,out,channel_axis=2,data_range=255)),'trained':False}
   report['methods'].append(row);cv2.imwrite(str(ROOT/f'renders/{method}_{name}_to_{t["image"][4:8]}.jpg'),cv2.cvtColor(out,cv2.COLOR_RGB2BGR))
# Traditional dense stereo on front-view pair using the estimated SfM relative pose.
sfm=np.load(ROOT/'calibration/sfm.npz');ks=sfm['K']/1.6;ks[2,2]=1;r=cv2.Rodrigues(sfm['cams'][1,:3])[0];t=sfm['cams'][1,3:]
im=[cv2.resize(cv2.imread(str(ROOT/f'source/IMG_{n}.jpg')),(W,H)) for n in [1207,1209]]
r1,r2,p1,p2,Q,roi1,roi2=cv2.stereoRectify(ks,None,ks,None,(W,H),r,t,alpha=0)
rect=[]
for R,P,I in zip([r1,r2],[p1,p2],im):
 mx,my=cv2.initUndistortRectifyMap(ks,None,R,P,(W,H),cv2.CV_32FC1);rect.append(cv2.remap(I,mx,my,cv2.INTER_LINEAR))
matcher=cv2.StereoSGBM_create(minDisparity=0,numDisparities=128,blockSize=5,P1=8*3*25,P2=32*3*25,disp12MaxDiff=1,uniquenessRatio=10,speckleWindowSize=100,speckleRange=2,mode=cv2.STEREO_SGBM_MODE_SGBM_3WAY)
disp=matcher.compute(*rect).astype(float)/16;good=disp>0
cv2.imwrite(str(ROOT/'renders/stereo_sgbm.jpg'),cv2.applyColorMap(np.uint8(np.clip(disp/80,0,1)*255),cv2.COLORMAP_TURBO));np.save(ROOT/'calibration/stereo_disparity.npy',disp)
report['stereo']={'method':'OpenCV StereoSGBM','pair':[1207,1209],'valid_disparity_fraction':float(good.mean()),'status':'diagnostic only; no ground-truth depth; weak baseline and textureless table limit reliability'}
report['unavailable']=[{'method':'gsplat trained 3D Gaussian Splatting','status':'not run','reason':'GitHub DNS/download blocked; package unavailable; CUDA inaccessible'},{'method':'VGGT / MASt3R','status':'not run','reason':'Weights and source not installed; network downloads blocked'},{'method':'visual inertial SLAM','status':'not applicable to this input','reason':'Only three stills; no temporal image sequence or synchronized IMU'}]
(ROOT/'calibration/benchmark.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
