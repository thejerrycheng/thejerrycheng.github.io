"""Explicit geometry-prior reconstruction; all landmarks are manual, not ground truth."""
from pathlib import Path
import numpy as np,cv2,json
from scipy.optimize import least_squares
ROOT=Path(__file__).resolve().parents[1]
indices=[[0,1,2],[1,2],[0,1,2]]
ids=[1207,1208,1209];W,H=750,1000;f=24/np.hypot(36,24)*1250
# Table back-left/back-right/front-right; third corner is out of frame in side view.
tables=[[[68,515],[490,543],[627,887]],[[335,579],[740,710]],[[95,524],[536,550],[662,933]]]
# Bounding boxes of uppermost lid ring and cup bottom ring.
lids=[[369,527,464,559],[434,550,518,575],[370,516,475,550]]
bases=[[369,690,441,718],[453,692,515,715],[376,700,456,730]]
# Reference scale only: replace with measured height when supplied.
height=.17;radius=.045;rb=.032;table_z=.75
angle=np.linspace(0,2*np.pi,128,endpoint=False)

def geometry(par):
 w,d,cx,cy=par[:4];table=np.array([[-w/2,d/2,table_z],[w/2,d/2,table_z],[w/2,-d/2,table_z]])
 rings=[np.c_[cx+r*np.cos(angle),cy+r*np.sin(angle),np.full(128,table_z+z)] for r,z in [(radius,height),(rb,0)]]
 return table,rings
K=np.array([[f,0,W/2],[0,f,H/2],[0,0,1.]])
par=np.array([.72,.72,.12,.04]);tab,rings=geometry(par);cs=[]
for i in range(3):
 xy=np.array(tables[i]+[[sum(lids[i][::2])/2,sum(lids[i][1::2])/2],[sum(bases[i][::2])/2,sum(bases[i][1::2])/2]],float)
 obj=np.vstack([tab[indices[i]],[par[2],par[3],table_z+height],[par[2],par[3],table_z]])
 ok,rv,tv=cv2.solvePnP(obj,xy,K,None,flags=cv2.SOLVEPNP_SQPNP)
 cs.append(np.r_[rv.ravel(),tv.ravel()])
x0=np.r_[par,f,np.array(cs).ravel()]
def residual(x):
 tab,rings=geometry(x);k=K.copy();k[0,0]=k[1,1]=x[4];out=[]
 for i,c in enumerate(x[5:].reshape(3,6)):
  def project(p): return cv2.projectPoints(p,c[:3],c[3:],k,None)[0][:,0]
  out.extend(((project(tab[indices[i]])-tables[i])*1.5).ravel())
  for ring,box in zip(rings,[lids[i],bases[i]]):
   q=project(ring);out.extend((np.r_[q.min(0),q.max(0)]-box))
 out.extend([(x[0]-x[1])*20,(x[4]-f)/40])
 return out
lo=np.r_[[.3,.3,-.4,-.4,f*.85],np.full(18,-np.inf)];hi=np.r_[[1.5,1.5,.4,.4,f*1.15],np.full(18,np.inf)]
s=least_squares(residual,x0,bounds=(lo,hi),loss='soft_l1',f_scale=3,max_nfev=2500)
x=s.x;tab,rings=geometry(x);k=K.copy();k[0,0]=k[1,1]=x[4]
result={'method':'manually annotated geometry-constrained bundle fit','metric_scale':'assumed cup height 0.17 m; NOT measured','cup_height':height,'cup_radius':radius,'cup_bottom_radius':rb,'cup_position':[x[2],x[3],table_z],'table_width':x[0],'table_depth':x[1],'table_height':table_z,'K':k.tolist(),'resolution':[W,H],'landmark_residual_median_px':float(np.median(np.abs(residual(x)[:-2]))),'cameras':[]}
for n,c in zip(ids,x[5:].reshape(3,6)):
 R=cv2.Rodrigues(c[:3])[0];C=-R.T@c[3:];result['cameras'].append({'name':f'capture_{n}','image':f'IMG_{n}.jpg','R_world_to_cv':R.tolist(),'t_world_to_cv':c[3:].tolist(),'position':C.tolist(),'rotation_camera_to_world_opengl':(R.T@np.diag([1,-1,-1])).tolist()})
 im=cv2.resize(cv2.imread(str(ROOT/f'source/IMG_{n}.jpg')),(W,H))
 for ps in [tab,*rings]:
  q=cv2.projectPoints(ps,c[:3],c[3:],k,None)[0][:,0]
  for u,v in q: cv2.circle(im,(round(u),round(v)),2,(0,0,255),-1)
 cv2.imwrite(str(ROOT/f'calibration/fit_{n}.jpg'),im)
(ROOT/'calibration/cameras.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
