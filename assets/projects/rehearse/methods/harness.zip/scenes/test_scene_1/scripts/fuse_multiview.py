import os,sys
os.environ.update(OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R.parents[1]/'third_party/numpy126'))
import numpy as np,json,open3d as o3d
cal=json.loads((R/'calibration/cameras_multiview.json').read_text());a=np.load(R/'calibration/da3_large_refined.npz');out=R/'assets/multiview';out.mkdir(exist_ok=True)
vol=o3d.pipelines.integration.ScalableTSDFVolume(voxel_length=.008,sdf_trunc=.05,color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8)
for i,c in enumerate(cal['cameras']):
 d=a['depth'][i].astype('float32');rgb=a['rgb'][i];h,w=d.shape;K=a['intrinsics'][i];d[(d<.15)|(d>12)]=0
 rgbd=o3d.geometry.RGBDImage.create_from_color_and_depth(o3d.geometry.Image(rgb),o3d.geometry.Image(d),depth_scale=1,depth_trunc=12,convert_rgb_to_intensity=False);ext=np.eye(4);ext[:3,:3]=c['R_world_to_cv'];ext[:3,3]=c['t_world_to_cv'];intr=o3d.camera.PinholeCameraIntrinsic(w,h,K[0,0],K[1,1],K[0,2],K[1,2]);vol.integrate(rgbd,intr,ext)
m=vol.extract_triangle_mesh();m.remove_degenerate_triangles();m.remove_duplicated_vertices();m=m.simplify_quadric_decimation(180000);m.compute_vertex_normals();o3d.io.write_triangle_mesh(str(out/'fused.ply'),m);print(len(m.vertices),len(m.triangles))
