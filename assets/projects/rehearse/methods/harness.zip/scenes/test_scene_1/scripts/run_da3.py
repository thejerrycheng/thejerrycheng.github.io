import os,sys
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR='/tmp/rehearse-mpl',IMAGEIO_FFMPEG_EXE='/opt/homebrew/bin/ffmpeg')
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R.parents[1]/'third_party/depth-anything-3/src'))
import torch,numpy as np,json
from depth_anything_3.api import DepthAnything3
class CPUModel(DepthAnything3):
 @torch.inference_mode()
 def forward(self,image,extrinsics=None,intrinsics=None,export_feat_layers=None,infer_gs=False,use_ray_pose=False,ref_view_strategy='saddle_balanced'):
  return self.model(image,extrinsics,intrinsics,export_feat_layers,infer_gs,use_ray_pose,ref_view_strategy)
newcal=json.loads((R/'calibration/cameras_multiview.json').read_text());cs=newcal['cameras'];Ks=[c['K'] for c in cs];exts=[np.r_[np.c_[c['R_world_to_cv'],c['t_world_to_cv']],[[0,0,0,1]]] for c in cs]
torch.set_num_threads(4);m=CPUModel.from_pretrained(str(R.parents[1]/'models/da3-large')).to('cpu')
pred=m.inference([str(R/'calibration/video_localization/images'/c['image']) for c in cs],extrinsics=np.array(exts,dtype='float32'),intrinsics=np.array(Ks,dtype='float32'),align_to_input_ext_scale=True,process_res=504,ref_view_strategy='middle')
np.savez_compressed(R/'calibration/da3_large.npz',depth=pred.depth,conf=pred.conf,intrinsics=pred.intrinsics,extrinsics=pred.extrinsics,rgb=pred.processed_images)
