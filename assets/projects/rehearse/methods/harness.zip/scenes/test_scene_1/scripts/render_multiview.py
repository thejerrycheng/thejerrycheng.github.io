import bpy,json
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parents[1];A=R/'assets/multiview';cal=json.loads((R/'calibration/cameras_multiview.json').read_text());bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=8;s.render.resolution_x=750;s.render.resolution_y=1000;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard';s.world.color=(.7,.7,.7)
def material(name,path=None,color=(.01,.01,.01,1)):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();o=n.new('ShaderNodeOutputMaterial');sh=n.new('ShaderNodeEmission');sh.inputs['Color'].default_value=color
 if path:t=n.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(path));m.node_tree.links.new(t.outputs['Color'],sh.inputs['Color'])
 m.node_tree.links.new(sh.outputs[0],o.inputs['Surface']);return m
photo=material('Photographs',A/'atlas.jpg');cup=material('Cup',R/'assets/cup_wrap.png');black=material('Lid');floor_mat=material('Inferred carpet',A/'floor.jpg')
for name,mat in [('background',photo),('floor',floor_mat),('cup',cup),('lid',black),('lid_top',photo)]:
 bpy.ops.import_scene.obj(filepath=str(A/f'{name}.obj'),axis_forward='Y',axis_up='Z');o=bpy.context.selected_objects[0];o.name=name;o.data.materials.clear();o.data.materials.append(mat)
 if name not in ['background','floor']:o.location=cal['cup_position']
for c in cal['cameras']:
 bpy.ops.object.camera_add(location=c['position']);o=bpy.context.object;o.name=c['name'];o.rotation_euler=Matrix(c['rotation_camera_to_world_opengl']).to_euler();o.data.sensor_fit='VERTICAL';o.data.sensor_height=24;o.data.lens=c['K'][1][1]/1000*24;o.data.clip_start=.005;s.camera=o;s.render.filepath=str(R/'renders'/f"multiview_{c['name']}.png");bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'scene_multiview.blend'))
for n in ['cup','lid','lid_top']:bpy.data.objects[n].location.z+=.2
s.camera=bpy.data.objects['capture_1207'];s.render.filepath=str(R/'renders/multiview_lifted.png');bpy.ops.render.render(write_still=True)
