from pathlib import Path
import trimesh,numpy as np,json
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT.parents[1]/'website/assets/projects/rehearse';OUT.mkdir(parents=True,exist_ok=True);A=ROOT/'assets';cal=json.loads((ROOT/'calibration/cameras.json').read_text())
scene=trimesh.Scene()
root_transform=np.eye(4);root_transform[:3,3]=cal['cup_position'];scene.graph.update(frame_to='coffee',matrix=root_transform)
for name,tex,pos in [('background_0','photo_0.png',None),('background_side_extension','photo_1.png',None),('table_top','table_atlas.png',None),('coffee_shell','cup_wrap.png',cal['cup_position']),('lid_top','photo_0.png',cal['cup_position'])]:
 m=trimesh.load(A/f'{name}.obj',force='mesh',process=False);m.visual.material=trimesh.visual.material.PBRMaterial(baseColorTexture=Image.open(A/tex).convert('RGB'),metallicFactor=0,roughnessFactor=1,doubleSided=True)
 tr=np.eye(4)
 if pos:scene.add_geometry(m,node_name=name,geom_name=name,parent_node_name='coffee')
 else:scene.add_geometry(m,node_name=name,geom_name=name,transform=tr)
rim=trimesh.creation.cylinder(radius=.045,height=.020,sections=96);rim.apply_translation([0,0,.160]);rim.visual.material=trimesh.visual.material.PBRMaterial(baseColorFactor=[8,8,8,255],roughnessFactor=.25)
scene.add_geometry(rim,node_name='coffee_lid_sidewall',parent_node_name='coffee')
scene.export(OUT/'scene.glb')
(OUT/'cameras.json').write_text(json.dumps(cal,indent=2))
for n in (1207,1208,1209):
 im=Image.open(ROOT/f'source/IMG_{n}.jpg');im.thumbnail((1200,1600));im.save(OUT/f'capture-{n}.webp',quality=88)
 p=ROOT/f'renders/capture_{n}.png'
 if p.exists():Image.open(p).save(OUT/f'render-{n}.webp',quality=86)
 Image.open(ROOT/f'calibration/depth_{n}.jpg').resize((750,1000)).save(OUT/f'depth-{n}.webp',quality=83)
Image.open(A/'generated_clean_table.png').resize((750,1000)).save(OUT/'clean-table.webp',quality=87)
if (ROOT/'renders/coffee_lifted.png').exists():Image.open(ROOT/'renders/coffee_lifted.png').save(OUT/'lifted.webp',quality=86)
for name in ['benchmark','physics_report','sfm_report']:
 p=ROOT/f'calibration/{name}.json'
 if p.exists():(OUT/f'{name}.json').write_bytes(p.read_bytes())
print(OUT)
