from pathlib import Path
import numpy as np,json,pycolmap
R=Path(__file__).resolve().parents[1]
cal=json.loads((R.parent/'test_scene_2/calibration/cameras.json').read_text());rec=pycolmap.Reconstruction(R/'calibration/video_localization/best');B=np.array(cal['raw_to_world_rotation']);s=cal['scale_m_per_sfm_unit'];O=np.array(cal['origin_raw']);cs=[];Ks=[];exts=[]
for name in ['IMG_1207.jpg','IMG_1208.jpg','IMG_1209.jpg']:
 im=next(x for x in rec.images.values() if x.name==name);cam=rec.cameras[im.camera_id];raw=im.cam_from_world();rot=raw.rotation.matrix()@B.T;C=(im.projection_center()-O)@B.T*s;t=-rot@C;K=cam.calibration_matrix();Ks.append(K);exts.append(np.r_[np.c_[rot,t],[[0,0,0,1]]]);cs.append({'name':'capture_'+name[4:8],'image':name,'position':C.tolist(),'R_world_to_cv':rot.tolist(),'t_world_to_cv':t.tolist(),'rotation_camera_to_world_opengl':(rot.T@np.diag([1,-1,-1])).tolist(),'K':K.tolist()})
newcal={'method':'Stills localized against COLMAP video map; camera-conditioned DA3 Large','K':Ks[0].tolist(),'resolution':[750,1000],'metric_scale':'Cup height assumed 17 cm, video supplies additional calibration evidence','table_width':.79,'table_depth':.76,'table_height':.56,'cup_position':[.204,-.18,.55],'cup_height':.168,'cameras':cs};(R/'calibration/cameras_multiview.json').write_text(json.dumps(newcal,indent=2))
