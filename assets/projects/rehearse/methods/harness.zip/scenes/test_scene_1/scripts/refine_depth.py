from pathlib import Path
import numpy as np,json,pycolmap
from scipy.optimize import least_squares
R=Path(__file__).resolve().parents[1];cal=json.loads((R/'calibration/cameras_multiview.json').read_text());world=json.loads((R.parent/'test_scene_2/calibration/cameras.json').read_text());B=np.array(world['raw_to_world_rotation']);s=world['scale_m_per_sfm_unit'];O=np.array(world['origin_raw']);rec=pycolmap.Reconstruction(R/'calibration/video_localization/best');a=dict(np.load(R/'calibration/da3_large.npz'));report=[]
for i,c in enumerate(cal['cameras']):
 d=a['depth'][i];H,W=d.shape;im=next(x for x in rec.images.values() if x.name==c['image']);vals=[];truth=[]
 for pt in im.points2D:
  if not pt.has_point3D():continue
  X=(rec.points3D[pt.point3D_id].xyz-O)@B.T*s;z=(np.array(c['R_world_to_cv'])@X+c['t_world_to_cv'])[2];u,v=np.rint(pt.xy*[W/750,H/1000]).astype(int)
  if 0<=u<W and 0<=v<H and .2<z<12:vals.append(d[v,u]);truth.append(z)
 v=np.array(vals);z=np.array(truth);good=(v>.2)&(abs(v-z)/z<.8);fit=least_squares(lambda p:(p[0]*v[good]+p[1]-z[good])/z[good],[1,0],bounds=([.4,-1],[2,1]),loss='soft_l1',f_scale=.025);a['depth'][i]=np.maximum(.01,d*fit.x[0]+fit.x[1]);report.append({'view':c['name'],'a':float(fit.x[0]),'b':float(fit.x[1]),'median_before':float(np.median(abs(v-z)/z)),'median_after':float(np.median(abs(v*fit.x[0]+fit.x[1]-z)/z))});print(report[-1])
np.savez_compressed(R/'calibration/da3_large_refined.npz',**a);(R/'calibration/depth_refinement.json').write_text(json.dumps(report,indent=2))
