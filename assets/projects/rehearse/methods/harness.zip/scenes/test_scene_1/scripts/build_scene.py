"""Build a physics scene plus a photo-textured depth-mesh appearance baseline."""
from pathlib import Path
import json, numpy as np, cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]; A=ROOT/'assets';cal=json.loads((ROOT/'calibration/cameras.json').read_text());K=np.array(cal['K']);W,H=750,1000
cams=cal['cameras']; cup=np.array(cal['cup_position']);tw=cal['table_width'];td=cal['table_depth'];tz=cal['table_height']
ims=[cv2.resize(cv2.imread(str(ROOT/'source'/c['image'])),(W,H)) for c in cams]
polys=[[[0,565],[68,515],[490,543],[627,887],[610,1000],[0,1000]],[[0,706],[335,579],[740,710],[735,1000],[0,1000]],[[0,578],[95,524],[536,550],[662,933],[651,1000],[0,1000]]]
cup_polys=[[[385,526],[436,526],[465,539],[471,565],[463,584],[442,704],[435,715],[412,720],[385,714],[368,704],[362,580],[358,560],[367,539]],[[458,549],[492,549],[514,558],[523,579],[518,596],[516,700],[507,713],[482,717],[459,711],[451,698],[431,594],[428,578],[436,559]],[[393,515],[444,515],[472,526],[486,552],[486,563],[479,572],[460,714],[450,729],[420,733],[394,727],[376,714],[363,568],[360,553],[368,532]]]
for i,c in enumerate(cams):
 cv2.imwrite(str(A/f'photo_{i}.png'),ims[i]);mask=np.zeros((H,W),np.uint8);cv2.fillPoly(mask,[np.array(cup_polys[i])],255);cv2.imwrite(str(A/f'cup_mask_{i}.png'),mask)
# Keep original pixels except the generated patch around cup and shadow in side view.
gen=cv2.resize(cv2.imread(str(A/'generated_clean_table.png')),(W,H)); clean=gen.copy();cv2.imwrite(str(A/'table_clean.png'),clean)

def project(X,i):
 c=cams[i];R=np.array(c['R_world_to_cv']);t=np.array(c['t_world_to_cv']);p=X@R.T+t;q=p@K.T;return q[:,:2]/q[:,2:],p[:,2]

def obj(name,v,uv,faces):
 # Non-colliding visual meshes still need nonzero convex hull volume in MuJoCo.
 v=np.array(v);uv=np.array(uv);faces=np.array(faces)
 if len(v)<4 or np.linalg.matrix_rank(v-v.mean(0),tol=1e-7)<3:
  v=np.vstack([v,v[0]+[0,0,-.00002]]);uv=np.vstack([uv,uv[0]])
 with (A/f'{name}.obj').open('w') as f:
  for a in v:f.write('v '+' '.join(f'{x:.7f}' for x in a)+'\n')
  for a in uv:f.write('vt '+' '.join(f'{x:.7f}' for x in a)+'\n')
  for a in faces:f.write('f '+' '.join(f'{int(x)+1}/{int(x)+1}' for x in a)+'\n')
 return name
# Build world-space background depth meshes. Fit affine inverse depth to known table plane.
background=[];depthreport=[]
for i,c in enumerate(cams):
 n=c['image'][4:8];d=cv2.resize(np.load(ROOT/f'calibration/depth_{n}.npy'),(W,H));R=np.array(c['R_world_to_cv']);C=np.array(c['position'])
 yy,xx=np.mgrid[0:H,0:W];rays=np.stack([(xx-W/2)/K[0,0],(yy-H/2)/K[1,1],np.ones_like(xx)],-1);rw=rays@R
 ztrue=(tz-C[2])/rw[:,:,2];X=C+ztrue[:,:,None]*rw
 table=(abs(X[:,:,0])<tw/2-.035)&(abs(X[:,:,1])<td/2-.035)&(ztrue>.1)&(ztrue<2)
 mask=cv2.imread(str(A/f'cup_mask_{i}.png'),0);table&=cv2.dilate(mask,np.ones((51,51),np.uint8))==0
 rows,cols=np.where(table);rows,cols=rows[::12],cols[::12]
 xxfit=d[rows,cols];yfit=1/ztrue[rows,cols]
 fit=least_squares(lambda p:p[0]*xxfit+p[1]-yfit,[.03,.1],bounds=([.001,-1],[.2,1]),loss='soft_l1',f_scale=.03)
 inv=fit.x[0]*d+fit.x[1];depth=1/np.clip(inv,1/6,1/.25)
 depth=cv2.bilateralFilter(depth.astype(np.float32),7,.1,4)
 np.save(ROOT/f'calibration/aligned_depth_{n}.npy',depth)
 depthreport.append({'image':n,'inverse_depth_scale':float(fit.x[0]),'inverse_depth_shift':float(fit.x[1]),'table_inverse_depth_mae':float(np.mean(abs(fit.fun))),'depth_type':'monocular relative depth anchored to assumed table geometry'})
 step=5;gy,gx=np.mgrid[0:H:step,0:W:step];z=depth[gy,gx];r=rays[gy,gx];verts=(C+(r*z[:,:,None])@R).reshape(-1,3); below=verts[:,2]<.004; rays_world=(r@R).reshape(-1,3); floor_distance=(.004-C[2])/rays_world[:,2]; verts[below]=C+rays_world[below]*floor_distance[below,None]; uv=np.c_[gx.ravel()/W,1-gy.ravel()/H]
 remove=np.zeros((H,W),np.uint8);cv2.fillPoly(remove,[np.array(polys[i])],255);remove=cv2.bitwise_or(remove,cv2.dilate(mask,np.ones((9,9),np.uint8)))
 valid=(remove[gy,gx]==0).ravel()
 # Reject dynamic pedestrian visible only in capture 1209.
 if i==2:valid&=~((gx.ravel()<90)&(gy.ravel()>220)&(gy.ravel()<460))
 faces=[];nh,nw=z.shape
 for y in range(nh-1):
  for x in range(nw-1):
   a=y*nw+x;b=a+1;cc=a+nw;dd=cc+1
   for face in [[a,cc,b],[b,cc,dd]]:
    if valid[face].all() and np.ptp(z.ravel()[face])<.35+np.mean(z.ravel()[face])*.1:faces.append(face)
 obj(f'background_{i}',verts,uv,faces);background.append((verts,uv,np.array(faces)))
 # Save a point cloud for independent reconstruction evaluation.
 cols=ims[i][gy,gx][:,:,::-1].reshape(-1,3)
 np.savez_compressed(ROOT/f'calibration/cloud_{n}.npz',xyz=verts[valid],rgb=cols[valid],camera=i)
(ROOT/'calibration/depth_alignment.json').write_text(json.dumps(depthreport,indent=2))
# Composite background only adds side-view triangles outside the first camera's support.
v,uv,faces=background[1];q,zz=project(v,0);outside=(q[:,0]<2)|(q[:,0]>W-3)|(q[:,1]<2)|(q[:,1]>H-3)|(zz<0)
obj('background_side_extension',v,uv,faces[np.all(outside[faces],axis=1)])
# Bake a single world-aligned table atlas from visible photo pixels.
size=1024
xx,yy=np.meshgrid(np.linspace(-tw/2,tw/2,size),np.linspace(td/2,-td/2,size));X=np.c_[xx.ravel(),yy.ravel(),np.full(size*size,tz)]
acc=np.zeros((size*size,3));weights=np.zeros(size*size)
for i in [0,2,1]:
 q,zz=project(X,i);qx=q[:,0].astype('float32').reshape(size,size);qy=q[:,1].astype('float32').reshape(size,size)
 src=clean if i==1 else ims[i]
 color=cv2.remap(src,qx,qy,cv2.INTER_LINEAR).reshape(-1,3).astype(float)
 border=np.minimum.reduce([q[:,0],W-1-q[:,0],q[:,1],H-1-q[:,1]])
 mask=cv2.imread(str(A/f'cup_mask_{i}.png'),0)
 occ=cv2.remap(cv2.dilate(mask,np.ones((31,31),np.uint8)),qx,qy,cv2.INTER_NEAREST).ravel()>0
 weight=np.clip(border/55,0,1)*(zz>0)*(1 if i==0 else .4)
 if i!=1:weight[occ]=0
 acc+=color*weight[:,None];weights+=weight
atlas=acc/np.maximum(weights[:,None],1e-6);atlas[weights==0]=[196,198,198]
cv2.imwrite(str(A/'table_atlas.png'),atlas.reshape(size,size,3).astype('uint8'))
x,y=np.meshgrid(np.linspace(-tw/2,tw/2,30),np.linspace(-td/2,td/2,30));v=np.c_[x.ravel(),y.ravel(),np.full(x.size,tz+.00015)];uv=np.c_[x.ravel()/tw+.5,y.ravel()/td+.5];faces=[]
for y in range(29):
 for x in range(29):
  a=y*30+x;faces.extend([[a,a+1,a+30],[a+1,a+31,a+30]])
obj('table_top',v,uv,faces)
# Cup UV atlas uses the best-facing observed camera for each texel.
nu,nv=1024,512;uu,vv=np.meshgrid(np.arange(nu)/nu,np.arange(nv)/(nv-1));ang=uu*2*np.pi;z=(1-vv)*.15;r=.032+(.044-.032)*z/.15
v=np.stack([r*np.cos(ang),r*np.sin(ang),z],-1).reshape(-1,3);norm=np.c_[np.cos(ang).ravel(),np.sin(ang).ravel(),np.full(nu*nv,-.08)];best=np.full(len(v),-1.);colors=np.tile([66.,73.,83.],(len(v),1));seen=np.zeros(len(v),bool)
for i,c in enumerate(cams):
 q,zz=project(v+cup,i);tow=np.array(c['position'])-(v+cup);tow/=np.linalg.norm(tow,axis=1)[:,None];score=np.sum(norm*tow,axis=1)
 ok=(q[:,0]>1)&(q[:,0]<W-2)&(q[:,1]>1)&(q[:,1]<H-2)&(score>.15)&(zz>0)&(score>best)
 cc=cv2.remap(ims[i],q[:,0].astype('float32').reshape(nv,nu),q[:,1].astype('float32').reshape(nv,nu),cv2.INTER_LINEAR).reshape(-1,3);colors[ok]=cc[ok];best[ok]=score[ok];seen|=ok
# Unseen back retains a conservative brown material and white bottom strip.
colors[(~seen)&(v[:,2]<.012)]=[205,211,211]
cv2.imwrite(str(A/'cup_wrap.png'),colors.reshape(nv,nu,3).astype('uint8'))
cv2.imwrite(str(A/'cup_texture_observed.png'),seen.reshape(nv,nu).astype('uint8')*255)
N=128;zs=[0,.012,.15];vs=[];uvs=[]
for zz in zs:
 rr=.032+(.044-.032)*zz/.15
 for j in range(N+1):
  th=j/N*2*np.pi;vs.append([rr*np.cos(th),rr*np.sin(th),zz]);uvs.append([j/N,zz/.15])
fs=[]
for k in range(len(zs)-1):
 for j in range(N):
  a=k*(N+1)+j;fs.extend([[a,a+1,a+N+1],[a+1,a+N+2,a+N+1]])
obj('coffee_shell',vs,uvs,fs)
# Top lid texture is projected from capture 1207 onto actual disk geometry.
vs=[[0,0,.17]]+[[.043*np.cos(t),.043*np.sin(t),.17] for t in np.linspace(0,2*np.pi,N,endpoint=False)];q,_=project(np.array(vs)+cup,0);obj('lid_top',vs,np.c_[q[:,0]/W,1-q[:,1]/H],[[0,j+1,(j+1)%N+1] for j in range(N)])
# Closed tapered convex cup collision mesh; isolated from visual shell.
vs=[[r*np.cos(t),r*np.sin(t),z] for r,z in [(.032,0),(.044,.15)] for t in np.linspace(0,2*np.pi,32,endpoint=False)]
fs=[]
for j in range(32):k=(j+1)%32;fs.extend([[j,k,j+32],[k,k+32,j+32]])
for j in range(1,31):fs.extend([[0,j+1,j],[32,32+j,33+j]])
obj('coffee_collision',vs,np.zeros((64,2)),fs)

def fmt(v):return ' '.join(f'{float(x):.8g}' for x in np.asarray(v).ravel())
def make(variant='hybrid'):
 root=ET.Element('mujoco',model='test_scene_1');ET.SubElement(root,'compiler',angle='radian',meshdir='assets',texturedir='assets');ET.SubElement(root,'option',timestep='.002',integrator='implicitfast',cone='elliptic',gravity='0 0 -9.81');ET.SubElement(root,'statistic',center=f'{cup[0]} {cup[1]} .8',extent='2')
 vis=ET.SubElement(root,'visual');ET.SubElement(vis,'global',offwidth='1200',offheight='1600');ET.SubElement(vis,'headlight',ambient='.65 .65 .65',diffuse='.3 .3 .3',specular='.05 .05 .05');ET.SubElement(vis,'map',znear='.005',zfar='30')
 default=ET.SubElement(root,'default');ET.SubElement(default,'geom',friction='.8 .005 .0001',condim='4',solref='.015 1');dv=ET.SubElement(default,'default',attrib={'class':'visual'});ET.SubElement(dv,'geom',contype='0',conaffinity='0',group='1',mass='0')
 asset=ET.SubElement(root,'asset')
 for name,file in [(f'photo_{i}',f'photo_{i}.png') for i in range(3)]+[('cup_wrap','cup_wrap.png'),('table_clean','table_atlas.png')]:
  ET.SubElement(asset,'texture',name=name,type='2d',file=file);ET.SubElement(asset,'material',name=name,texture=name,texuniform='false',emission='1',specular='0',shininess='0')
 meshes=['table_top','coffee_shell','lid_top','coffee_collision','background_0','background_1','background_2','background_side_extension']
 for m in meshes:ET.SubElement(asset,'mesh',name=m,file=m+'.obj',inertia='convex' if m=='coffee_collision' else 'shell')
 world=ET.SubElement(root,'worldbody');ET.SubElement(world,'light',pos='0 -1 3',dir='0 0 -1',diffuse='.3 .3 .3',castshadow='true')
 ET.SubElement(world,'geom',name='floor_collision',type='plane',size='6 6 .1',rgba='.52 .49 .43 1',group='0')
 ET.SubElement(world,'geom',name='table_collision',type='box',pos=f'0 0 {tz/2}',size=f'{tw/2} {td/2} {tz/2}',rgba='.72 .72 .71 1')
 ET.SubElement(world,'geom',name='table_surface',type='mesh',mesh='table_top',material='table_clean',attrib={'class':'visual'})
 bgs=[('background_0','photo_0'),('background_side_extension','photo_1')] if variant=='hybrid' else [(f'background_{variant}',f'photo_{variant}')]
 for mesh,mat in bgs:ET.SubElement(world,'geom',name=mesh,type='mesh',mesh=mesh,material=mat,attrib={'class':'visual'})
 body=ET.SubElement(world,'body',name='coffee',pos=fmt(cup+[0,0,.0006]));ET.SubElement(body,'freejoint',name='coffee_free');ET.SubElement(body,'inertial',pos='0 0 .075',mass='.32',diaginertia='.00082 .00082 .00027')
 ET.SubElement(body,'geom',name='coffee_contact',type='mesh',mesh='coffee_collision',rgba='0 0 0 0',group='3')
 ET.SubElement(body,'geom',name='lid_contact',type='cylinder',size='.045 .009',pos='0 0 .159',rgba='.018 .018 .018 1',group='0')
 ET.SubElement(body,'geom',name='coffee_visual',type='mesh',mesh='coffee_shell',material='cup_wrap',attrib={'class':'visual'})
 ET.SubElement(body,'geom',name='lid_visual',type='mesh',mesh='lid_top',material='photo_0',attrib={'class':'visual'})
 ET.SubElement(body,'site',name='coffee_grasp',pos='0 0 .085',size='.003',rgba='0 0 0 0');ET.SubElement(world,'site',name='robot_spawn',pos='-.55 -.15 .75',size='.01',rgba='0 0 0 0')
 for i,c in enumerate(cams):
  rot=np.array(c['rotation_camera_to_world_opengl']);quat=Rotation.from_matrix(rot).as_quat()[[3,0,1,2]]
  ET.SubElement(world,'camera',name=c['name'],pos=fmt(c['position']),quat=fmt(quat),fovy=str(np.degrees(2*np.arctan(H/(2*K[1,1])))))
  C=np.array(c['position']);R=np.array(c['R_world_to_cv']);corners=np.array([[-W/2/K[0,0],-H/2/K[1,1],1],[W/2/K[0,0],-H/2/K[1,1],1],[W/2/K[0,0],H/2/K[1,1],1],[-W/2/K[0,0],H/2/K[1,1],1]])*.16@R+C
  color=['.1 .5 1 1','.95 .4 .1 1','.2 .7 .4 1'][i]
  for j in range(4):
   for aa,bb in [(C,corners[j]),(corners[j],corners[(j+1)%4])]:ET.SubElement(world,'geom',name=f'camera_{i}_edge_{j}_{int(np.all(aa==C))}',type='capsule',fromto=fmt(np.r_[aa,bb]),size='.0015',rgba=color,group='5',contype='0',conaffinity='0')
 ET.indent(root);ET.ElementTree(root).write(ROOT/('scene.xml' if variant=='hybrid' else f'scene_view_{variant}.xml'),encoding='unicode')
for variant in ['hybrid',0,1,2]:make(variant)
print('Built scene.xml and 3 diagnostic single-view depth meshes.')
