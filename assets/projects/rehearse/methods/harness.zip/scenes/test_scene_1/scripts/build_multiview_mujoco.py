from pathlib import Path
import numpy as np,json,trimesh,xml.etree.ElementTree as ET
from PIL import Image
from scipy.spatial.transform import Rotation
import mujoco
R=Path(__file__).resolve().parents[1];A=R/'assets/multiview';cal=json.loads((R/'calibration/cameras_multiview.json').read_text());Image.open(A/'atlas.jpg').save(A/'atlas.png');Image.open(A/'floor.jpg').save(A/'floor.png');Image.open(R/'assets/cup_wrap.png').save(A/'cup_wrap.png')
def t(x):return ' '.join(str(float(v)) for v in x)
root=ET.Element('mujoco',model='Rehearse_scene_01_multiview');ET.SubElement(root,'compiler',angle='radian',meshdir='assets/multiview',texturedir='assets/multiview');ET.SubElement(root,'option',timestep='.002',integrator='implicitfast');asset=ET.SubElement(root,'asset');world=ET.SubElement(root,'worldbody');ET.SubElement(world,'geom',name='floor_contact',type='plane',size='5 5 .1',pos='0 0 -.08',rgba='.4 .4 .4 0')
for name,file in [('photo','atlas.png'),('cup_photo','cup_wrap.png'),('floor_photo','floor.png')]:ET.SubElement(asset,'texture',name=name,type='2d',file=file);ET.SubElement(asset,'material',name=name,texture=name,emission='1',specular='0')
for name in ['background','floor','cup','lid','lid_top']:ET.SubElement(asset,'mesh',name=name,file=name+'.obj')
for name,mat in [('background','photo'),('floor','floor_photo')]:ET.SubElement(world,'geom',type='mesh',mesh=name,material=mat,contype='0',conaffinity='0',mass='0',group='2')
corn=np.array(cal['table_corners']);bot=corn.copy();bot[:,2]=-.08;proxy=trimesh.convex.convex_hull(np.r_[corn,bot]);proxy.export(A/'table_collision.obj');ET.SubElement(asset,'mesh',name='table_collision',file='table_collision.obj');ET.SubElement(world,'geom',type='mesh',mesh='table_collision',rgba='.5 .5 .5 0',group='3',friction='.8 .01 .001')
body=ET.SubElement(world,'body',name='coffee',pos=t(cal['cup_position']));ET.SubElement(body,'freejoint',name='coffee_free');ET.SubElement(body,'inertial',pos=t([0,0,cal['cup_height']/2]),mass='.35',diaginertia='.001 .001 .0004')
for name,mat in [('cup','cup_photo'),('lid_top','photo')]:ET.SubElement(body,'geom',name=name+'_appearance',type='mesh',mesh=name,material=mat,mass='0',contype='0',conaffinity='0',group='2')
ET.SubElement(body,'geom',name='lid_sidewall',type='mesh',mesh='lid',rgba='.025 .025 .025 1',mass='0',contype='0',conaffinity='0',group='2');ET.SubElement(body,'geom',type='cylinder',size=t([.043,cal['cup_height']/2]),pos=t([0,0,cal['cup_height']/2]),rgba='.3 .3 .3 0',group='3',friction='.8 .01 .001')
for c in cal['cameras']:
 q=Rotation.from_matrix(c['rotation_camera_to_world_opengl']).as_quat();ET.SubElement(world,'camera',name=c['name'],pos=t(c['position']),quat=t(np.r_[q[3],q[:3]]),fovy=str(2*np.degrees(np.arctan(500/c['K'][1][1]))))
ET.indent(root);ET.ElementTree(root).write(R/'scene_multiview.xml',encoding='unicode');m=mujoco.MjModel.from_xml_path(str(R/'scene_multiview.xml'));d=mujoco.MjData(m)
for i in range(1000):mujoco.mj_step(m,d)
report={'finite':bool(np.isfinite(d.qpos).all()),'settle_speed':float(abs(d.qvel).max()),'warnings':[int(w.number) for w in d.warning],'cup_final_position':d.qpos[:3].tolist(),'assumptions':'17 cm reference scale from video; cup dimensions inferred; mass 0.35 kg and friction 0.8 assumed'};(R/'calibration/multiview_physics.json').write_text(json.dumps(report,indent=2));print(report)
