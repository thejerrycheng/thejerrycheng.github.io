"""Three-view SIFT SfM; EXIF focal prior, essential matrix, PnP, robust BA."""
from pathlib import Path
import cv2, numpy as np, json
from scipy.optimize import least_squares
from scipy.sparse import lil_matrix
ROOT=Path(__file__).resolve().parents[1]
ids=[1207,1209,1208]; W,H=1200,1600
f=24/np.hypot(36,24)*np.hypot(W,H)
K=np.array([[f,0,W/2],[0,f,H/2],[0,0,1.]])
ims=[cv2.resize(cv2.imread(str(ROOT/f'source/IMG_{n}.jpg')),(W,H)) for n in ids]
sift=cv2.SIFT_create(nfeatures=40000,contrastThreshold=.018)
feat=[sift.detectAndCompute(im,None) for im in ims]
pts=[np.array([p.pt for p in k]) for k,d in feat]
bf=cv2.BFMatcher(); matches={}; rawmatches={}; report={'focal_prior':f,'resolution':[W,H],'pairs':{}}
for i,j in [(0,1),(0,2),(1,2)]:
 mm=bf.knnMatch(feat[i][1],feat[j][1],k=2)
 good=[(a.queryIdx,a.trainIdx) for a,b in mm if a.distance<.85*b.distance]
 ij=np.array(good); rawmatches[i,j]=ij.copy(); a,b=pts[i][ij[:,0]],pts[j][ij[:,1]]
 E,mask=cv2.findEssentialMat(a,b,K,method=cv2.RANSAC,prob=.999,threshold=1.3)
 count,R,t,posemask,_=cv2.recoverPose(E,a,b,K,distanceThresh=1000,mask=mask)
 keep=posemask.ravel()>0
 matches[i,j]=(ij[keep],R,t)
 report['pairs'][f'{ids[i]}_{ids[j]}']={'ratio_matches':len(good),'essential_inliers':int(count)}
 print(report['pairs'],flush=True)
 # Diagnostic matching overlay, capped to reduce clutter.
 mvis=[cv2.DMatch(int(x),int(y),0) for x,y in ij[keep][::max(1,count//90)]]
 vis=cv2.drawMatches(ims[i],feat[i][0],ims[j],feat[j][0],mvis,None,flags=2)
 cv2.imwrite(str(ROOT/f'calibration/matches_{ids[i]}_{ids[j]}.jpg'),cv2.resize(vis,(1200,800)))
ij,R,t=matches[0,1]
P0=K@np.c_[np.eye(3),np.zeros(3)];P1=K@np.c_[R,t]
Xh=cv2.triangulatePoints(P0,P1,pts[0][ij[:,0]].T,pts[1][ij[:,1]].T);X=(Xh[:3]/Xh[3]).T
ok=(X[:,2]>0)&(X[:,2]<500)
X=X[ok];ij=ij[ok]
map02=dict(rawmatches[0,2]); map12=dict(rawmatches[1,2]); obs=[]
for k,(a,b) in enumerate(ij):
 obs.extend([(0,k,*pts[0][a]),(1,k,*pts[1][b])])
 c=map02.get(a,map12.get(b))
 if c is not None: obs.append((2,k,*pts[2][c]))
obs=np.array(obs); o3=obs[obs[:,0]==2]; print('third view tracks',len(o3),flush=True)
ret,rv,tv,ins=cv2.solvePnPRansac(X[o3[:,1].astype(int)],o3[:,2:],K,None,iterationsCount=2000,reprojectionError=3,flags=cv2.SOLVEPNP_EPNP)
if not ret: raise RuntimeError('Third camera PnP failed')
# Drop third-view outliers before BA.
keep3=set(ins.ravel()); n=0; filtered=[]
for o in obs:
 if o[0]==2:
  if n in keep3: filtered.append(o)
  n+=1
 else: filtered.append(o)
obs=np.array(filtered); ci=obs[:,0].astype(int); pi=obs[:,1].astype(int)
cams=np.array([np.zeros(6),np.r_[cv2.Rodrigues(R)[0].ravel(),t.ravel()],np.r_[rv.ravel(),tv.ravel()]])
x0=np.r_[cams[1:].ravel(),X.ravel()]
sp=lil_matrix((len(obs)*2+1,len(x0)),dtype=int)
for q,(c,p) in enumerate(zip(ci,pi)):
 if c: sp[q*2:q*2+2,(c-1)*6:c*6]=1
 sp[q*2:q*2+2,12+3*p:15+3*p]=1
sp[-1,3:6]=1

def residual(x):
 cs=np.vstack([np.zeros(6),x[:12].reshape(2,6)]);xx=x[12:].reshape(-1,3);pred=np.zeros((len(obs),2))
 for c in range(3):
  ix=ci==c; pred[ix]=cv2.projectPoints(xx[pi[ix]],cs[c,:3],cs[c,3:],K,None)[0][:,0]
 return np.r_[(pred-obs[:,2:]).ravel(),(np.linalg.norm(cs[1,3:])-1)*100]
sol=least_squares(residual,x0,jac_sparsity=sp.tocsr(),loss='soft_l1',f_scale=1.,max_nfev=100,verbose=0)
cams=np.vstack([np.zeros(6),sol.x[:12].reshape(2,6)]);X=sol.x[12:].reshape(-1,3)
errors=np.linalg.norm(residual(sol.x)[:-1].reshape(-1,2),axis=1)
report.update(points=len(X),observations=len(obs),reprojection_median_px=float(np.median(errors)),reprojection_p95_px=float(np.percentile(errors,95)),pnp_inliers=len(ins))
np.savez(ROOT/'calibration/sfm.npz',K=K,cams=cams,X=X,obs=obs,ids=ids,errors=errors)
(ROOT/'calibration/sfm_report.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
