"""Localize the three original stills against the later video map; keep video calibration fixed."""
from pathlib import Path
import shutil,json,pycolmap
from PIL import Image
R=Path(__file__).resolve().parents[1];V=R.parent/'test_scene_2';out=R/'calibration/video_localization';out.mkdir(exist_ok=True);frames=out/'images';frames.mkdir(exist_ok=True)
for p in (V/'source/frames').glob('*.jpg'):
 q=frames/p.name
 if not q.exists():q.symlink_to(p)
for n in ['1207','1208','1209']:
 im=Image.open(R/f'source/IMG_{n}.jpg');im.thumbnail((1000,1000));im.save(frames/f'IMG_{n}.jpg')
db=out/'database.db'
if not db.exists():shutil.copy2(V/'calibration/colmap/database.db',db)
opts=pycolmap.FeatureExtractionOptions();opts.num_threads=4;opts.sift.max_num_features=12000
pycolmap.extract_features(db,frames,camera_mode=pycolmap.CameraMode.AUTO,reader_options={'camera_model':'SIMPLE_RADIAL'},extraction_options=opts,device=pycolmap.Device.cpu)
mo=pycolmap.FeatureMatchingOptions();mo.num_threads=4;mo.guided_matching=True
pycolmap.match_exhaustive(db,matching_options=mo,device=pycolmap.Device.cpu)
opts=pycolmap.IncrementalPipelineOptions();opts.num_threads=4;opts.fix_existing_frames=True
maps=pycolmap.incremental_mapping(db,frames,out/'sparse',options=opts,input_path=V/'calibration/colmap/best')
best=max(maps.values(),key=lambda x:x.num_reg_images());(out/'best').mkdir(exist_ok=True);best.write(out/'best');best.write_text(out/'best');print('registered',best.num_reg_images(),flush=True)
