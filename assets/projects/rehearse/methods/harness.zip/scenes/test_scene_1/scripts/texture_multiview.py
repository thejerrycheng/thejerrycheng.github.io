from pathlib import Path
import numpy as np,json,trimesh,cv2,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'test_scene_2/scripts'))
from solid_assets import gridquad
from PIL import Image
R=Path(__file__).resolve().parents[1];A=R/'assets/multiview';cal=json.loads((R/'calibration/cameras_multiview.json').read_text());data=np.load(R/'calibration/da3_large_refined.npz');m=trimesh.load(A/'fused.ply',process=False);V=m.vertices;F=m.faces;X=m.triangles_center;C=np.array(cal['cup_position']);h=cal['cup_height'];keep=~((np.linalg.norm(X[:,:2]-C[:2],axis=1)<.065)&(X[:,2]>C[2]-.006)&(X[:,2]<C[2]+h+.06));keep &= ~((X[:,0]>-.39)&(X[:,0]<.41)&(X[:,1]>-.42)&(X[:,1]<.4)&(X[:,2]<.62))
F=F[keep];corn=np.array(cal['table_corners']);parts=[gridquad(corn)]
for i in range(4):
 a=corn[i].copy();b=corn[(i+1)%4].copy();aa=a.copy();bb=b.copy();aa[2]=bb[2]=-.075;parts.append(gridquad([aa,bb,b,a]))
# A fitted vertical glass-plane patch fills reflective-depth gaps; kept behind observed surfaces.
glass=gridquad([[.865,.5,.35],[1.08,5,.35],[1.08,5,2.8],[.865,.5,2.8]],40);gc=cal['cameras'][0];gg=glass.triangles_center@np.array(gc['R_world_to_cv']).T+gc['t_world_to_cv'];gk=np.array(gc['K']);gu=gg[:,:2]/gg[:,2:]*[gk[0,0],gk[1,1]]+[375,500];gkeep=(gu[:,0]>475)&(gu[:,0]<735)&(gu[:,1]>0)&(gu[:,1]<370);glass=glass.submesh([np.where(gkeep)[0]],append=True);parts.append(glass)
for part in parts:F=np.r_[F,part.faces+len(V)];V=np.r_[V,part.vertices]
X=V[F].mean(1);N=trimesh.Trimesh(V,F,process=False).face_normals
atlas=Image.new('RGB',(1500,2000),(180,178,169));best=np.full(len(F),-1e7);uv=np.zeros((len(F),3,2));views=np.zeros(len(F),int)
for index in range(4):
 i=index if index<3 else 1;c=cal['cameras'][i];K=np.array(c['K']);im=Image.open(R/'source'/c['image']).resize((750,1000)) if index<3 else Image.open(R/'assets/generated_clean_table.png').resize((750,1000));atlas.paste(im,((index%2)*750,(index//2)*1000));P=V[F]@np.array(c['R_world_to_cv']).T+c['t_world_to_cv'];q=P[:,:,:2]/P[:,:,2:]*[K[0,0],K[1,1]]+[375,500];ok=(P[:,:,2]>.1).all(1)&(q[:,:,0]>1).all(1)&(q[:,:,0]<749).all(1)&(q[:,:,1]>1).all(1)&(q[:,:,1]<999).all(1);idx=np.where(ok)[0];mid=q[idx].mean(1);d=data['depth'][i];hh,ww=d.shape;depth=d[(mid[:,1]*hh/1000).astype(int),(mid[:,0]*ww/750).astype(int)];err=abs(P[idx,:,2].mean(1)-depth);direc=np.array(c['position'])-X[idx];dist=np.linalg.norm(direc,axis=1);score=abs((direc*N[idx]).sum(1))/dist-dist*.06-err*10;score+=.4*(i==0);score[err>.2]-=20
 if index==3:
  top=(abs(X[idx,0])<.43)&(abs(X[idx,1])<.43)&(X[idx,2]>.48)&(X[idx,2]<.6)&(abs(N[idx,2])>.7);score[~top]=-1e8;score[top]=100
 update=score>best[idx];idx=idx[update];best[idx]=score[update];uv[idx]=q[idx];views[idx]=index
uv[:,:,0]=(uv[:,:,0]+(views%2)[:,None]*750)/1500;uv[:,:,1]=1-(uv[:,:,1]+(views//2)[:,None]*1000)/2000;atlas.save(A/'atlas.jpg',quality=95);mat=trimesh.visual.material.PBRMaterial(baseColorTexture=Image.open(A/'atlas.jpg'),doubleSided=True,metallicFactor=0,roughnessFactor=1)
mask=best>-1e6;v=V[F[mask]].reshape(-1,3);mesh=trimesh.Trimesh(v,np.arange(len(v)).reshape(-1,3),process=False);mesh.visual=trimesh.visual.TextureVisuals(uv=uv[mask].reshape(-1,2),material=mat);mesh.export(A/'background.obj');scene=trimesh.Scene();scene.add_geometry(mesh,node_name='background',geom_name='background');tf=np.eye(4);tf[:3,3]=C;scene.graph.update(frame_to='coffee',matrix=tf)
# Existing photographic cup wrap, new geometry and calibrated pose. Lid and shell share coffee parent.
N=96;verts=[];faces=[];tex=[]
for z,r in [(0,.032),(.012,.033),(h-.02,.044)]:
 for i in range(N+1):
  a=2*np.pi*i/N;verts.append([r*np.cos(a),r*np.sin(a),z]);tex.append([i/N,z/(h-.02)])
for j in range(2):
 for i in range(N):k=j*(N+1)+i;faces.extend([[k,k+1,k+N+2],[k,k+N+2,k+N+1]])
cup=trimesh.Trimesh(verts,faces,process=False);cup.visual=trimesh.visual.TextureVisuals(uv=tex,material=trimesh.visual.material.PBRMaterial(baseColorTexture=Image.open(R/'assets/cup_wrap.png'),doubleSided=True,roughnessFactor=1,metallicFactor=0));scene.add_geometry(cup,node_name='coffee_shell',geom_name='coffee_shell',parent_node_name='coffee');cup.export(A/'cup.obj')
lid=trimesh.creation.cylinder(radius=.046,height=.020,sections=96);lid.apply_translation([0,0,h-.010]);lid.visual=trimesh.visual.ColorVisuals(lid,vertex_colors=[14,15,16,255]);scene.add_geometry(lid,node_name='coffee_lid',geom_name='coffee_lid',parent_node_name='coffee');lid.export(A/'lid.obj')
# Photo textured top disk from original source view, flush with the connected lid sidewall.
top=trimesh.creation.annulus(r_min=.0001,r_max=.045,height=.0003,sections=96);top.apply_translation([0,0,h+.0002]);p=top.vertices+C;c=cal['cameras'][0];z=p@np.array(c['R_world_to_cv']).T+c['t_world_to_cv'];K=np.array(c['K']);q=z[:,:2]/z[:,2:]*[K[0,0],K[1,1]]+[375,500];tex=np.c_[q[:,0]/1500,1-q[:,1]/2000];top.visual=trimesh.visual.TextureVisuals(uv=tex,material=mat);scene.add_geometry(top,node_name='lid_photo_top',geom_name='lid_photo_top',parent_node_name='coffee');top.export(A/'lid_top.obj');floor=gridquad([[-4,-1.5,-.08],[1.2,-1.5,-.08],[1.2,12,-.08],[-4,12,-.08]],80);vc=json.loads((R.parent/'test_scene_2/calibration/cameras.json').read_text());cam=vc['cameras'][12];kk=np.array(vc['K']);pp=floor.vertices[floor.faces];zz=pp@np.array(cam['R_world_to_cv']).T+cam['t_world_to_cv'];qq=zz[:,:,:2]/zz[:,:,2:]*[kk[0,0],kk[1,1]]+[480,360];good=(zz[:,:,2]>.1).all(1)&(qq[:,:,0]>5).all(1)&(qq[:,:,0]<780).all(1)&(qq[:,:,1]>40).all(1)&(qq[:,:,1]<715).all(1);qq[~good,:,0]=200+(pp[~good,:,0]%.7)/.7*180;qq[~good,:,1]=150+(pp[~good,:,1]%.7)/.7*180;uu=np.stack([qq[:,:,0]/960,1-qq[:,:,1]/720],axis=-1).reshape(-1,2);vv=pp.reshape(-1,3);floor=trimesh.Trimesh(vv,np.arange(len(vv)).reshape(-1,3),process=False);fim=Image.open(R.parent/'test_scene_2/assets/generated_clean_floor.png');fim.save(A/'floor.jpg');floor.visual=trimesh.visual.TextureVisuals(uv=uu,material=trimesh.visual.material.PBRMaterial(baseColorTexture=fim,doubleSided=True,roughnessFactor=1,metallicFactor=0));floor.export(A/'floor.obj');scene.add_geometry(floor,node_name='inferred_floor',geom_name='inferred_floor');scene.export(A/'scene.glb');print('exported',len(mesh.faces),'background faces')
