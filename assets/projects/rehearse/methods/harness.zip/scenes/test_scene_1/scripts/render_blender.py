"""CPU visual QA renderer using exactly the exported scene assets and camera poses."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Matrix
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'assets';cal=json.loads((ROOT/'calibration/cameras.json').read_text());cup=cal['cup_position']
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=12;s.cycles.use_denoising=False;s.render.resolution_x=750;s.render.resolution_y=1000;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard';s.world.color=(.4,.4,.4)

def mat(name,file=None,color=(.7,.7,.7,1)):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');shader=n.new('ShaderNodeEmission') if file else n.new('ShaderNodeBsdfDiffuse')
 if file:
  tex=n.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(A/file));m.node_tree.links.new(tex.outputs['Color'],shader.inputs['Color'])
 else:shader.inputs['Color'].default_value=color
 m.node_tree.links.new(shader.outputs[0],out.inputs['Surface']);return m
mats={f'photo_{i}':mat(f'photo_{i}',f'photo_{i}.png') for i in range(3)};mats.update(table=mat('table','table_atlas.png'),cup=mat('cup','cup_wrap.png'),white=mat('white',color=(.66,.66,.65,1)),black=mat('lid',color=(.018,.018,.018,1)),floor=mat('floor',color=(.36,.33,.29,1)))
def mesh(name,material,loc=None):
 bpy.ops.import_scene.obj(filepath=str(A/f'{name}.obj'));o=bpy.context.selected_objects[0];o.data.materials.clear();o.data.materials.append(mats[material]);
 if loc:o.location=loc
 return o
# Blender importer converts OBJ forward axis by default; explicit import axes restore raw world coordinates.
# Files use z-up coordinates; correct import defaults by clearing the importer rotation.
def rawmesh(name,material,loc=None):
 bpy.ops.import_scene.obj(filepath=str(A/f'{name}.obj'),axis_forward='Y',axis_up='Z');o=bpy.context.selected_objects[0];o.data.materials.clear();o.data.materials.append(mats[material]);
 if loc:o.location=loc
 return o
rawmesh('background_0','photo_0');rawmesh('background_side_extension','photo_1');rawmesh('table_top','table');coffee=rawmesh('coffee_shell','cup',cup);lid=rawmesh('lid_top','photo_0',cup)
bpy.ops.mesh.primitive_cube_add(size=1,location=(0,0,cal['table_height']/2));o=bpy.context.object;o.name='table_collision';o.dimensions=(cal['table_width'],cal['table_depth'],cal['table_height']);o.data.materials.append(mats['white'])
bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=.045,depth=.018,location=(cup[0],cup[1],cup[2]+.159));rim=bpy.context.object;rim.data.materials.append(mats['black'])
bpy.ops.mesh.primitive_plane_add(size=12);bpy.context.object.data.materials.append(mats['floor'])
bpy.ops.object.light_add(type='AREA',location=(-1,-1,4));bpy.context.object.data.energy=200;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=4
for c in cal['cameras']:
 bpy.ops.object.camera_add(location=c['position']);o=bpy.context.object;o.name=c['name'];o.rotation_euler=Matrix(c['rotation_camera_to_world_opengl']).to_euler();o.data.type='PERSP';o.data.sensor_fit='VERTICAL';o.data.sensor_height=24;o.data.lens=cal['K'][1][1]/1000*24;o.data.clip_start=.005;o.data.clip_end=30
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'scene.blend'))
for c in cal['cameras']:
 s.camera=bpy.data.objects[c['name']];s.render.filepath=str(ROOT/'renders'/f"{c['name']}.png");bpy.ops.render.render(write_still=True)
for o in [coffee,lid,rim]:o.location.z+=.2
s.camera=bpy.data.objects['capture_1207'];s.render.filepath=str(ROOT/'renders/coffee_lifted.png');bpy.ops.render.render(write_still=True)
