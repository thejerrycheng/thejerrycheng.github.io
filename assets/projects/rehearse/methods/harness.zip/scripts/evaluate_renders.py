from pathlib import Path
from PIL import Image
import numpy as np,json,cv2
ROOT=Path(__file__).resolve().parents[1];report={'protocol':'Input-view fit: render vs resized source from recovered camera. These are training/input images, not held-out novel views. Generated fill counts as rendered content. No alignment or exposure correction is applied.','cases':{}}
def score(reference,result):
 a=np.array(Image.open(reference).convert('RGB'));b=np.array(Image.open(result).convert('RGB'));a=cv2.resize(a,(b.shape[1],b.shape[0]),interpolation=cv2.INTER_AREA).astype('float64')/255;b=b.astype('float64')/255;mse=np.mean((a-b)**2);ma=cv2.GaussianBlur(a,(11,11),1.5);mb=cv2.GaussianBlur(b,(11,11),1.5);va=cv2.GaussianBlur(a*a,(11,11),1.5)-ma*ma;vb=cv2.GaussianBlur(b*b,(11,11),1.5)-mb*mb;cov=cv2.GaussianBlur(a*b,(11,11),1.5)-ma*mb;ssim=((2*ma*mb+.01**2)*(2*cov+.03**2))/((ma*ma+mb*mb+.01**2)*(va+vb+.03**2));return {'psnr_db':float(-10*np.log10(mse)),'ssim_rgb':float(ssim.mean()),'mean_absolute_rgb_error_0_255':float(abs(a-b).mean()*255)}
for name,frames in [('test_scene_1',['1207','1208','1209']),('test_scene_2',[0,12,24])]:
 R=ROOT/'scenes'/name;results=[]
 for i in frames:
  src=R/f'source/IMG_{i}.jpg' if name.endswith('1') else R/f'source/frames/frame_{i+1:04d}.jpg';render=R/f'renders/multiview_capture_{i}.png' if name.endswith('1') else R/f'renders/photo_{i:02d}.png';results.append({'capture':str(i),**score(src,render)})
 report['cases'][name]=results
(ROOT/'website/assets/projects/rehearse/render-evaluation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
