from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import re,shutil
ROOT=Path(__file__).resolve().parents[1]
class Handler(SimpleHTTPRequestHandler):
 def send_head(self):
  self.byte_range=None
  path=Path(self.translate_path(self.path))
  if path.is_file() and 'Range' in self.headers:
   m=re.fullmatch(r'bytes=(\d+)-(\d*)',self.headers['Range'])
   if m:
    size=path.stat().st_size;start=int(m[1]);end=min(int(m[2]) if m[2] else size-1,size-1)
    if start>=size:self.send_error(416);return None
    f=path.open('rb');f.seek(start);self.send_response(206);self.send_header('Content-type',self.guess_type(str(path)));self.send_header('Content-Length',str(end-start+1));self.send_header('Content-Range',f'bytes {start}-{end}/{size}');self.send_header('Accept-Ranges','bytes');self.end_headers();self.byte_range=(start,end);return f
  return super().send_head()
 def copyfile(self,source,outputfile):
  if self.byte_range:
   remaining=self.byte_range[1]-self.byte_range[0]+1
   while remaining:
    block=source.read(min(1024*1024,remaining))
    if not block:break
    outputfile.write(block);remaining-=len(block)
  else:shutil.copyfileobj(source,outputfile)
print('http://127.0.0.1:8765/rehearse.html',flush=True)
ThreadingHTTPServer(('127.0.0.1',8765),partial(Handler,directory=str(ROOT/'website'))).serve_forever()
