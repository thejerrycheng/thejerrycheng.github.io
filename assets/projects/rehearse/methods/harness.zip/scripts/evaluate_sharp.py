"""Measure source-camera fit of browser SPZ renders, not unseen-view accuracy."""
from PIL import Image
from skimage.metrics import structural_similarity,peak_signal_noise_ratio
from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parents[1];out=R/'website/assets/projects/rehearse/splats'
rows=[]
for case,src in [('scene1','scenes/test_scene_1/source/IMG_1207.jpg'),('scene2','scenes/test_scene_2/source/full/frame_0013.jpg')]:
 im=Image.open('/tmp/rehearse-sharp'+case[-1]+'.png').convert('RGB');reference=Image.open(R/src).convert('RGB').resize(im.size,Image.Resampling.LANCZOS);a=np.array(im);b=np.array(reference)
 rows.append({'case':case,'render_width':im.width,'render_height':im.height,'psnr_db':float(peak_signal_noise_ratio(b,a,data_range=255)),'ssim_rgb':float(structural_similarity(b,a,channel_axis=2,data_range=255))})
 im.save(out/(case+'-render.webp'),quality=93)
 for name in ['lift','novel']:
  p=Path('/tmp/rehearse-sharp'+case[-1]+'-'+name+'.png')
  if p.exists():Image.open(p).save(out/(case+'-'+name+'.webp'),quality=93)
report={'method':'Apple SHARP, independently predicted from one image per case; SPZ quantization + Spark browser rendering','evaluation':'Input image resized with Lanczos to browser render resolution; RGB PSNR/SSIM without image alignment or exposure correction. Not independent novel-view or geometry accuracy. Different resolutions and inputs from the mesh benchmark prevent a matched-budget method comparison.','results':rows,'limitations':['Cup segmentation exposes missing background and residual boundary splats when moved.','Appearance preview has no collision simulation.','No multi-view Gaussian training or online updating was performed.']}
(out/'source-view-evaluation.json').write_text(json.dumps(report,indent=2));print(json.dumps(rows,indent=2))
