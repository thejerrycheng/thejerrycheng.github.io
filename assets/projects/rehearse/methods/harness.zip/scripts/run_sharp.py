import os,sys
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',IMAGEIO_FFMPEG_EXE='/opt/homebrew/bin/ffmpeg',MPLCONFIGDIR='/tmp/rehearse-mpl')
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'third_party/ml-sharp/src'))
import torch,numpy as np,json,time
from PIL import Image
from sharp.models import PredictorParams,create_predictor
from sharp.cli.predict import predict_image
from sharp.utils.gaussians import save_ply
torch.set_num_threads(4);print('loading SHARP',flush=True);model=create_predictor(PredictorParams());model.load_state_dict(torch.load(R/'models/sharp/sharp.pt',weights_only=True,map_location='cpu'));model.eval();report=[]
for case,file,f in [('test_scene_1','source/IMG_1207.jpg',None),('test_scene_2','source/full/frame_0013.jpg',None)]:
 root=R/'scenes'/case;out=root/'assets/sharp';out.mkdir(exist_ok=True)
 if (out/'scene.ply').exists():continue
 im=np.array(Image.open(root/file).convert('RGB'));height,width=im.shape[:2];cal=json.loads((root/('calibration/cameras_multiview.json' if case.endswith('1') else 'calibration/cameras.json')).read_text());f=(cal['cameras'][0]['K'][0][0]*width/750 if case.endswith('1') else cal['K'][0][0]*width/960);start=time.time();g=predict_image(model,im,float(f),torch.device('cpu'));save_ply(g,float(f),(height,width),out/'scene.ply');report.append({'case':case,'seconds':time.time()-start,'count':int(g.mean_vectors.shape[1]),'width':width,'height':height,'focal_px':float(f),'source':file});print(report[-1],flush=True);(out/'report.json').write_text(json.dumps(report[-1],indent=2))
