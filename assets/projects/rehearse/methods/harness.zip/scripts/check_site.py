import sys,runpy
if '--methods' in sys.argv:
 runpy.run_path('scripts/check_methods.py');raise SystemExit
import sys,runpy
if '--interactions' in sys.argv:
 runpy.run_path('scripts/check_interactions.py');raise SystemExit
import sys,runpy
if '--splats' in sys.argv:
 runpy.run_path('scripts/check_splats.py');raise SystemExit
if '--scene2' in sys.argv:
 runpy.run_path('scripts/check_scene2.py');raise SystemExit
from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
 page=b.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/rehearse.html',wait_until='networkidle');page.wait_for_timeout(3000)
 page.screenshot(path='/tmp/rehearse-browser.png',full_page=False)
 print({'errors':errors,'canvas':page.locator('canvas').count(),'title':page.title()})
 b.close()
