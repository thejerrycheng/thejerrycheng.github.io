"""Deterministic offline map/camera replay synchronized to the egocentric source."""
from pathlib import Path
import numpy as np,cv2,json,subprocess
from scipy.spatial.transform import Rotation,Slerp
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'scenes/test_scene_2';cal=json.loads((R/'calibration/cameras.json').read_text());a=np.load(R/'calibration/dense_world.npz');idx=np.arange(0,len(a['xyz']),max(1,len(a['xyz'])//140000));X=a['xyz'][idx];colors=a['rgb'][idx][:,::-1];seen=a['first_seen'][idx];times=np.array([c['time'] for c in cal['cameras']]);C=np.array([c['position'] for c in cal['cameras']]);rots=Rotation.from_matrix([c['rotation_camera_to_world_opengl'] for c in cal['cameras']]);slerp=Slerp(times,rots)
W,H=960,720;eye=np.array([3.3,-4.5,4.0]);target=np.array([-.5,.8,.55]);forward=target-eye;forward/=np.linalg.norm(forward);right=np.cross(forward,[0,0,1]);right/=np.linalg.norm(right);up=np.cross(right,forward);camR=np.array([right,-up,forward]);f=700

def project(x):
 q=(x-eye)@camR.T;uv=q[:,:2]/q[:,2:]*f+[W/2,H/2+40];return np.rint(uv).astype(int),q[:,2]
uv,z=project(X);valid=(z>.1)&(uv[:,0]>1)&(uv[:,0]<W-2)&(uv[:,1]>1)&(uv[:,1]<H-2);order=np.where(valid)[0];order=order[np.argsort(z[order])[::-1]];path,_=project(C)
video=cv2.VideoCapture(str(ROOT/'website/assets/projects/rehearse/scene2/capture.mp4'));out=ROOT/'website/assets/projects/rehearse/scene2/reconstruction-replay.mp4';fps=15;proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','bgr24','-s',f'{W}x{H*2}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for frame in range(round(15.7*fps)):
 t=frame/fps;img=np.full((H,W,3),[35,31,29],np.uint8);ids=order[seen[order]<=t];p=uv[ids];col=colors[ids]
 for dx,dy in [(0,0),(1,0),(0,1)]:img[p[:,1]+dy,p[:,0]+dx]=col
 j=np.searchsorted(times,t);cv2.polylines(img,[path[:min(j+1,len(path))]],False,(234,193,49),2,cv2.LINE_AA);ts=np.clip(t,times[0],times[-1]);position=np.array([np.interp(ts,times,C[:,k]) for k in range(3)]);rot=slerp(ts).as_matrix();corners=np.array([[-.12,-.09,-.2],[.12,-.09,-.2],[.12,.09,-.2],[-.12,.09,-.2]]);corners=corners@rot.T+position;pp,_=project(np.r_[position[None],corners]);
 for k in range(4):cv2.line(img,tuple(pp[0]),tuple(pp[k+1]),(255,255,255),2,cv2.LINE_AA);cv2.line(img,tuple(pp[k+1]),tuple(pp[(k+1)%4+1]),(255,255,255),1,cv2.LINE_AA)
 cv2.circle(img,tuple(pp[0]),6,(255,180,0),-1,cv2.LINE_AA);cv2.rectangle(img,(0,0),(W,83),(29,27,26),-1);cv2.putText(img,'REHEARSE  /  RECONSTRUCTION REPLAY',(28,35),cv2.FONT_HERSHEY_SIMPLEX,.65,(244,244,244),1,cv2.LINE_AA);cv2.putText(img,f'{t:05.2f} s  |  {len(ids):,} sampled observations  |  31 keyframe poses',(28,65),cv2.FONT_HERSHEY_SIMPLEX,.48,(187,185,181),1,cv2.LINE_AA)
 video.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,source=video.read()
 if not ok:source=np.zeros((H,W,3),np.uint8)
 source=cv2.resize(source,(W,H));cv2.rectangle(source,(0,H-38),(W,H),(29,27,26),-1);cv2.putText(source,'Original video  |  Offline reconstruction; intermediate camera poses interpolated',(22,H-13),cv2.FONT_HERSHEY_SIMPLEX,.47,(240,240,240),1,cv2.LINE_AA);proc.stdin.write(np.vstack([img,source]).tobytes())
 if frame%45==0:print('frame',frame,flush=True)
proc.stdin.close();assert proc.wait()==0;video.release();print(out)
