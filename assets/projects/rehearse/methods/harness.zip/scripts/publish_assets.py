from pathlib import Path
import shutil,json,zipfile,numpy as np,cv2
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'website/assets/projects/rehearse';S1=ROOT/'scenes/test_scene_1';S2=ROOT/'scenes/test_scene_2'
shutil.copy2(S1/'assets/multiview/scene.glb',W/'scene.glb');shutil.copy2(S1/'calibration/cameras_multiview.json',W/'cameras.json')
for name in ['scene.glb','objects.json']:shutil.copy2(S2/'assets'/name,W/'scene2'/name)
for n in ['1207','1208','1209']:
 Image.open(S1/f'renders/multiview_capture_{n}.png').save(W/f'render-{n}.webp',quality=91)
Image.open(S1/'renders/multiview_lifted.png').save(W/'lifted.webp',quality=91)
a=np.load(S1/'calibration/da3_large.npz')
for i,n in enumerate(['1207','1208','1209']):
 d=a['depth'][i];x=np.clip((d-np.percentile(d,2))/(np.percentile(d,98)-np.percentile(d,2)),0,1);rgb=cv2.cvtColor(cv2.applyColorMap((x*255).astype('uint8'),cv2.COLORMAP_TURBO),cv2.COLOR_BGR2RGB);Image.fromarray(rgb).resize((750,1000)).save(W/f'depth-{n}.webp',quality=90)
Image.open(S2/'source/frames/frame_0013.jpg').save(W/'scene2/reference.webp',quality=92);Image.open(S2/'renders/photo_12.png').save(W/'scene2/render.webp',quality=92)
for s,n in [(S1,'scene1'),(S2,'scene2')]:
 out=W/n;out.mkdir(exist_ok=True)
 for file in ['physics_report.json','depth_benchmark.json','sam2_tracking.json','multiview_physics.json','hinge_contacts.json']:
  p=s/'calibration'/file
  if p.exists():shutil.copy2(p,out/file.replace('_','-'))
# Portable simulation downloads: only runtime assets and documented assumptions.
for s,n,xml,assets in [(S1,'scene1','scene_multiview.xml','assets/multiview'),(S2,'scene2','scene.xml','assets/objects')]:
 with zipfile.ZipFile(W/n/'mujoco-scene.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  z.write(s/xml,'scene.xml')
  for p in (s/assets).rglob('*.obj'):z.write(p,str(p.relative_to(s)))
  if n=='scene2' and (s/'scene_coacd.xml').exists():z.write(s/'scene_coacd.xml','scene-coacd.xml')
  for p in ((s/'assets/multiview').glob('*.png') if n=='scene1' else [s/'assets/photo_atlas.png',s/'assets/still_atlas.png']):z.write(p,str(p.relative_to(s)))
  for p in [s/'assets/physics_assumptions.json',s/'calibration/physics_report.json',s/'calibration/multiview_physics.json']:
   if p.exists():z.write(p,p.name)
  z.writestr('README.txt','Rehearse reconstruction prototype. Load scene.xml with MuJoCo 3.5+. Scene 2 also includes scene-coacd.xml with fewer, coarser convex collision pieces; compare contact_comparison.json and physics timing reports before choosing a training profile. Scale is provisional (17 cm cup assumption). Camera poses are estimated. Mass, friction and hidden geometry are not measured. Visual textures contain captured illumination; relighting is not physically calibrated. Floor completion is generated. Browser object motion is a transform preview, not an RL policy. Scene 1 uses later video to localize its still cameras. Scene 2 backpack and cushions are rigid approximations. Cables and distant contents are not individually simulated. All scenes require robot-frame calibration and physical validation before transfer.\n')
  if n=='scene2':
   for p in list((s/'calibration').glob('physics_timing_*.json'))+[s/'calibration/contact_comparison.json',s/'calibration/completed_asset_validation.json']:z.write(p,p.name)
print('published runtime assets into website checkout')
