import os
os.environ.update(USE_TF='0',USE_FLAX='0',KMP_USE_SHM='0',OMP_NUM_THREADS='4')
from pathlib import Path
import torch,numpy as np,cv2
from transformers import SamModel,SamProcessor
from PIL import Image
R=Path(__file__).resolve().parents[1];torch.set_num_threads(4);p=SamProcessor.from_pretrained(str(R/'models/sam-vit-base'));m=SamModel.from_pretrained(str(R/'models/sam-vit-base')).eval();im=Image.open(R/'scenes/test_scene_1/source/IMG_1207.jpg').resize((750,1000));inputs=p(im,input_boxes=[[[353,520,474,727]]],return_tensors='pt')
with torch.inference_mode():o=m(**inputs)
masks=p.image_processor.post_process_masks(o.pred_masks,inputs['original_sizes'],inputs['reshaped_input_sizes'])[0];i=int(o.iou_scores[0,0].argmax());mask=masks[0,i].numpy().astype('uint8')*255;cv2.imwrite(str(R/'scenes/test_scene_1/calibration/sharp_cup_mask.png'),mask);print('cup mask',int((mask>0).sum()))
