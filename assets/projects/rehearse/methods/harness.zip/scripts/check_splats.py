from playwright.sync_api import sync_playwright
from pathlib import Path
import json, base64

def capture(page, name):
 page.wait_for_function('''() => { const s=window.rehearseSplats; const m=s.spark.defaultView.display?.accumulator.mapping.find(r=>r.node===s.cup);return m && m.version===s.cup.version && s.cup.context.transform.translate.value.distanceTo(s.cup.position)<1e-5; }''',timeout=45000)
 page.evaluate('''async () => { await new Promise(r=>requestAnimationFrame(r)); const s=window.rehearseSplats;s.renderer.render(s.scene,s.camera); }''')
 print('ready to capture',name,flush=True)
 data=page.evaluate("window.rehearseSplats.renderer.domElement.toDataURL('image/png')")
 Path('/tmp/'+name+'.png').write_bytes(base64.b64decode(data.split(',')[1]))
 print('captured',name,flush=True)

def drag_cup(page):
 page.locator('#splat-view').scroll_into_view_if_needed()
 point=page.evaluate("""()=>{const s=window.rehearseSplats,e=s.interaction.entries[0],v=e.bounds.getCenter(s.cup.position.clone()).applyMatrix4(s.cup.matrixWorld).project(s.camera),r=s.renderer.domElement.getBoundingClientRect();return {x:r.left+(v.x+1)*r.width/2,y:r.top+(1-v.y)*r.height/2};}""")
 page.mouse.move(point['x'],point['y']);page.keyboard.down('Shift');page.mouse.down();page.mouse.move(point['x'],point['y']-70,steps=8);page.mouse.up();page.keyboard.up('Shift')
 assert page.evaluate('window.rehearseSplats.cup.position.length()>0'),point
 print(page.evaluate("()=>{const s=window.rehearseSplats;return {position:s.cup.position.toArray(),transform:s.cup.context.transform.translate.value.toArray(),version:s.cup.version,mapping:s.spark.defaultView.display?.accumulator.mapping.filter(r=>r.node===s.cup).map(r=>r.version)};}"),flush=True)

with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--use-angle=metal','--enable-webgl','--ignore-gpu-blocklist'])
 page=b.new_page(viewport={'width':1440,'height':1200},device_scale_factor=1)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('console',lambda m:print(m.text[:500],flush=True) if m.type=='error' else None)
 print('browser launched',flush=True)
 page.goto('http://127.0.0.1:8765/rehearse-splats.html',wait_until='networkidle')
 print('page loaded',flush=True)
 page.wait_for_function('window.rehearseSplats?.ready',timeout=45000)
 page.wait_for_timeout(2500)
 capture(page,'rehearse-sharp1')
 drag_cup(page)
 page.wait_for_timeout(1200)
 assert page.evaluate('window.rehearseSplats.cup.position.length()>0')
 capture(page,'rehearse-sharp1-lift')
 page.keyboard.press('r')
 assert page.evaluate('window.rehearseSplats.cup.position.length()===0')
 page.locator('#splat-novel').dispatch_event('click')
 page.wait_for_timeout(1200)
 capture(page,'rehearse-sharp1-novel')
 page.locator('#splat-reset').dispatch_event('click')
 assert page.evaluate('window.rehearseSplats.camera.position.length()<1e-6')
 page.locator('#splat-case').select_option('scene2')
 page.wait_for_function('window.rehearseSplats?.meta?.case==="test_scene_2"',timeout=45000)
 page.wait_for_timeout(2500)
 capture(page,'rehearse-sharp2')
 drag_cup(page)
 page.wait_for_timeout(1200)
 capture(page,'rehearse-sharp2-lift')
 page.keyboard.press('r')
 assert page.evaluate('window.rehearseSplats.cup.position.length()===0')
 page.screenshot(path='/tmp/rehearse-splats-page.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844})
 page.wait_for_timeout(1000)
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
 page.screenshot(path='/tmp/rehearse-splats-mobile.png',full_page=True)
 print({'errors':errors},flush=True)
 Path('website/assets/projects/rehearse/splats/browser-checks.json').write_text(json.dumps({'errors':errors,'source_and_offset_views_captured':True,'cup_lift_and_reset_checked':True,'direct_pointer_drag_checked':True,'mobile_layout_checked':True,'browser':'Chromium headless with ANGLE Metal'},indent=2))
 b.close()
 assert not errors
