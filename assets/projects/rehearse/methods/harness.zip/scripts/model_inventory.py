from pathlib import Path
import json,hashlib,subprocess,importlib.metadata as md
R=Path(__file__).resolve().parents[1]
models=[('Depth Anything V2 Small','models/depth-anything-v2-small/model.safetensors','https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf'),('Depth Anything 3 Small','models/da3-small/model.safetensors','https://huggingface.co/depth-anything/DA3-SMALL'),('Depth Anything 3 Large','models/da3-large/model.safetensors','https://huggingface.co/depth-anything/DA3-LARGE'),('SAM ViT-B','models/sam-vit-base/model.safetensors','https://huggingface.co/facebook/sam-vit-base'),('SAM 2.1 Hiera Tiny','models/sam2.1/sam2.1_hiera_tiny.pt','https://github.com/facebookresearch/sam2'),('Apple SHARP','models/sharp/sharp.pt','https://github.com/apple-aiml-research/ml-sharp')]
models.append(('TripoSR','models/triposr/model.ckpt','https://huggingface.co/stabilityai/TripoSR'))
for f in sorted((R/'models/sam3d-mlx').rglob('*.safetensors')):models.append(('SAM 3D MLX '+f.stem,str(f.relative_to(R)),'https://huggingface.co/appautomaton/sam-3d-objects-mlx'))
report={'models':[],'libraries':{},'limitations':['CPU execution; no CUDA training or rasterization.','gsplat Python package installed with BUILD_NO_CUDA=1. Standard trained 3DGS has not run.','Model comparisons use different published model configurations and input resolutions; not a controlled equal-compute architecture ablation.','Generative clean plates infer hidden appearance; not measured geometry.']}
for name,p,url in models:
 f=R/p;h=hashlib.sha256()
 with f.open('rb') as stream:
  while block:=stream.read(4*1024*1024):h.update(block)
 report['models'].append({'name':name,'local_relative_path':p,'source':url,'bytes':f.stat().st_size,'sha256':h.hexdigest()})
for p in ['torch','pycolmap','mujoco','gsplat','transformers','numpy','open3d','hydra-core']:
 try:report['libraries'][p]=md.version(p)
 except md.PackageNotFoundError:pass
(R/'model_inventory.json').write_text(json.dumps(report,indent=2));(R/'website/assets/projects/rehearse/model-inventory.json').write_text(json.dumps(report,indent=2));print('model inventory saved')
