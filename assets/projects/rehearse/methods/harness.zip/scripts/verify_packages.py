from pathlib import Path
import tempfile,zipfile,json,numpy as np,mujoco
root=Path(__file__).resolve().parents[1];results=[]
for case in ['scene1','scene2']:
 with tempfile.TemporaryDirectory(prefix='rehearse-package-') as d:
  with zipfile.ZipFile(root/f'website/assets/projects/rehearse/{case}/mujoco-scene.zip') as z:z.extractall(d)
  m=mujoco.MjModel.from_xml_path(str(Path(d)/'scene.xml'));data=mujoco.MjData(m)
  for _ in range(round(3/m.opt.timestep)):mujoco.mj_step(m,data)
  assert np.isfinite(data.qpos).all();assert not any(w.number for w in data.warning)
  results.append({'case':case,'portable_archive_loaded':True,'simulation_seconds':float(data.time),'finite_state':True,'warnings':0})
(root/'website/assets/projects/rehearse/package-checks.json').write_text(json.dumps(results,indent=2));print(results)
