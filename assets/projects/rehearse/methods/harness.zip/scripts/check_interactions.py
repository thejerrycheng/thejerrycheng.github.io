from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--use-angle=metal','--enable-webgl','--ignore-gpu-blocklist']);page=b.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/rehearse-scene-2.html',wait_until='networkidle');page.wait_for_function('window.rehearseReplay?.ready',timeout=120000);page.locator('#replay').scroll_into_view_if_needed();page.locator('[data-view2="capture"]').click();page.evaluate('window.rehearseReplay.seek(6.25)');page.wait_for_timeout(300)
 assert page.locator('[data-move],#lid-angle,#reset-objects').count()==0
 assert page.locator('#scene2-interactions .movable-list li').count()==7
 page.locator('#scene2-interactions .highlight-all').click();assert page.evaluate('window.rehearseReplay.interaction.entries.every(e=>e.box.visible)')
 point=page.evaluate('''()=>{const s=window.rehearseReplay,o=s.objects.get('cup').object;const p=o.getWorldPosition(o.position.clone());p.z-=.07;p.project(s.camera);const r=s.renderer.domElement.getBoundingClientRect(),w=Math.min(r.width,r.height*4/3),h=w*3/4;return {x:r.left+r.width/2+p.x*w/2,y:r.top+r.height/2-p.y*h/2};}''')
 before=page.evaluate("window.rehearseReplay.objects.get('cup').object.position.toArray()")
 page.mouse.move(point['x'],point['y']);page.mouse.down();page.mouse.move(point['x']+40,point['y']-40,steps=10);page.mouse.up();after=page.evaluate("window.rehearseReplay.objects.get('cup').object.position.toArray()");assert sum((a-b)**2 for a,b in zip(after,before))>.001,(before,after,point)
 page.keyboard.press('r');assert page.evaluate("window.rehearseReplay.objects.get('cup').object.position.distanceTo(window.rehearseReplay.objects.get('cup').initial)<1e-6")
 # Exercise the visible hinge handle with real pointer events before numeric tests.
 points=page.evaluate("""()=>{const s=window.rehearseReplay,j=s.joint,r=s.renderer.domElement.getBoundingClientRect(),w=Math.min(r.width,r.height*4/3),h=w*3/4;return [0,.45].map(a=>{const v=j.handleLocal.clone().applyAxisAngle(j.axis,a).applyMatrix4(j.object.matrixWorld).project(s.camera);return {x:r.left+r.width/2+v.x*w/2,y:r.top+r.height/2-v.y*h/2};});}""")
 page.mouse.move(points[0]['x'],points[0]['y']);page.mouse.down();page.mouse.move(points[1]['x'],points[1]['y'],steps=12);page.mouse.up();assert page.evaluate('window.rehearseReplay.joint.angle>.1'),points;page.evaluate('window.rehearseReplay.interaction.setJoint(window.rehearseReplay.joint,0)')
 report=page.evaluate('''()=>{const s=window.rehearseReplay,j=s.joint;const rest=j.handleLocal.clone().applyMatrix4(j.object.matrixWorld);const result=s.interaction.setJoint(j,10);j.object.updateMatrixWorld(true);const closed=j.handleLocal.clone().applyMatrix4(j.object.matrixWorld);return {rest:rest.toArray(),closed:closed.toArray(),angle:j.angle,contact:result.contact,penetrates:!!j.collision(j.angle),max:j.max};}''');assert report['angle']>.4,report;assert not report['penetrates'],report;assert report['closed'][1]<report['rest'][1],report
 page.screenshot(path='/tmp/rehearse-direct-closed.png');page.evaluate('window.rehearseReplay.interaction.setJoint(window.rehearseReplay.joint,0)')
 # Raise the table into the lid's closing sweep: contact must stop it sooner.
 collision=page.evaluate('''()=>{const s=window.rehearseReplay,t=s.objects.get('table').object;t.position.z+=.12;t.position.y-=.56;const r=s.interaction.setJoint(s.joint,10);const result={...r,penetrates:!!s.joint.collision(r.angle)};t.position.z-=.12;t.position.y+=.56;s.interaction.setJoint(s.joint,0);return result;}''');assert collision['contact']=='tabletop' and not collision['penetrates'],collision
 page.set_viewport_size({'width':390,'height':844});page.locator('#replay').scroll_into_view_if_needed();page.wait_for_timeout(250);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path='/tmp/rehearse-direct-mobile.png',full_page=True)
 page.set_viewport_size({'width':1440,'height':1100});page.goto('http://127.0.0.1:8765/rehearse.html',wait_until='networkidle');page.wait_for_function('window.rehearseScene1?.ready',timeout=120000);assert page.locator('#lift').count()==0;page.locator('#scene').scroll_into_view_if_needed();page.locator('[data-camera="0"]').click();page.locator('#scene1-interactions .highlight-all').click();page.screenshot(path='/tmp/rehearse-direct-scene1.png')
 assert not errors,errors
 print({'errors':errors,'cup_drag':True,'hinge':report,'raised_table_contact':collision},flush=True)
 Path('website/assets/projects/rehearse/interaction-checks.json').write_text(json.dumps({'errors':errors,'cup_direct_drag_and_reset':True,'hinge_pointer_drag':True,'movable_entries':6,'articulated_joints':1,'hinge':report,'raised_table_contact':collision,'mobile_overflow':False},indent=2));b.close()
