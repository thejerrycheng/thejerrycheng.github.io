"""Publish portable source, example annotations and provenance; exclude large weights."""
from pathlib import Path
import json,subprocess,zipfile,importlib.metadata as md,shutil
R=Path(__file__).resolve().parents[1];W=R/'website/assets/projects/rehearse/methods';W.mkdir(exist_ok=True);repos=[]
for p in sorted((R/'third_party').iterdir()):
 if not (p/'.git').exists():continue
 def git(*args):return subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
 repos.append({'directory':str(p.relative_to(R)),'url':git('remote','get-url','origin'),'revision':git('rev-parse','HEAD')})
libs={}
for n in ['torch','torchvision','transformers','pycolmap','mujoco','gsplat','numpy','scipy','trimesh','open3d','opencv-python','Pillow','hydra-core','omegaconf','scikit-image','playwright','safetensors','einops','huggingface-hub','rembg','xatlas','fast-simplification','coacd','rtree']:
 try:libs[n]=md.version(n)
 except md.PackageNotFoundError:pass
provenance={'python':'3.11','packages':libs,'repositories':repos,'separate_environment':'NumPy 1.26.4 is isolated for Open3D stages. MLX experiment uses Python 3.13; see README.','inputs':'Full capture and model weights excluded. The 31 reference JPEGs, SAM prompt masks and calibration are included. Fetch the website capture.mp4 at the config path for full-rate tracking.'};(R/'harness/environment.json').write_text(json.dumps(provenance,indent=2))
files=[R/'model_inventory.json'];files+=list((R/'harness').glob('*.py'))+list((R/'harness').glob('*.md'))+list((R/'harness').glob('*.json'))+list((R/'harness/configs').glob('*.json'));files+=list((R/'scripts').glob('*.py'))
files += [p for p in (R/'harness/simfoundry').rglob('*') if p.is_file() and p.suffix in ['.py','.json','.patch']]
files += [R/'scenes/test_scene_2/simfoundry/room/capture_manifest.json']
for case in ['test_scene_1','test_scene_2']:
 s=R/'scenes'/case;files+=list((s/'scripts').glob('*.py'));files+=list((s/'calibration').glob('*.json'));files+=list((s/'calibration/masks').glob('*.png'));files+=list((s/'source/frames').glob('*.jpg'))
 for file in ['assets/physics_assumptions.json','scene.xml','scene_multiview.xml']:
  if (s/file).exists():files.append(s/file)
files+=list((R/'website/assets/projects/rehearse').glob('*.js'))
with zipfile.ZipFile(W/'harness.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  if p.suffix in ['.json','.md','.py','.js'] and ('/'+'Users'+'/') in p.read_text():raise ValueError('Nonportable machine path in '+str(p))
  z.write(p,str(p.relative_to(R)))
 z.writestr('README.txt','Start with harness/README.md. Stage scripts need the separately downloaded model checkpoints and third-party repositories pinned in harness/environment.json. MuJoCo runtime assets are separate case-study downloads. The source JPEGs are reconstructed keyframes, not the full original capture. Models and inferred surfaces are not ground truth.\n')
for f in ['README.md','research.md','environment.json']:shutil.copy2(R/'harness'/f,W/f)
print('Harness files',len(set(files)),'bytes',(W/'harness.zip').stat().st_size)
