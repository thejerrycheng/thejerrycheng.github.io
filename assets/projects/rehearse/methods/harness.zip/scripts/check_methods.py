from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--use-angle=metal']);page=b.new_page(viewport={'width':1440,'height':1100});errors=[];missing=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:missing.append(r.url) if r.status>=400 else None);page.goto('http://127.0.0.1:8765/rehearse-methods.html',wait_until='networkidle');page.screenshot(path='/tmp/rehearse-methods.png',full_page=True)
 for a in page.locator('a[href^="assets/"]').all():
  href=a.get_attribute('href');response=page.request.get('http://127.0.0.1:8765/'+href);assert response.ok,(href,response.status)
 page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');page.screenshot(path='/tmp/rehearse-methods-mobile.png',full_page=True);assert not errors and not missing,(errors,missing);Path('website/assets/projects/rehearse/methods/browser-checks.json').write_text(json.dumps({'errors':errors,'missing_assets':missing,'local_download_links_checked':True,'mobile_overflow':False},indent=2));b.close();print('Methods page and downloads passed')
